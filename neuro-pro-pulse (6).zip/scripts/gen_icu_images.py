"""Regenerate 3 photorealistic ICU patient images for the NeuroSim cases.

Each image depicts a comatose, intubated, mechanically-ventilated adult
patient in a modern academic neuro-ICU room. Sophisticated equipment
(Puritan Bennett / Drager ventilator, Philips IntelliVue / GE CARESCAPE
multi-parameter monitor with live waveforms, IV pumps, EEG electrodes,
central line) is visible. Ages and demographics match the case prompts.

Run:  python /app/scripts/gen_icu_images.py
Output: /app/frontend/public/patients/*.png
"""
import asyncio
import base64
import os
from pathlib import Path

from dotenv import load_dotenv
from emergentintegrations.llm.chat import LlmChat, UserMessage

load_dotenv('/app/backend/.env')

OUT_DIR = Path('/app/frontend/public/patients')
OUT_DIR.mkdir(parents=True, exist_ok=True)

BASE_STYLE = (
    "Ultra-photorealistic, editorial medical photography, cinematic lighting. "
    "Shot on a full-frame camera with a 50mm lens, shallow depth of field, "
    "subtle film grain. This is NOT an illustration, NOT a cartoon, NOT a "
    "3D render — a real-looking photograph. \n\n"
    "SCENE: A modern academic neurocritical-care ICU room, single occupancy, "
    "glass sliding door visible in the background, clean contemporary "
    "architecture with cool white walls and a subtle wood accent. Soft "
    "overhead LED lighting plus the warm glow of bedside monitors. The "
    "patient lies at a slight incline on pristine white hospital linens in "
    "a modern articulating ICU bed (Stryker InTouch style). \n\n"
    "PATIENT STATE: Comatose, eyes gently closed, lips relaxed around an "
    "endotracheal tube secured with tape. Ventilator tubing runs to a "
    "modern mechanical ventilator at the head of the bed. Several ECG "
    "leads visible on the chest, pulse oximeter on one finger, arterial "
    "line on the forearm, central venous line at the right internal "
    "jugular site (well dressed). A row of scalp EEG electrodes with "
    "cables is visible across the forehead and scalp (continuous EEG "
    "monitoring). A warm hospital blanket is pulled up to mid-chest. \n\n"
    "EQUIPMENT (all sharply rendered, clinically accurate): \n"
    "  • Multi-parameter bedside monitor with readable waveforms (ECG, "
    "SpO2, ABP, EtCO2, ICP) and numeric values \n"
    "  • Mechanical ventilator with digital display \n"
    "  • Stack of IV infusion pumps on a pole (Alaris / BBraun style) \n"
    "  • EEG machine with cable bundle \n"
    "  • Ambient IV poles, suction canister, crash cart edge in background \n\n"
    "COMPOSITION: Three-quarter camera angle from the foot-left of the bed, "
    "medium close-up of the patient's upper body with the monitor and "
    "ventilator framed softly behind. Respectful, dignified, serious "
    "tone. No gore, no blood. Hyper-clean modern ICU aesthetic. "
    "Aspect ratio 16:9."
)

PATIENTS = [
    {
        "slug": "case1_baseline_54f_black",
        "description": (
            "A 54-year-old Black / African American woman. Medium-dark "
            "skin tone. Short-to-medium natural dark hair, slightly "
            "tousled against the pillow. Gentle facial lines consistent "
            "with age 54 (not younger). Serene, relaxed face. No makeup."
        ),
    },
    {
        "slug": "case2_teaching_67m_hispanic",
        "description": (
            "A 67-year-old Hispanic / Latino man. Warm medium-olive "
            "skin tone. Short salt-and-pepper hair, trimmed gray "
            "mustache-and-beard stubble. Age-appropriate skin texture "
            "and facial lines (clearly 60s, not younger). Serene, "
            "relaxed face."
        ),
    },
    {
        "slug": "case3_eval_71f_white",
        "description": (
            "A 71-year-old White / Caucasian woman. Fair skin tone with "
            "age-appropriate fine lines and texture (clearly in her "
            "early 70s, not younger). Short silver-white hair. Serene, "
            "relaxed face. No makeup."
        ),
    },
]


async def generate_one(patient):
    api_key = os.getenv("EMERGENT_LLM_KEY")
    assert api_key, "EMERGENT_LLM_KEY not set"

    chat = LlmChat(
        api_key=api_key,
        session_id=f"neurosim-icu-{patient['slug']}",
        system_message="You generate photorealistic medical photography.",
    )
    chat.with_model("gemini", "gemini-3.1-flash-image-preview").with_params(
        modalities=["image", "text"]
    )

    prompt = f"{BASE_STYLE}\n\nPATIENT SUBJECT: {patient['description']}"
    msg = UserMessage(text=prompt)
    try:
        text, images = await chat.send_message_multimodal_response(msg)
    except Exception as e:
        print(f"[ERR] {patient['slug']}: {e}")
        return False

    if not images:
        print(f"[WARN] no image for {patient['slug']}: {text[:150]}")
        return False

    img = images[0]
    out_path = OUT_DIR / f"{patient['slug']}.png"
    out_path.write_bytes(base64.b64decode(img["data"]))
    size_kb = out_path.stat().st_size // 1024
    print(f"[OK] {out_path.name} ({size_kb} KB)")
    return True


async def main():
    results = []
    for p in PATIENTS:
        results.append(await generate_one(p))
    print(f"Done. {sum(results)}/{len(results)} images generated.")


if __name__ == "__main__":
    asyncio.run(main())
