import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import Layout from './components/Layout';
import Welcome from './pages/Welcome';
import Dashboard from './pages/Dashboard';
import Courses from './pages/Courses';
import ModuleView from './pages/ModuleView';
import CasePlayer from './pages/CasePlayer';
import LearningCheckpoint from './pages/LearningCheckpoint';

import SOAPNotePage from './pages/SOAPNotePage';
import SOAPNoteFeedback from './pages/SOAPNoteFeedback';
import CaseCompleteFeedback from './pages/CaseCompleteFeedback.jsx';
import ProgressAssessment from './pages/ProgressAssessment.jsx';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-slate-950">
        <div className="w-8 h-8 border-4 border-slate-700 border-t-teal-400 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  return (
    <Routes>
      <Route path="/" element={<Navigate to="/Welcome" replace />} />
      <Route element={<Layout />}>
        <Route path="/Welcome" element={<Welcome />} />
        <Route path="/Dashboard" element={<Dashboard />} />
        <Route path="/Courses" element={<Courses />} />
        <Route path="/ModuleView" element={<ModuleView />} />
      </Route>
      <Route path="/CasePlayer" element={<CasePlayer />} />
      <Route path="/LearningCheckpoint" element={<LearningCheckpoint />} />

      <Route path="/SOAPNotePage" element={<SOAPNotePage />} />
      <Route path="/SOAPNoteFeedback" element={<SOAPNoteFeedback />} />
      <Route path="/CaseCompleteFeedback" element={<CaseCompleteFeedback />} />
      <Route path="/ProgressAssessment" element={<ProgressAssessment />} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App