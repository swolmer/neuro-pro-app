import React from 'react';
import { Brain, Target, Zap, TrendingUp, AlertTriangle, Clock, Star } from 'lucide-react';
import ProgressRing from '../dashboard/ProgressRing';

function ScoreBar({ label, value, max = 100, color = 'teal' }) {
  const pct = Math.round((value / max) * 100);
  const colorMap = {
    teal: 'bg-teal-500',
    cyan: 'bg-cyan-500',
    violet: 'bg-violet-500',
    amber: 'bg-amber-500',
    red: 'bg-red-500',
  };
  return (
    <div>
      <div className="flex justify-between text-xs mb-1">
        <span className="text-slate-400">{label}</span>
        <span className="text-slate-200 font-mono font-semibold">{value}{max !== 100 ? `/${max}` : '%'}</span>
      </div>
      <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
        <div className={`h-full ${colorMap[color]} rounded-full transition-all`} style={{ width: `${Math.min(100, pct)}%` }} />
      </div>
    </div>
  );
}

export default function ReasoningScoreCard({ attempt }) {
  const bd = attempt?.score_breakdown || {};
  const aiFeedback = bd.ai_reasoning_feedback
    ? (typeof bd.ai_reasoning_feedback === 'string' ? JSON.parse(bd.ai_reasoning_feedback) : bd.ai_reasoning_feedback)
    : null;

  const cogErrors = attempt?.cognitive_errors || [];
  const hypotheses = attempt?.hypothesis_timestamps || [];
  const firstCorrect = hypotheses.find(h => h.is_correct);

  const errorLabels = {
    premature_closure: 'Premature Closure',
    anchoring_bias: 'Anchoring Bias',
    availability_bias: 'Availability Bias',
    framing_effect: 'Framing Effect',
    other: 'Other',
  };

  return (
    <div className="space-y-4">
      {/* Composite + sub-scores */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
        <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-5 flex items-center gap-2">
          <Brain className="w-4 h-4 text-teal-400" /> Clinical Reasoning Scores
        </h3>
        <div className="flex flex-col md:flex-row items-center gap-6 mb-6">
          <div className="text-center">
            <ProgressRing progress={attempt?.composite_reasoning_score || attempt?.score || 0} size={110} strokeWidth={8} />
            <p className="text-xs text-slate-400 mt-2">Composite Score</p>
          </div>
          <div className="flex-1 space-y-3 w-full">
            <ScoreBar label="Critical Action Completion" value={bd.critical_action_score ?? attempt?.critical_action_score ?? 0} color="teal" />
            <ScoreBar label="Reasoning Path Order" value={bd.order_accuracy_score ?? attempt?.order_accuracy_score ?? 0} color="cyan" />
            <ScoreBar label="Diagnostic Efficiency" value={bd.diagnostic_efficiency_score ?? attempt?.diagnostic_efficiency_score ?? 0} color="violet" />
            <ScoreBar label="AI Reasoning Quality" value={(bd.ai_reasoning_score ?? attempt?.ai_reasoning_score ?? 0)} max={5} color="amber" />
          </div>
        </div>
        <div className="grid grid-cols-3 gap-3 pt-4 border-t border-slate-800 text-center">
          <div>
            <p className="text-xs text-slate-500 mb-1">Total Actions</p>
            <p className="text-lg font-bold text-white font-mono">{bd.total_actions_taken ?? (attempt?.actions_performed?.length || 0)}</p>
          </div>
          <div>
            <p className="text-xs text-slate-500 mb-1">Path Score</p>
            <p className={`text-lg font-bold font-mono ${(bd.reasoning_path_score ?? 0) >= 0 ? 'text-teal-400' : 'text-red-400'}`}>
              {(bd.reasoning_path_score ?? 0) >= 0 ? '+' : ''}{bd.reasoning_path_score ?? 0} pts
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-500 mb-1">Time to Dx</p>
            <p className="text-lg font-bold text-white font-mono">
              {firstCorrect ? `${Math.round(firstCorrect.elapsed_seconds / 60)}m` : '—'}
            </p>
          </div>
        </div>
      </div>

      {/* AI Reasoning Feedback */}
      {aiFeedback && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
          <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-4 flex items-center gap-2">
            <Star className="w-4 h-4 text-amber-400" /> AI Reasoning Assessment
          </h3>
          <div className="flex items-center gap-3 mb-4">
            {[1,2,3,4,5].map(n => (
              <div key={n} className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold ${n <= (aiFeedback.score || 0) ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' : 'bg-slate-800 text-slate-600'}`}>
                {n}
              </div>
            ))}
            <span className="text-slate-400 text-sm ml-2">/ 5</span>
          </div>
          {aiFeedback.overall_feedback && (
            <p className="text-sm text-slate-300 mb-4 leading-relaxed">{aiFeedback.overall_feedback}</p>
          )}
          <div className="grid md:grid-cols-2 gap-4">
            {aiFeedback.strengths?.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-teal-400 uppercase mb-2">Strengths</p>
                <ul className="space-y-1">
                  {aiFeedback.strengths.map((s, i) => (
                    <li key={i} className="text-sm text-slate-300 flex items-start gap-2">
                      <span className="text-teal-500 mt-0.5">✓</span> {s}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            {aiFeedback.weaknesses?.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-red-400 uppercase mb-2">Areas for Improvement</p>
                <ul className="space-y-1">
                  {aiFeedback.weaknesses.map((w, i) => (
                    <li key={i} className="text-sm text-slate-300 flex items-start gap-2">
                      <span className="text-red-400 mt-0.5">→</span> {w}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Reasoning path timeline */}
      {attempt?.actions_performed?.length > 0 && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
          <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-4 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-cyan-400" /> Reasoning Path
          </h3>
          <div className="space-y-2 max-h-64 overflow-auto pr-1">
            {attempt.actions_performed.map((a, i) => {
              const typeConfig = {
                critical: { color: 'text-teal-400', bg: 'bg-teal-500/10 border-teal-500/20', pts: '+2' },
                unnecessary: { color: 'text-amber-400', bg: 'bg-amber-500/10 border-amber-500/20', pts: '-1' },
                dangerous: { color: 'text-red-400', bg: 'bg-red-500/10 border-red-500/20', pts: '-3' },
                neutral: { color: 'text-slate-400', bg: 'bg-slate-800 border-slate-700', pts: '0' },
              }[a.action_type || 'neutral'] || { color: 'text-slate-400', bg: 'bg-slate-800 border-slate-700', pts: '0' };
              return (
                <div key={i} className={`flex items-center gap-3 rounded-lg px-3 py-2 border ${typeConfig.bg}`}>
                  <span className="text-xs text-slate-500 font-mono w-5 shrink-0">{i + 1}.</span>
                  <span className={`text-xs font-semibold w-20 shrink-0 ${typeConfig.color}`}>{a.action_type || 'neutral'}</span>
                  <span className="text-xs text-slate-300 flex-1 truncate">{a.action_text || a.action}</span>
                  <span className={`text-xs font-mono font-bold shrink-0 ${typeConfig.color}`}>{typeConfig.pts}</span>
                  {a.elapsed_seconds != null && (
                    <span className="text-xs text-slate-500 font-mono shrink-0">{Math.round(a.elapsed_seconds / 60)}m</span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Cognitive errors */}
      {cogErrors.length > 0 && (
        <div className="bg-slate-900 border border-red-500/20 rounded-2xl p-6">
          <h3 className="text-sm font-semibold text-red-400 uppercase tracking-wider mb-4 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4" /> Cognitive Errors Detected
          </h3>
          <div className="space-y-3">
            {cogErrors.map((err, i) => (
              <div key={i} className="bg-red-500/5 border border-red-500/20 rounded-xl p-3">
                <p className="text-sm font-semibold text-red-300 mb-1">{errorLabels[err.error_type] || err.error_type}</p>
                <p className="text-xs text-slate-400 mb-1">{err.description}</p>
                {err.message_text && <p className="text-xs text-slate-500 italic">"{err.message_text}"</p>}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Hypothesis timeline */}
      {hypotheses.length > 0 && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
          <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-4 flex items-center gap-2">
            <Clock className="w-4 h-4 text-violet-400" /> Hypothesis Timeline
          </h3>
          <div className="space-y-2">
            {hypotheses.map((h, i) => (
              <div key={i} className={`flex items-start gap-3 rounded-lg px-3 py-2 border ${h.is_correct ? 'bg-teal-500/5 border-teal-500/20' : 'bg-slate-800 border-slate-700'}`}>
                <span className={`text-sm mt-0.5 ${h.is_correct ? 'text-teal-400' : 'text-slate-500'}`}>{h.is_correct ? '✓' : '?'}</span>
                <span className="text-xs text-slate-300 flex-1">{h.hypothesis}</span>
                <span className="text-xs text-slate-500 font-mono">{Math.round(h.elapsed_seconds / 60)}m</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}