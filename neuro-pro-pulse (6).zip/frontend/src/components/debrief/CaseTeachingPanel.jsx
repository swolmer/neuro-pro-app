import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { BookOpen, Lightbulb, Target, Star, ChevronDown, ChevronUp, Loader2, GraduationCap, AlertTriangle, CheckCircle2, ExternalLink } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

const GRADE_CONFIG = {
  A: { label: 'Excellent', color: 'text-teal-400', bg: 'bg-teal-500/10', border: 'border-teal-500/30', min: 85 },
  B: { label: 'Proficient', color: 'text-cyan-400', bg: 'bg-cyan-500/10', border: 'border-cyan-500/30', min: 70 },
  C: { label: 'Developing', color: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/30', min: 55 },
  D: { label: 'Needs Work', color: 'text-orange-400', bg: 'bg-orange-500/10', border: 'border-orange-500/30', min: 40 },
  F: { label: 'Insufficient', color: 'text-red-400', bg: 'bg-red-500/10', border: 'border-red-500/30', min: 0 },
};

function getGrade(score) {
  if (score >= 85) return 'A';
  if (score >= 70) return 'B';
  if (score >= 55) return 'C';
  if (score >= 40) return 'D';
  return 'F';
}

const rubricDimensions = [
  { key: 'critical_action_score', label: 'Critical Action Completion', weight: '40%', desc: 'Did you perform all mandatory clinical steps?' },
  { key: 'order_accuracy_score', label: 'Reasoning Sequence', weight: '20%', desc: 'Did you follow the evidence-based order of evaluation?' },
  { key: 'diagnostic_efficiency_score', label: 'Diagnostic Efficiency', weight: '20%', desc: 'Did you avoid unnecessary tests and redundant steps?' },
  { key: 'ai_reasoning_score', label: 'Reasoning Quality', weight: '20%', desc: 'Was your clinical reasoning coherent, justified, and guideline-aligned?', max: 5 },
];

function RubricRow({ dimension, attempt }) {
  const raw = attempt?.[dimension.key] ?? attempt?.score_breakdown?.[dimension.key] ?? 0;
  const value = dimension.max ? Math.round((raw / dimension.max) * 100) : raw;
  const grade = getGrade(value);
  const cfg = GRADE_CONFIG[grade];

  return (
    <div className="flex items-center gap-4 py-3 border-b border-slate-800 last:border-0">
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-0.5">
          <p className="text-sm font-medium text-slate-200">{dimension.label}</p>
          <span className="text-xs text-slate-500 bg-slate-800 px-1.5 py-0.5 rounded">{dimension.weight}</span>
        </div>
        <p className="text-xs text-slate-500">{dimension.desc}</p>
      </div>
      <div className="flex items-center gap-3 shrink-0">
        <div className="w-24 h-1.5 bg-slate-800 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all ${value >= 85 ? 'bg-teal-500' : value >= 70 ? 'bg-cyan-500' : value >= 55 ? 'bg-amber-500' : 'bg-red-500'}`}
            style={{ width: `${Math.min(100, value)}%` }}
          />
        </div>
        <span className="text-xs font-mono text-slate-300 w-8 text-right">{value}%</span>
        <span className={`text-xs font-bold px-2 py-0.5 rounded-full border ${cfg.bg} ${cfg.color} ${cfg.border} w-8 text-center`}>{grade}</span>
      </div>
    </div>
  );
}

function ExpandableSection({ title, icon: Icon, iconColor, children, defaultOpen = false }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between px-6 py-4 hover:bg-slate-800/40 transition-colors"
      >
        <span className="flex items-center gap-2 text-sm font-semibold text-slate-300">
          <Icon className={`w-4 h-4 ${iconColor}`} />
          {title}
        </span>
        {open ? <ChevronUp className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
      </button>
      {open && <div className="px-6 pb-5">{children}</div>}
    </div>
  );
}

export default function CaseTeachingPanel({ attempt, caseData }) {
  const [teaching, setTeaching] = useState(null);
  const [loading, setLoading] = useState(false);
  const [generated, setGenerated] = useState(false);

  const score = attempt?.composite_reasoning_score || attempt?.score || 0;
  const grade = getGrade(score);
  const cfg = GRADE_CONFIG[grade];
  const bd = attempt?.score_breakdown || {};

  useEffect(() => {
    if (!attempt || !caseData || generated) return;
    generateTeaching();
  }, [attempt?.id, caseData?.id]);

  const generateTeaching = async () => {
    if (generated || loading) return;
    setLoading(true);
    setGenerated(true);

    const aiFeedback = bd.ai_reasoning_feedback
      ? (typeof bd.ai_reasoning_feedback === 'string' ? JSON.parse(bd.ai_reasoning_feedback) : bd.ai_reasoning_feedback)
      : null;

    const result = await base44.integrations.Core.InvokeLLM({
      model: 'claude_sonnet_4_6',
      prompt: `You are an expert clinical educator providing a comprehensive post-case teaching debrief grounded in the NCS 2024 Guidelines for Neuroprognostication in Critically Ill Adults with Moderate–Severe Traumatic Brain Injury (Muehlschlegel et al., Neurocrit Care 2024).

CORE GUIDELINE KNOWLEDGE YOU MUST TEACH FROM:

RELIABILITY FRAMEWORK:
- "Reliable" predictor: high certainty evidence, AUC >0.8, low false-positive rate → can say outcome is "very likely"
- "Moderately reliable" predictor: lower certainty, must use WITH other moderately reliable predictors → can say outcome is "likely" but acknowledge SUBSTANTIAL uncertainty
- "Not reliable": cannot use alone for prognosis counseling

INDIVIDUAL CLINICAL VARIABLES (when used alone):
- Bilateral pupillary nonreactivity on admission: MODERATELY RELIABLE for 6-month functional outcome (conditional on no confounders: medications, orbital trauma, DAI)
- Unilateral pupillary nonreactivity: NOT RELIABLE
- Age, GCS/motor GCS, hypotension (SBP<90), hypoxia (SpO2<90% or PaO2<110), elevated ICP (>20 mmHg), major extracranial injury, AKI, alcohol intoxication, hypernatremia, post-traumatic cerebral infarction: ALL NOT RELIABLE alone
- No biomarker met criteria for inclusion

CLINICAL PREDICTION MODELS (moderately reliable):
- CRASH-basic & CRASH-CT: moderately reliable for 14-day mortality AND 6-month functional outcome (AUC 0.8–0.89); includes age, GCS, pupils, extracranial injury ± CT features
- IMPACT-core, IMPACT-extended (core+CT), IMPACT-lab (core+CT+lab): moderately reliable for 6-month mortality AND functional outcome (AUC 0.71–0.88); most validated models in msTBI
- Marshall CT, Rotterdam CT, Helsinki CT, Stockholm CT: NOT RELIABLE
- When using prediction models: describe as "an objective estimate only, subject to considerable uncertainty"

GOOD PRACTICE STATEMENTS (strong recommendations):
1. NEVER base prognosis on a single variable — use complete clinical picture
2. Do NOT prognosticate in first 3 days (primary + secondary injuries still evolving; minimum wait = 3 days, ideally 1–2 weeks)
3. Acknowledge uncertainty explicitly; avoid nihilism

SELF-FULFILLING PROPHECY RISK: Premature WLST based on inaccurate prognosis may kill patients who would have recovered. Up to 25% of initially poor-prognosis patients may achieve meaningful recovery.

CASE: ${caseData?.title}
DIAGNOSIS: ${caseData?.diagnosis}
LEARNER SCORE: ${score}% (Grade ${grade})
CRITICAL ACTIONS COMPLETED: ${(bd.correct_actions || []).join(', ') || 'None'}
MISSED CRITICAL ACTIONS: ${(bd.missed_actions || []).join(', ') || 'None'}
COGNITIVE ERRORS: ${(attempt?.cognitive_errors || []).map(e => e.error_type).join(', ') || 'None'}
AI REASONING SCORE: ${bd.ai_reasoning_score || 0}/5
AI FEEDBACK: ${aiFeedback?.overall_feedback || 'N/A'}
BEST PRACTICE SUMMARY: ${caseData?.best_practice_summary || 'N/A'}
LEARNING OBJECTIVES: ${(caseData?.learning_objectives || []).join(', ') || 'N/A'}

Generate a structured teaching debrief grounded in these NCS 2024 guidelines with the following exact JSON schema:
{
  "key_takeaways": [
    { "title": "string (short, punchy)", "body": "string (2-3 sentences, cite specific NCS 2024 recommendations)", "priority": "high|medium|low" }
  ],
  "personalized_advice": "string (3-4 sentences directly addressing THIS learner's performance — reference their scores, errors, missed actions, and map them to specific guideline violations or adherence)",
  "concept_review": [
    { "concept": "string", "explanation": "string (2-3 sentences grounded in NCS 2024 evidence)", "guideline_ref": "string (e.g. NCS 2024 PICOT Q2, CRASH model, Good Practice Statement 1)" }
  ],
  "next_steps": ["string", "string", "string"],
  "competency_level": "novice|developing|competent|proficient|expert"
}

Rules:
- key_takeaways: 3-5 items mapping learner errors to specific NCS 2024 guideline failures
- concept_review: 2-4 items — each must cite a specific PICOT question, model, or Good Practice Statement from NCS 2024
- Be specific and clinically rigorous, not generic
- next_steps: actionable learning recommendations referencing the CRASH/IMPACT calculators or specific guideline sections`,
      response_json_schema: {
        type: 'object',
        properties: {
          key_takeaways: { type: 'array', items: { type: 'object' } },
          personalized_advice: { type: 'string' },
          concept_review: { type: 'array', items: { type: 'object' } },
          next_steps: { type: 'array', items: { type: 'string' } },
          competency_level: { type: 'string' },
        }
      }
    });

    setTeaching(result);
    setLoading(false);
  };

  const competencyColors = {
    novice: 'text-red-400 bg-red-500/10 border-red-500/30',
    developing: 'text-orange-400 bg-orange-500/10 border-orange-500/30',
    competent: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
    proficient: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30',
    expert: 'text-teal-400 bg-teal-500/10 border-teal-500/30',
  };

  const takeawayPriorityColors = {
    high: 'border-l-red-400',
    medium: 'border-l-amber-400',
    low: 'border-l-slate-500',
  };

  return (
    <div className="space-y-4">
      {/* Graded Rubric Header */}
      <div className={`bg-slate-900 border ${cfg.border} rounded-2xl p-6`}>
        <div className="flex items-start justify-between gap-4 mb-5">
          <div className="flex items-center gap-3">
            <div className={`w-14 h-14 rounded-2xl ${cfg.bg} border ${cfg.border} flex items-center justify-center`}>
              <span className={`text-3xl font-black ${cfg.color}`}>{grade}</span>
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Assessment Report</h2>
              <p className={`text-sm font-semibold ${cfg.color}`}>{cfg.label}</p>
            </div>
          </div>
          {teaching?.competency_level && (
            <span className={`text-xs font-semibold uppercase tracking-wider px-3 py-1.5 rounded-full border ${competencyColors[teaching.competency_level] || competencyColors.competent}`}>
              {teaching.competency_level}
            </span>
          )}
        </div>

        {/* Rubric dimensions */}
        <div className="bg-slate-950/50 rounded-xl p-4">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3 flex items-center gap-1.5">
            <Target className="w-3 h-3" /> Graded Rubric
          </p>
          {rubricDimensions.map(dim => (
            <RubricRow key={dim.key} dimension={dim} attempt={attempt} />
          ))}
        </div>
      </div>

      {loading && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 flex items-center justify-center gap-3">
          <Loader2 className="w-5 h-5 animate-spin text-teal-400" />
          <p className="text-slate-400 text-sm">Generating personalized teaching debrief...</p>
        </div>
      )}

      {teaching && (
        <>
          {/* Personalized Advice */}
          <div className="bg-gradient-to-br from-teal-500/10 to-cyan-500/5 border border-teal-500/25 rounded-2xl p-6">
            <div className="flex items-center gap-2 mb-3">
              <GraduationCap className="w-4 h-4 text-teal-400" />
              <h3 className="text-sm font-semibold text-teal-300 uppercase tracking-wider">Personalized Feedback</h3>
            </div>
            <p className="text-sm text-slate-200 leading-relaxed">{teaching.personalized_advice}</p>
          </div>

          {/* Key Takeaways */}
          <ExpandableSection title="Key Takeaways" icon={Lightbulb} iconColor="text-amber-400" defaultOpen={true}>
            <div className="space-y-3 pt-1">
              {(teaching.key_takeaways || []).map((t, i) => (
                <div key={i} className={`border-l-4 ${takeawayPriorityColors[t.priority] || 'border-l-slate-600'} bg-slate-800/50 rounded-r-xl pl-4 pr-4 py-3`}>
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <p className="text-sm font-semibold text-white">{t.title}</p>
                    {t.priority === 'high' && (
                      <span className="text-xs text-red-400 bg-red-500/10 border border-red-500/20 px-1.5 py-0.5 rounded shrink-0">Key</span>
                    )}
                  </div>
                  <p className="text-sm text-slate-300 leading-relaxed">{t.body}</p>
                </div>
              ))}
            </div>
          </ExpandableSection>

          {/* Concept Review */}
          <ExpandableSection title="Concept Review" icon={BookOpen} iconColor="text-violet-400" defaultOpen={true}>
            <div className="space-y-4 pt-1">
              {(teaching.concept_review || []).map((c, i) => (
                <div key={i} className="bg-slate-800/40 rounded-xl p-4">
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <p className="text-sm font-semibold text-violet-300">{c.concept}</p>
                    {c.guideline_ref && (
                      <span className="text-xs font-mono text-teal-400 bg-teal-500/10 border border-teal-500/20 px-2 py-0.5 rounded shrink-0 whitespace-nowrap">
                        {c.guideline_ref}
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-slate-300 leading-relaxed">{c.explanation}</p>
                </div>
              ))}
            </div>
          </ExpandableSection>

          {/* Next Steps */}
          <ExpandableSection title="Recommended Next Steps" icon={Star} iconColor="text-cyan-400" defaultOpen={true}>
            <div className="space-y-2 pt-1">
              {(teaching.next_steps || []).map((step, i) => (
                <div key={i} className="flex items-start gap-3 py-2">
                  <div className="w-6 h-6 rounded-full bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center shrink-0 mt-0.5">
                    <span className="text-xs font-bold text-cyan-400">{i + 1}</span>
                  </div>
                  <p className="text-sm text-slate-300 leading-relaxed">{step}</p>
                </div>
              ))}
            </div>
          </ExpandableSection>
        </>
      )}

      {/* Learning objectives */}
      {(caseData?.learning_objectives?.length > 0) && (
        <ExpandableSection title="Case Learning Objectives" icon={CheckCircle2} iconColor="text-green-400">
          <div className="space-y-2 pt-1">
            {caseData.learning_objectives.map((obj, i) => (
              <div key={i} className="flex items-start gap-3 text-sm py-1.5">
                <CheckCircle2 className="w-4 h-4 text-green-400 shrink-0 mt-0.5" />
                <span className="text-slate-300">{obj}</span>
              </div>
            ))}
          </div>
        </ExpandableSection>
      )}
    </div>
  );
}