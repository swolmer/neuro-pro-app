import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronRight, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

const TOUR_STEPS = [
  {
    title: 'Welcome to NeuroSim',
    description: 'An interactive neuroprognostication training platform. Let\'s learn how to use it.',
    position: 'center',
    action: 'Next',
  },
  {
    title: 'Click Hotspots to Explore',
    description: 'The black dots on the patient figure represent different body systems. Click any dot to reveal physical exam findings for that system.',
    position: 'patient-figure',
    action: 'Next',
  },
  {
    title: 'Your Turn: Reposition Hotspots',
    description: 'Click the "Edit" button and drag any dot to align it with the correct body region. Try it now — then click "Edit" again to finish.',
    position: 'patient-figure',
    action: 'Got It',
  },
  {
    title: 'Hover for Quick Findings',
    description: 'Hover over any system button in the top bar to quickly see key findings without opening the full drawer.',
    position: 'vitals-bar',
    action: 'Next',
  },
  {
    title: 'Ask the Team',
    description: 'Use the chat panel on the right to ask questions about exam findings and lab results. Your reasoning is evaluated to provide feedback.',
    position: 'chat-panel',
    action: 'Next',
  },
  {
    title: 'Ready to Begin',
    description: 'You now know the basics. Click "Start" to begin your first case and practice neuroprognostication.',
    position: 'center',
    action: 'Start',
  },
];

export default function ProgramTour({ onComplete }) {
  const [currentStep, setCurrentStep] = useState(0);
  const [cardPosition, setCardPosition] = useState({ top: '50%', left: '50%' });
  const [paused, setPaused] = useState(false);
  const cardRef = useRef(null);
  const step = TOUR_STEPS[currentStep];
  const isLastStep = currentStep === TOUR_STEPS.length - 1;
  const isEditStep = currentStep === 2; // "Your Turn" step

  useEffect(() => {
    if (step.position === 'center') {
      setCardPosition({ top: '50%', left: '50%', transform: 'translate(-50%, -50%)' });
    } else if (step.position === 'patient-figure') {
      setCardPosition({ bottom: '20px', left: '20px', transform: 'none' });
    } else if (step.position === 'vitals-bar') {
      setCardPosition({ bottom: '180px', left: '20px', transform: 'none' });
    } else if (step.position === 'chat-panel') {
      setCardPosition({ bottom: '20px', right: '20px', left: 'auto', transform: 'none' });
    }
  }, [step.position]);

  const handleNext = () => {
    if (isEditStep && !paused) {
      // Pause tour for edit step
      setPaused(true);
    } else if (isEditStep && paused) {
      // Resume after edit
      setPaused(false);
      setCurrentStep(currentStep + 1);
    } else if (isLastStep) {
      onComplete();
    } else {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleSkip = () => {
    onComplete();
  };

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center ${paused ? 'bg-transparent pointer-events-none' : 'bg-black/50'} pointer-events-none`}>
      {/* Spotlight effect on target */}
      {step.position !== 'center' && !paused && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
          className="absolute inset-0 pointer-events-none"
          style={{
            boxShadow: 'inset 0 0 0 9999px rgba(0, 0, 0, 0.7)',
          }}
        />
      )}

      <>
        {/* Tour card - positioned dynamically */}
        {!paused && (
        <motion.div
        ref={cardRef}
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        transition={{ duration: 0.3 }}
        className="fixed max-w-md w-full mx-4 bg-white rounded-xl shadow-2xl overflow-hidden pointer-events-auto z-50"
        style={cardPosition}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-teal-500 to-cyan-500 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-teal-100">Step {currentStep + 1} of {TOUR_STEPS.length}</p>
              <h2 className="text-2xl font-bold text-white mt-1">{step.title}</h2>
            </div>
            <button
              onClick={handleSkip}
              className="text-teal-100 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Progress bar */}
        <div className="h-1 bg-slate-200">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${((currentStep + 1) / TOUR_STEPS.length) * 100}%` }}
            transition={{ duration: 0.5 }}
            className="h-full bg-gradient-to-r from-teal-500 to-cyan-500"
          />
        </div>

        {/* Content */}
        <div className="px-6 py-6">
          <p className="text-slate-600 text-base leading-relaxed">{step.description}</p>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 flex items-center justify-between gap-3">
          <button
            onClick={handleSkip}
            className="text-sm font-medium text-slate-600 hover:text-slate-800 transition-colors"
          >
            Skip Tour
          </button>
          <Button
            onClick={handleNext}
            className="bg-teal-600 hover:bg-teal-700 text-white flex items-center gap-2 pointer-events-auto"
          >
            {step.action}
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </motion.div>
      )}

      {/* Pause overlay message for edit step */}
      {paused && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
          className="fixed right-0 top-0 bottom-0 w-1/2 flex items-center justify-center pointer-events-none z-50"
        >
          <div className="bg-white rounded-xl shadow-2xl px-6 py-8 max-w-sm pointer-events-auto text-center">
            <p className="text-slate-700 text-base font-medium mb-4">
              Go ahead —click the edit button in the upper right. And then drag the dots around! When you're done, click below to continue.
            </p>
            <Button
              onClick={handleNext}
              className="bg-teal-600 hover:bg-teal-700 text-white pointer-events-auto"
            >
              Resume Tour
            </Button>
          </div>
        </motion.div>
      )}
      </>
      </div>
      );
      }