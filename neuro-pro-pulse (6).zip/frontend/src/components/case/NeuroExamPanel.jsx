import React, { useState } from 'react';
import { Eye, Activity, Brain, Pill, ChevronDown, ChevronRight, Lock, Map } from 'lucide-react';
import DotPlacementDiagram from './DotPlacementDiagram';

const SECTIONS = [
  {
    key: 'pupils',
    label: 'Pupils',
    icon: Eye,
    color: 'text-sky-400',
    borderColor: 'border-sky-500/30',
    bgColor: 'bg-sky-500/10',
    promptHint: 'Ask: "What are the pupils?"',
    findings: [
      { label: 'Size', value: '7 mm bilaterally' },
      { label: 'Reactivity', value: 'Fixed — no response to light' },
      { label: 'Symmetry', value: 'Symmetric' },
    ],
  },
  {
    key: 'motor',
    label: 'Motor Response',
    icon: Activity,
    color: 'text-violet-400',
    borderColor: 'border-violet-500/30',
    bgColor: 'bg-violet-500/10',
    promptHint: 'Ask: "What is the motor response to noxious stimuli?"',
    findings: [
      { label: 'Spontaneous movement', value: 'None' },
      { label: 'Response to noxious', value: 'No purposeful withdrawal; extensor posturing noted' },
      { label: 'Tone', value: 'Flaccid in all extremities' },
    ],
  },
  {
    key: 'brainstem',
    label: 'Brainstem Reflexes',
    icon: Brain,
    color: 'text-teal-400',
    borderColor: 'border-teal-500/30',
    bgColor: 'bg-teal-500/10',
    promptHint: 'Ask: "What are the brainstem reflexes?"',
    findings: [
      { label: 'Corneal reflex', value: 'Absent bilaterally' },
      { label: 'Oculocephalic (Doll\'s eyes)', value: 'Absent — eyes move with head' },
      { label: 'Gag reflex', value: 'Absent' },
      { label: 'Cough reflex', value: 'Absent' },
      { label: 'Apnea test', value: 'Not yet performed' },
    ],
  },
  {
    key: 'confounders',
    label: 'Sedation / Confounders',
    icon: Pill,
    color: 'text-amber-400',
    borderColor: 'border-amber-500/30',
    bgColor: 'bg-amber-500/10',
    promptHint: 'Ask: "Is there sedation on board?"',
    findings: [
      { label: 'Current sedation', value: 'Midazolam 2 mg/hr IV (active)' },
      { label: 'Last dose', value: '~30 min ago' },
      { label: 'Metabolic screen', value: 'Pending' },
      { label: 'Hypothermia protocol', value: 'Completed 6 hrs ago, temp now 36.8°C' },
    ],
    warning: 'Active sedation may confound examination findings.',
  },
];

function ExamSection({ section, isRevealed }) {
  const [expanded, setExpanded] = useState(false);
  const Icon = section.icon;

  return (
    <div className={`rounded-xl border transition-all duration-200 ${isRevealed ? section.borderColor + ' bg-slate-900' : 'border-slate-800 bg-slate-900/40'}`}>
      <button
        onClick={() => isRevealed && setExpanded(p => !p)}
        className={`w-full flex items-center justify-between px-4 py-3 rounded-xl ${isRevealed ? 'cursor-pointer hover:bg-white/5' : 'cursor-default opacity-50'}`}
      >
        <div className="flex items-center gap-3">
          <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${isRevealed ? section.bgColor : 'bg-slate-800'}`}>
            <Icon className={`w-4 h-4 ${isRevealed ? section.color : 'text-slate-600'}`} />
          </div>
          <div className="text-left">
            <p className={`text-sm font-semibold ${isRevealed ? 'text-white' : 'text-slate-600'}`}>{section.label}</p>
            {!isRevealed && (
              <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                <Lock className="w-3 h-3" /> {section.promptHint}
              </p>
            )}
          </div>
        </div>
        {isRevealed && (
          <div className={`w-5 h-5 rounded-full flex items-center justify-center ${section.bgColor}`}>
            {expanded ? <ChevronDown className={`w-3.5 h-3.5 ${section.color}`} /> : <ChevronRight className={`w-3.5 h-3.5 ${section.color}`} />}
          </div>
        )}
      </button>

      {isRevealed && expanded && (
        <div className="px-4 pb-4 space-y-2">
          {section.warning && (
            <div className="bg-amber-950/40 border border-amber-700/40 rounded-lg px-3 py-2 mb-3">
              <p className="text-xs text-amber-300 font-medium">⚠ {section.warning}</p>
            </div>
          )}
          {section.findings.map((f, i) => (
            <div key={i} className="flex flex-col gap-0.5 bg-slate-800/60 rounded-lg px-3 py-2">
              <span className="text-xs text-slate-500 uppercase tracking-wide font-medium">{f.label}</span>
              <span className="text-sm text-slate-100">{f.value}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function NeuroExamPanel({ revealedSections = new Set(), isFacilitator = false }) {
  const totalRevealed = SECTIONS.filter(s => revealedSections.has(s.key)).length;
  const [showDiagram, setShowDiagram] = useState(false);
  const [selectedSection, setSelectedSection] = useState(null);

  return (
    <div className="flex flex-col h-full bg-slate-950 overflow-auto p-4 space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-sm font-bold text-white">Neurologic Examination</h2>
          <p className="text-xs text-slate-500 mt-0.5">Ask the ICU team to reveal findings</p>
        </div>
        <div className="flex items-center gap-1.5 bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1">
          <div className={`w-1.5 h-1.5 rounded-full ${totalRevealed > 0 ? 'bg-teal-400' : 'bg-slate-600'}`} />
          <span className="text-xs font-medium text-slate-400">{totalRevealed}/{SECTIONS.length} revealed</span>
        </div>
      </div>

      {/* Dropdown for Physical Exam Findings */}
      <div className="space-y-2">
        <select
          value={selectedSection || ''}
          onChange={(e) => setSelectedSection(e.target.value || null)}
          className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-xs font-medium focus:border-teal-500 focus:outline-none"
        >
          <option value="">Physical Exam Findings</option>
          {SECTIONS.filter(s => revealedSections.has(s.key)).map((section) => (
            <option key={section.key} value={section.key}>
              {section.label}
            </option>
          ))}
        </select>

        {selectedSection && (
          <div className="bg-slate-800/60 rounded-lg p-3 space-y-2">
            <div className="flex items-center gap-1.5 mb-2">
              {SECTIONS.find(s => s.key === selectedSection) && (
                <>
                  <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: SECTIONS.find(s => s.key === selectedSection).color }} />
                  <span className="text-xs font-semibold text-white">{SECTIONS.find(s => s.key === selectedSection).label}</span>
                </>
              )}
            </div>
            <div className="space-y-2">
              {SECTIONS.find(s => s.key === selectedSection)?.findings?.map((f, i) => (
                <div key={i} className="bg-slate-700/50 rounded px-2 py-1.5">
                  <p className="text-[9px] text-slate-500 uppercase tracking-wider mb-0.5">{f.label}</p>
                  <p className="text-xs text-slate-200">{f.value}</p>
                </div>
              )) || []}
            </div>
          </div>
        )}
      </div>

      {/* Diagram toggle (moved below dropdown) */}
      <button
        onClick={() => setShowDiagram(p => !p)}
        className="flex items-center gap-2 text-xs text-slate-400 hover:text-slate-200 bg-slate-900 border border-slate-700 hover:border-slate-600 px-3 py-2 rounded-lg transition-all w-full"
      >
        <Map className="w-3.5 h-3.5" />
        <span className="font-medium">{showDiagram ? 'Hide' : 'Show'} Anatomy Diagram</span>
        {isFacilitator && <span className="ml-auto text-[10px] bg-amber-900/50 text-amber-400 border border-amber-800/50 px-1.5 py-0.5 rounded">Facilitator: Dot Placement</span>}
        {showDiagram ? <ChevronDown className="w-3.5 h-3.5 ml-auto shrink-0" /> : <ChevronRight className="w-3.5 h-3.5 ml-auto shrink-0" />}
      </button>

      {showDiagram && (
        <DotPlacementDiagram isFacilitator={isFacilitator} />
      )}

      {/* Progress bar */}
      <div className="w-full bg-slate-800 rounded-full h-1.5">
        <div
          className="bg-teal-500 h-1.5 rounded-full transition-all duration-500"
          style={{ width: `${(totalRevealed / SECTIONS.length) * 100}%` }}
        />
      </div>

      {/* Collapsible sections for reference */}
      <div className="text-xs text-slate-600 pt-2">
        <details className="cursor-pointer">
          <summary className="font-medium text-slate-400 hover:text-slate-300">Show all exam sections</summary>
          <div className="mt-3 space-y-2">
            {SECTIONS.map(section => (
              <ExamSection
                key={section.key}
                section={section}
                isRevealed={revealedSections.has(section.key)}
              />
            ))}
          </div>
        </details>
      </div>

      {/* Footer note */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 mt-2">
        <p className="text-xs text-slate-500 leading-relaxed">
          🧠 <span className="text-slate-400 font-medium">Systematic approach:</span> Pupils → Motor → Brainstem Reflexes → Rule out confounders
        </p>
      </div>
    </div>
  );
}