import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { ChevronRight, BookOpen } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const STAGE_GUIDELINES = [
  {
    stage: 'Stage 1: History & Timeline',
    key: 'history',
    description: 'Establish the clinical context and ensure adequate timing.',
    guidelines: [
      {
        title: 'Timing is Non-Negotiable',
        detail: 'Per NCS 2023, you MUST wait ≥72 hours after ROSC (or ≥72h after rewarming if hypothermia was used). Prognostication before this threshold is unreliable and risks self-fulfilling prophecy through inappropriate withdrawal of care.',
      },
      {
        title: 'Rule Out Confounders Upfront',
        detail: 'Document sedation status, hypothermia (core temp), metabolic panel (glucose, electrolytes, renal/hepatic function), and recent seizure history. These are the gatekeepers—if present, you cannot interpret neuro exam or EEG findings.',
      },
      {
        title: 'Establish Baseline',
        detail: 'Know the patient\'s prior cognitive function, prior strokes, dementia, or neurologic disease. You assess *change from baseline*, not absolute function.',
      },
    ],
  },
  {
    stage: 'Stage 2: Physical Exam',
    key: 'exam',
    description: 'Perform detailed neurologic assessment with NCS 2023 reliability in mind.',
    guidelines: [
      {
        title: 'Pupils: A Reliable Predictor',
        detail: 'Bilateral absent pupils at ≥72h (with confounders excluded) is ONE of only TWO highly reliable predictors per NCS 2023 (FPR <5%). This is a critical finding—bilateral absence strongly suggests poor neurologic outcome.',
      },
      {
        title: 'Motor Response: Important Context, Not Sufficient Alone',
        detail: 'Document detailed motor exam (response to commands vs pain, extension vs withdrawal). While important, motor response alone is NOT reliably predictive (FPR up to 30%). Must combine with EEG, imaging, and other modalities.',
      },
      {
        title: 'Brainstem Reflexes: Supporting Evidence',
        detail: 'Assess corneal, gag, and cough reflexes. While not individually predictive, their absence when combined with other poor prognostic findings strengthens the overall assessment.',
      },
    ],
  },
  {
    stage: 'Stage 3: Ancillary Testing',
    key: 'ancillary',
    description: 'Obtain multimodal evidence per NCS 2023 framework.',
    guidelines: [
      {
        title: 'SSEP/N20: The Gold Standard Test',
        detail: 'Bilateral absent N20 cortical responses on SSEP (≥48h with valid peripheral responses confirming test validity) is the MOST reliable single predictor per NCS 2023 (FPR <3%). This test should be obtained whenever resources allow.',
      },
      {
        title: 'EEG: Moderately Reliable When Confounders Excluded',
        detail: 'Malignant patterns (suppression <10μV, burst-suppression, absent reactivity, no sleep-wake differentiation) are moderately reliable. BUT you MUST explicitly rule out active sedation first, or you will misinterpret the findings.',
      },
      {
        title: 'Imaging: Critical for Concordance',
        detail: 'CT (diffuse gray-white loss, sulcal effacement) and MRI DWI (diffuse restricted diffusion) are moderately reliable. While individually less powerful than pupils or SSEP, they add essential concordance when combined with clinical findings.',
      },
    ],
  },
  {
    stage: 'Stage 4: Prognosis & Integration',
    key: 'prognosis',
    description: 'Synthesize all evidence into a defensible prognostic statement.',
    guidelines: [
      {
        title: 'Multimodal Integration is Mandatory',
        detail: 'NCS 2023 is explicit: NO single predictor is sufficient alone. You must integrate clinical exam (pupils), electrophysiology (SSEP, EEG), imaging (CT/MRI), and confirm timing & confounders. Skipping any major modality weakens your conclusion.',
      },
      {
        title: 'Assess Concordance Across Modalities',
        detail: 'Do your findings agree? Concordant findings (e.g., absent pupils + malignant EEG + diffuse DWI) are far more predictive than isolated abnormalities. Discordant findings warrant caution and extended observation.',
      },
      {
        title: 'Always Communicate Uncertainty',
        detail: 'Even with poor-prognosis indicators, up to 25% of patients may recover meaningfully. Your prognosis statement must explicitly acknowledge uncertainty and support extended observation when evidence is incomplete.',
      },
    ],
  },
];

export default function GuidelinesTeaching({ onDone }) {
  const [currentStageIndex, setCurrentStageIndex] = useState(0);
  const [currentGuidelineIndex, setCurrentGuidelineIndex] = useState(0);

  const stage = STAGE_GUIDELINES[currentStageIndex];
  const guideline = stage.guidelines[currentGuidelineIndex];
  const isLastGuideline = currentGuidelineIndex === stage.guidelines.length - 1;
  const isLastStage = currentStageIndex === STAGE_GUIDELINES.length - 1;

  const handleNext = () => {
    if (isLastGuideline) {
      if (isLastStage) {
        onDone();
      } else {
        setCurrentStageIndex(currentStageIndex + 1);
        setCurrentGuidelineIndex(0);
      }
    } else {
      setCurrentGuidelineIndex(currentGuidelineIndex + 1);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-indigo-50 border border-indigo-200 rounded-lg p-5"
    >
      {/* Stage header */}
      <div className="flex items-start gap-3 mb-4">
        <BookOpen className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
        <div className="flex-1">
          <p className="text-sm font-bold text-indigo-900">{stage.stage}</p>
          <p className="text-xs text-indigo-700 mt-0.5">{stage.description}</p>
        </div>
      </div>

      {/* Guideline content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={`${currentStageIndex}-${currentGuidelineIndex}`}
          initial={{ opacity: 0, x: 10 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -10 }}
          transition={{ duration: 0.3 }}
          className="bg-white rounded-lg p-4 mb-4 border border-indigo-100"
        >
          <h3 className="text-sm font-semibold text-indigo-900 mb-2">{guideline.title}</h3>
          <p className="text-sm text-indigo-800 leading-relaxed">{guideline.detail}</p>
        </motion.div>
      </AnimatePresence>

      {/* Progress indicators */}
      <div className="mb-4">
        <div className="flex gap-1 mb-2">
          {stage.guidelines.map((_, idx) => (
            <div
              key={idx}
              className={`h-1.5 flex-1 rounded-full transition-colors ${
                idx <= currentGuidelineIndex ? 'bg-indigo-600' : 'bg-indigo-200'
              }`}
            />
          ))}
        </div>
        <p className="text-xs text-indigo-700 text-center">
          {currentGuidelineIndex + 1} of {stage.guidelines.length}
        </p>
      </div>

      {/* Navigation */}
      <div className="flex gap-2">
        <Button
          onClick={() => {
            if (currentStageIndex > 0 || currentGuidelineIndex > 0) {
              if (currentGuidelineIndex > 0) {
                setCurrentGuidelineIndex(currentGuidelineIndex - 1);
              } else {
                setCurrentStageIndex(currentStageIndex - 1);
                setCurrentGuidelineIndex(STAGE_GUIDELINES[currentStageIndex - 1].guidelines.length - 1);
              }
            }
          }}
          disabled={currentStageIndex === 0 && currentGuidelineIndex === 0}
          variant="outline"
          className="flex-1 border-indigo-300 text-indigo-900 hover:bg-indigo-100 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Back
        </Button>
        <Button
          onClick={handleNext}
          className="flex-1 bg-indigo-600 hover:bg-indigo-700"
        >
          {isLastStage && isLastGuideline ? (
            <>Done</>
          ) : (
            <>Next <ChevronRight className="w-4 h-4 ml-1" /></>
          )}
        </Button>
      </div>

      {/* Overall progress */}
      <p className="text-xs text-indigo-700 mt-3 text-center">
        Stage {currentStageIndex + 1} of {STAGE_GUIDELINES.length}
      </p>
    </motion.div>
  );
}