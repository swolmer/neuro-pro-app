import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Lock, Unlock, Undo2, Redo2, Grid3x3, Trash2, Plus, CheckCircle2 } from 'lucide-react';

const DOT_COLORS = {
  abnormal: { fill: '#f87171', border: '#dc2626', label: 'Abnormal' },
  absent:   { fill: '#fb923c', border: '#ea580c', label: 'Absent' },
  present:  { fill: '#34d399', border: '#059669', label: 'Present' },
  note:     { fill: '#818cf8', border: '#4f46e5', label: 'Note' },
};

const DEFAULT_DOTS = [];

function clamp(val, min, max) { return Math.max(min, Math.min(max, val)); }

// Snap to a 5% grid
function snap(val) { return Math.round(val / 5) * 5; }

export default function DotPlacementDiagram({ isFacilitator = false }) {
  const [dots, setDots] = useState(DEFAULT_DOTS);
  const [locked, setLocked] = useState(false);
  const [placementMode, setPlacementMode] = useState(false);
  const [showGrid, setShowGrid] = useState(false);
  const [snapEnabled, setSnapEnabled] = useState(false);
  const [selectedColor, setSelectedColor] = useState('abnormal');
  const [history, setHistory] = useState([[]]);
  const [historyIdx, setHistoryIdx] = useState(0);
  const [dragging, setDragging] = useState(null); // { dotId, startX, startY, origX, origY }
  const [labelEdit, setLabelEdit] = useState(null); // dotId being edited
  const containerRef = useRef(null);
  const nextId = useRef(1);

  // Push to undo history
  const pushHistory = useCallback((newDots) => {
    const newHistory = history.slice(0, historyIdx + 1);
    newHistory.push(newDots.map(d => ({ ...d })));
    setHistory(newHistory);
    setHistoryIdx(newHistory.length - 1);
  }, [history, historyIdx]);

  const undo = () => {
    if (historyIdx <= 0) return;
    const idx = historyIdx - 1;
    setDots(history[idx].map(d => ({ ...d })));
    setHistoryIdx(idx);
  };

  const redo = () => {
    if (historyIdx >= history.length - 1) return;
    const idx = historyIdx + 1;
    setDots(history[idx].map(d => ({ ...d })));
    setHistoryIdx(idx);
  };

  // Click on diagram to place dot (facilitator + placement mode + not locked)
  const handleDiagramClick = useCallback((e) => {
    if (!placementMode || locked || !isFacilitator) return;
    if (dragging) return;
    const rect = containerRef.current.getBoundingClientRect();
    let x = ((e.clientX - rect.left) / rect.width) * 100;
    let y = ((e.clientY - rect.top) / rect.height) * 100;
    x = clamp(snapEnabled ? snap(x) : Math.round(x * 10) / 10, 0, 98);
    y = clamp(snapEnabled ? snap(y) : Math.round(y * 10) / 10, 0, 98);
    const id = nextId.current++;
    const newDot = { id, x, y, color: selectedColor, label: '' };
    const newDots = [...dots, newDot];
    setDots(newDots);
    pushHistory(newDots);
  }, [placementMode, locked, isFacilitator, dragging, dots, selectedColor, snapEnabled, pushHistory]);

  // Drag start
  const handleDotMouseDown = useCallback((e, dotId) => {
    if (locked || !isFacilitator || !placementMode) return;
    e.stopPropagation();
    const dot = dots.find(d => d.id === dotId);
    if (!dot) return;
    setDragging({ dotId, startX: e.clientX, startY: e.clientY, origX: dot.x, origY: dot.y });
  }, [locked, isFacilitator, placementMode, dots]);

  const handleMouseMove = useCallback((e) => {
    if (!dragging) return;
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;
    const dx = ((e.clientX - dragging.startX) / rect.width) * 100;
    const dy = ((e.clientY - dragging.startY) / rect.height) * 100;
    let nx = clamp(dragging.origX + dx, 0, 98);
    let ny = clamp(dragging.origY + dy, 0, 98);
    if (snapEnabled) { nx = snap(nx); ny = snap(ny); }
    setDots(prev => prev.map(d => d.id === dragging.dotId ? { ...d, x: nx, y: ny } : d));
  }, [dragging, snapEnabled]);

  const handleMouseUp = useCallback(() => {
    if (!dragging) return;
    pushHistory(dots);
    setDragging(null);
  }, [dragging, dots, pushHistory]);

  useEffect(() => {
    if (dragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [dragging, handleMouseMove, handleMouseUp]);

  const removeDot = (id) => {
    const newDots = dots.filter(d => d.id !== id);
    setDots(newDots);
    pushHistory(newDots);
  };

  const handleLock = () => {
    setLocked(true);
    setPlacementMode(false);
  };

  const handleUnlock = () => {
    if (!isFacilitator) return;
    setLocked(false);
  };

  const updateLabel = (id, label) => {
    const newDots = dots.map(d => d.id === id ? { ...d, label } : d);
    setDots(newDots);
  };

  const colorMeta = DOT_COLORS[selectedColor];

  return (
    <div className="flex flex-col gap-3">

      {/* Facilitator toolbar */}
      {isFacilitator && (
        <div className="bg-slate-900 border border-slate-700 rounded-xl p-3 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-300 uppercase tracking-wide">Dot Placement</span>
            <div className="flex items-center gap-1.5">
              {locked ? (
                <button onClick={handleUnlock} title="Unlock" className="flex items-center gap-1 text-xs bg-green-900/40 border border-green-700/50 text-green-300 px-2 py-1 rounded-lg hover:bg-green-900/60 transition-all">
                  <Lock className="w-3 h-3" /> Locked
                </button>
              ) : (
                <button onClick={handleLock} disabled={dots.length === 0} className="flex items-center gap-1 text-xs bg-teal-700 hover:bg-teal-600 disabled:opacity-40 text-white px-2 py-1 rounded-lg transition-all font-semibold">
                  <Lock className="w-3 h-3" /> Lock Placement
                </button>
              )}
            </div>
          </div>

          {!locked && (
            <>
              {/* Mode toggle + tools */}
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => setPlacementMode(p => !p)}
                  className={`flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-lg border font-semibold transition-all ${placementMode ? 'bg-violet-600 border-violet-500 text-white' : 'bg-slate-800 border-slate-600 text-slate-300 hover:border-slate-500'}`}
                >
                  <Plus className="w-3.5 h-3.5" />
                  {placementMode ? 'Placement ON' : 'Placement OFF'}
                </button>

                <button onClick={() => setShowGrid(p => !p)} className={`flex items-center gap-1 text-xs px-2 py-1.5 rounded-lg border transition-all ${showGrid ? 'bg-slate-700 border-slate-500 text-white' : 'bg-slate-800 border-slate-600 text-slate-500 hover:text-slate-300'}`}>
                  <Grid3x3 className="w-3.5 h-3.5" /> Grid
                </button>
                <button onClick={() => setSnapEnabled(p => !p)} className={`text-xs px-2 py-1.5 rounded-lg border transition-all ${snapEnabled ? 'bg-slate-700 border-slate-500 text-white' : 'bg-slate-800 border-slate-600 text-slate-500 hover:text-slate-300'}`}>
                  Snap {snapEnabled ? 'ON' : 'OFF'}
                </button>
                <button onClick={undo} disabled={historyIdx <= 0} className="p-1.5 rounded-lg border border-slate-700 text-slate-500 hover:text-slate-300 disabled:opacity-30 transition-all">
                  <Undo2 className="w-3.5 h-3.5" />
                </button>
                <button onClick={redo} disabled={historyIdx >= history.length - 1} className="p-1.5 rounded-lg border border-slate-700 text-slate-500 hover:text-slate-300 disabled:opacity-30 transition-all">
                  <Redo2 className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Color picker */}
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-500">Dot type:</span>
                {Object.entries(DOT_COLORS).map(([key, meta]) => (
                  <button
                    key={key}
                    onClick={() => setSelectedColor(key)}
                    title={meta.label}
                    className={`w-5 h-5 rounded-full border-2 transition-all ${selectedColor === key ? 'scale-125 border-white' : 'border-transparent opacity-60 hover:opacity-90'}`}
                    style={{ background: meta.fill, borderColor: selectedColor === key ? meta.border : 'transparent' }}
                  />
                ))}
                <span className="text-xs text-slate-400 ml-1">{colorMeta.label}</span>
              </div>

              {placementMode && <p className="text-xs text-violet-300">Click anywhere on the diagram to place a dot. Drag to reposition.</p>}
            </>
          )}

          {locked && (
            <div className="flex items-center gap-2 bg-green-950/40 border border-green-800/40 rounded-lg px-3 py-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-green-400 shrink-0" />
              <span className="text-xs text-green-300">Dots locked — learners can view but not interact. Click "Locked" to unlock.</span>
            </div>
          )}
        </div>
      )}

      {/* Diagram canvas */}
      <div
        ref={containerRef}
        onClick={handleDiagramClick}
        className={`relative w-full rounded-xl overflow-hidden border select-none ${locked ? 'border-green-700/30 bg-slate-900' : placementMode ? 'border-violet-600/50 bg-slate-900 cursor-crosshair' : 'border-slate-700 bg-slate-900'}`}
        style={{ aspectRatio: '4/3' }}
      >
        {/* Grid overlay */}
        {showGrid && !locked && (
          <div className="absolute inset-0 pointer-events-none" style={{
            backgroundImage: 'linear-gradient(rgba(100,116,139,0.15) 1px, transparent 1px), linear-gradient(90deg, rgba(100,116,139,0.15) 1px, transparent 1px)',
            backgroundSize: '5% 5%',
          }} />
        )}

        {/* Brain anatomy SVG diagram */}
        <svg viewBox="0 0 400 300" className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          {/* Background */}
          <rect width="400" height="300" fill="#0f172a" />

          {/* Skull outline */}
          <ellipse cx="200" cy="130" rx="110" ry="100" fill="none" stroke="#334155" strokeWidth="2" />

          {/* Brain hemispheres */}
          <path d="M200 50 C140 50 100 80 95 120 C90 160 110 195 130 210 C150 225 175 230 200 230" fill="none" stroke="#475569" strokeWidth="1.5" />
          <path d="M200 50 C260 50 300 80 305 120 C310 160 290 195 270 210 C250 225 225 230 200 230" fill="none" stroke="#475569" strokeWidth="1.5" />

          {/* Corpus callosum */}
          <path d="M155 130 Q200 115 245 130" fill="none" stroke="#94a3b8" strokeWidth="1" strokeDasharray="4 3" />

          {/* Brainstem */}
          <rect x="185" y="225" width="30" height="45" rx="8" fill="none" stroke="#475569" strokeWidth="1.5" />
          <line x1="185" y1="240" x2="215" y2="240" stroke="#334155" strokeWidth="1" />
          <line x1="185" y1="250" x2="215" y2="250" stroke="#334155" strokeWidth="1" />

          {/* Cerebellum */}
          <ellipse cx="200" cy="215" rx="35" ry="22" fill="none" stroke="#475569" strokeWidth="1.5" />
          <path d="M168 215 Q185 208 200 215 Q215 222 232 215" fill="none" stroke="#334155" strokeWidth="1" />

          {/* Left eye */}
          <ellipse cx="145" cy="165" rx="18" ry="12" fill="none" stroke="#475569" strokeWidth="1.5" />
          <circle cx="145" cy="165" r="6" fill="none" stroke="#64748b" strokeWidth="1" />

          {/* Right eye */}
          <ellipse cx="255" cy="165" rx="18" ry="12" fill="none" stroke="#475569" strokeWidth="1.5" />
          <circle cx="255" cy="165" r="6" fill="none" stroke="#64748b" strokeWidth="1" />

          {/* Optic chiasm */}
          <path d="M145 177 L175 190 L200 188 L225 190 L255 177" fill="none" stroke="#334155" strokeWidth="1" strokeDasharray="3 2" />

          {/* Labels */}
          <text x="200" y="42" textAnchor="middle" fill="#64748b" fontSize="9" fontFamily="monospace">Cerebral Cortex</text>
          <text x="72" y="130" textAnchor="middle" fill="#475569" fontSize="8" fontFamily="monospace" transform="rotate(-90,72,130)">Left</text>
          <text x="328" y="130" textAnchor="middle" fill="#475569" fontSize="8" fontFamily="monospace" transform="rotate(90,328,130)">Right</text>
          <text x="200" y="258" textAnchor="middle" fill="#64748b" fontSize="8" fontFamily="monospace">Brainstem</text>
          <text x="200" y="207" textAnchor="middle" fill="#64748b" fontSize="8" fontFamily="monospace">Cerebellum</text>
          <text x="145" y="190" textAnchor="middle" fill="#475569" fontSize="8" fontFamily="monospace">L Eye</text>
          <text x="255" y="190" textAnchor="middle" fill="#475569" fontSize="8" fontFamily="monospace">R Eye</text>
          <text x="200" y="127" textAnchor="middle" fill="#475569" fontSize="7.5" fontFamily="monospace">CC</text>

          {/* Pupil reactivity region markers (subtle) */}
          <text x="145" y="154" textAnchor="middle" fill="#1e3a5f" fontSize="7" fontFamily="monospace">Pupil L</text>
          <text x="255" y="154" textAnchor="middle" fill="#1e3a5f" fontSize="7" fontFamily="monospace">Pupil R</text>
        </svg>

        {/* Dots */}
        {dots.map(dot => {
          const meta = DOT_COLORS[dot.color] || DOT_COLORS.abnormal;
          const isLocked = locked;
          return (
            <div
              key={dot.id}
              style={{ left: `${dot.x}%`, top: `${dot.y}%`, transform: 'translate(-50%,-50%)', position: 'absolute' }}
              className="group"
              onMouseDown={(e) => !isLocked && handleDotMouseDown(e, dot.id)}
            >
              {/* Dot */}
              <div
                className={`w-4 h-4 rounded-full border-2 transition-all ${isLocked ? 'opacity-90 cursor-default' : 'cursor-grab active:cursor-grabbing hover:scale-125'}`}
                style={{ background: meta.fill, borderColor: meta.border, boxShadow: `0 0 6px ${meta.fill}88` }}
              />

              {/* Label bubble */}
              {dot.label && (
                <div className="absolute left-5 top-0 whitespace-nowrap bg-slate-800 border border-slate-600 text-white text-[10px] px-1.5 py-0.5 rounded pointer-events-none z-10">
                  {dot.label}
                </div>
              )}

              {/* Facilitator controls — only in placement mode */}
              {!isLocked && isFacilitator && placementMode && (
                <div className="absolute -top-7 left-1/2 -translate-x-1/2 hidden group-hover:flex items-center gap-1 bg-slate-800 border border-slate-600 rounded-lg px-1.5 py-1 z-20 shadow-xl">
                  {labelEdit === dot.id ? (
                    <input
                      autoFocus
                      className="text-[10px] bg-slate-700 text-white border border-slate-500 rounded px-1 w-20 outline-none"
                      value={dot.label}
                      onChange={e => updateLabel(dot.id, e.target.value)}
                      onBlur={() => setLabelEdit(null)}
                      onKeyDown={e => e.key === 'Enter' && setLabelEdit(null)}
                      onClick={e => e.stopPropagation()}
                    />
                  ) : (
                    <button onClick={(e) => { e.stopPropagation(); setLabelEdit(dot.id); }} className="text-[10px] text-slate-300 hover:text-white px-1">✏</button>
                  )}
                  <button onClick={(e) => { e.stopPropagation(); removeDot(dot.id); }} className="text-[10px] text-red-400 hover:text-red-300 px-1">✕</button>
                </div>
              )}
            </div>
          );
        })}

        {/* Empty state */}
        {dots.length === 0 && isFacilitator && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="bg-slate-900/80 border border-slate-700 rounded-xl px-4 py-3 text-center">
              <p className="text-xs text-slate-400 font-medium">Enable "Placement ON" and click the diagram to place dots</p>
            </div>
          </div>
        )}

        {/* Locked badge */}
        {locked && (
          <div className="absolute top-2 right-2 flex items-center gap-1 bg-green-900/70 border border-green-700/50 rounded-lg px-2 py-1">
            <Lock className="w-3 h-3 text-green-400" />
            <span className="text-[10px] font-bold text-green-300">LOCKED</span>
          </div>
        )}
      </div>

      {/* Dot legend */}
      {dots.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {Object.entries(DOT_COLORS).filter(([key]) => dots.some(d => d.color === key)).map(([key, meta]) => (
            <div key={key} className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full" style={{ background: meta.fill }} />
              <span className="text-xs text-slate-500">{meta.label}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}