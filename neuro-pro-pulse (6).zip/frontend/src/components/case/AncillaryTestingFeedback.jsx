import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { BookOpen, ChevronDown } from 'lucide-react';

const ANCILLARY_TEACHINGS = [
  {
    action: 'Order SSEP if available (bilateral N20 assessment)',
    reason: 'Bilateral absent N20 cortical responses is the MOST reliable single predictor (FPR <3%). This test should be prioritized when resources allow.',
  },
  {
    action: 'Obtain EEG and assess for malignant patterns',
    reason: 'Suppressed background (<10μV), burst-suppression, absent reactivity, and no sleep-wake cycling are moderately reliable. BUT sedation must be ruled out first.',
  },
  {
    action: 'Perform CT brain ≥48h and assess for diffuse signs',
    reason: 'Diffuse loss of gray-white differentiation and sulcal effacement are moderately reliable. Early CT (<48h) may show less ischemic change and overestimate recovery potential.',
  },
  {
    action: 'Consider MRI DWI if not contraindicated (2-7 days post-ROSC)',
    reason: 'Diffuse restricted diffusion on DWI is moderately reliable. Timing matters—DWI changes evolve over days, so later imaging (day 3+) shows more mature infarction.',
  },
];

export default function AncillaryTestingFeedback({ orderedTests, onContinue }) {
  const [selectedItemIndex, setSelectedItemIndex] = useState(null);

  const criticalTests = ['eeg', 'ssep', 'ct_brain', 'mri_brain'];
  const missedTests = criticalTests.filter(t => !orderedTests.includes(t));

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 to-slate-900 flex flex-col">
      {/* Header */}
      <div className="border-b border-slate-800 bg-slate-950/80 backdrop-blur px-4 py-6 sm:px-6 sticky top-0 z-20">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-2 rounded-lg bg-amber-500/10">
              <BookOpen className="w-5 h-5 text-amber-400" />
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white">Stage 3 — Ancillary Testing Review</h1>
          </div>
          <p className="text-slate-400">Here's what you tested and why these assessments matter.</p>
        </div>
      </div>

      {/* Summary */}
      <div className="px-4 py-6 sm:px-6 border-b border-slate-800 bg-slate-950/40">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-start gap-3 mb-4">
            <div className="text-2xl">✓</div>
            <div>
              <p className="text-sm font-semibold text-white mb-1">Tests Ordered: {orderedTests.length}</p>
              <p className="text-xs text-slate-400">You selected {orderedTests.length} ancillary test{orderedTests.length !== 1 ? 's' : ''}.</p>
            </div>
          </div>
          {missedTests.length > 0 && (
            <div className="flex items-start gap-3 bg-amber-950/20 border border-amber-700/30 rounded-lg p-3">
              <div className="text-lg">⚠️</div>
              <div>
                <p className="text-xs font-semibold text-amber-300 mb-1">Critical Tests Not Ordered</p>
                <p className="text-xs text-amber-200">{missedTests.length} important test{missedTests.length !== 1 ? 's' : ''} were not ordered. Consider why these matter per NCS 2023.</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Teaching points */}
      <div className="flex-1 p-4 py-8 sm:p-6 overflow-y-auto">
        <div className="max-w-2xl mx-auto space-y-3">
          <p className="text-[10px] text-slate-400 uppercase tracking-wide font-semibold mb-4">Why This Matters</p>
          {ANCILLARY_TEACHINGS.map((item, index) => (
            <motion.button
              key={index}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              onClick={() => setSelectedItemIndex(selectedItemIndex === index ? null : index)}
              className={`w-full text-left px-4 sm:px-6 py-4 rounded-lg border-2 transition-all ${
                selectedItemIndex === index
                  ? 'bg-teal-600/10 border-teal-500/50'
                  : 'bg-slate-900 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <p className="text-sm font-semibold text-white leading-snug">{item.action}</p>
                <ChevronDown className={`w-4 h-4 text-slate-400 shrink-0 transition-transform ${selectedItemIndex === index ? 'rotate-180' : ''}`} />
              </div>

              <AnimatePresence>
                {selectedItemIndex === index && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mt-2 pt-2 border-t border-slate-700"
                  >
                    <div className="flex items-start gap-2">
                      <BookOpen className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
                      <p className="text-xs text-slate-300 leading-relaxed">{item.reason}</p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Footer */}
      <div className="border-t border-slate-800 bg-slate-950/80 backdrop-blur px-4 py-4 sm:px-6 shrink-0">
        <div className="max-w-4xl mx-auto">
          <Button onClick={onContinue} className="w-full bg-teal-600 hover:bg-teal-700 text-white font-semibold">
            Continue to Stage 4: Prognosis →
          </Button>
        </div>
      </div>
    </div>
  );
}