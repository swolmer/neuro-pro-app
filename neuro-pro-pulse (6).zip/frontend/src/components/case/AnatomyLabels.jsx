import React from 'react';
import { motion } from 'framer-motion';

// Anatomical positions as % of image (x, y from top-left)
const ANATOMY_LABELS = [
  { id: 'neuro', label: 'Brain', x: 50, y: 10, color: '#a855f7' },
  { id: 'cardio', label: 'Heart', x: 44, y: 36, color: '#ef4444' },
  { id: 'pulm', label: 'Lungs', x: 56, y: 28, color: '#3b82f6' },
  { id: 'hepatic', label: 'Liver', x: 58, y: 44, color: '#22c55e' },
  { id: 'renal', label: 'Kidneys', x: 38, y: 48, color: '#ec4899' },
  { id: 'gi', label: 'GI', x: 50, y: 54, color: '#94a3b8' },
  { id: 'msk', label: 'Neuro Exam', x: 50, y: 76, color: '#14b8a6' },
];

export default function AnatomyLabels({ imgRect }) {
  if (!imgRect) return null;

  return (
    <>
      {ANATOMY_LABELS.map(({ id, label, x, y, color }) => {
        // Clamp position to stay within bounds
        const clampedX = Math.max(5, Math.min(95, x));
        const clampedY = Math.max(5, Math.min(95, y));

        // Convert % within image to px offset
        const leftPx = imgRect.left + (clampedX / 100) * imgRect.width;
        const topPx = imgRect.top + (clampedY / 100) * imgRect.height;

        return (
          <div
            key={id}
            style={{
              position: 'absolute',
              left: leftPx,
              top: topPx,
              transform: 'translate(-50%, -50%)',
              pointerEvents: 'none',
              zIndex: 5,
            }}
          >
            {/* Static labeled dot */}
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.1, duration: 0.3 }}
              style={{
                width: 6,
                height: 6,
                borderRadius: '50%',
                backgroundColor: color,
                position: 'relative',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              {/* Label text positioned above or below dot depending on position */}
              <div
                style={{
                  position: 'absolute',
                  top: clampedY > 50 ? 'auto' : '100%',
                  bottom: clampedY > 50 ? '100%' : 'auto',
                  left: '50%',
                  transform: 'translateX(-50%)',
                  whiteSpace: 'nowrap',
                  fontSize: '9px',
                  fontWeight: '600',
                  color: color,
                  textShadow: '0 0 2px rgba(0,0,0,0.5)',
                  marginTop: clampedY > 50 ? -2 : 2,
                  marginBottom: clampedY > 50 ? 2 : -2,
                  pointerEvents: 'none',
                }}
              >
                {label}
              </div>
            </motion.div>
          </div>
        );
      })}
    </>
  );
}