import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { ChevronRight, CheckCircle2, MessageSquare } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

/**
 * StructuredPrompt renders either a multiple-choice question or an open-response
 * prompt based on the `type` prop. Used to guide learners at key decision points.
 *
 * Props:
 *   prompt: { type: 'mcq'|'open', question: string, options?: string[], placeholder?: string }
 *   onSelect: (answer: string) => void  — fires when learner submits
 *   onDismiss: () => void
 */
export default function StructuredPrompt({ prompt, onSelect, onDismiss, actionsPerformed = [] }) {
  const [selected, setSelected] = useState(null);
  const [openText, setOpenText] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const isOptionDone = (option) => {
    return actionsPerformed.some(a =>
      (a.action_text || a.action || '').toLowerCase().includes(
        option.toLowerCase().split(' ').slice(0, 3).join(' ')
      )
    );
  };

  if (!prompt) return null;

  const handleSubmit = () => {
    const answer = prompt.type === 'mcq' ? selected : openText.trim();
    if (!answer) return;
    setSubmitted(true);
    setTimeout(() => {
      onSelect(answer);
      setSubmitted(false);
      setSelected(null);
      setOpenText('');
    }, 400);
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -4 }}
        className="mx-4 my-3 bg-slate-800 border border-teal-500/30 rounded-2xl overflow-hidden shadow-xl"
      >
        {/* Header */}
        <div className="bg-teal-500/10 border-b border-teal-500/20 px-4 py-2.5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            {prompt.type === 'mcq'
              ? <CheckCircle2 className="w-3.5 h-3.5 text-teal-400" />
              : <MessageSquare className="w-3.5 h-3.5 text-teal-400" />
            }
            <span className="text-xs font-semibold text-teal-300 uppercase tracking-wider">
              {prompt.type === 'mcq' ? 'Choose Your Next Step' : 'Clinical Reasoning'}
            </span>
          </div>
          <button onClick={onDismiss} className="text-slate-500 hover:text-slate-300 text-xs transition-colors">
            Type freely instead
          </button>
        </div>

        {/* Question */}
        <div className="px-4 pt-3 pb-1">
          <p className="text-sm text-white font-medium leading-relaxed">{prompt.question}</p>
        </div>

        {/* MCQ Options */}
        {prompt.type === 'mcq' && (
          <div className="px-4 py-3 space-y-2">
            {prompt.options?.map((opt, i) => {
              const done = isOptionDone(opt);
              return (
              <button
                key={i}
                onClick={() => setSelected(opt)}
                className={`w-full text-left text-sm px-3.5 py-2.5 rounded-xl border transition-all ${
                  selected === opt
                    ? 'bg-teal-500/15 border-teal-500/50 text-teal-200'
                    : done
                      ? 'bg-green-500/10 border-green-500/30 text-green-300'
                      : 'bg-slate-700/50 border-slate-600/50 text-slate-300 hover:border-slate-500 hover:text-white'
                }`}
              >
                <span className="inline-block w-5 h-5 rounded-full border text-center text-xs leading-5 mr-2.5 shrink-0
                  ${selected === opt ? 'border-teal-400 bg-teal-500/20 text-teal-300' : done ? 'border-green-400 bg-green-500/20 text-green-300' : 'border-slate-500 text-slate-500'}">
                  {String.fromCharCode(65 + i)}
                </span>
                {opt} {done && <span className="text-xs text-green-400 ml-1">(ALREADY DONE)</span>}
              </button>
            );
            })}
          </div>
        )}

        {/* Open response */}
        {prompt.type === 'open' && (
          <div className="px-4 py-3">
            <textarea
              value={openText}
              onChange={e => setOpenText(e.target.value)}
              placeholder={prompt.placeholder || 'Enter your clinical reasoning...'}
              rows={3}
              className="w-full bg-slate-700 border border-slate-600 text-white text-sm rounded-xl px-3 py-2.5 placeholder:text-slate-500 focus:outline-none focus:border-teal-500 resize-none"
            />
          </div>
        )}

        {/* Submit */}
        <div className="px-4 pb-3 flex gap-2">
          <Button
            size="sm"
            disabled={submitted || (prompt.type === 'mcq' ? !selected : !openText.trim())}
            onClick={handleSubmit}
            className="bg-teal-600 hover:bg-teal-700 text-xs flex-1"
          >
            {submitted ? 'Submitting...' : (
              <><ChevronRight className="w-3.5 h-3.5 mr-1" /> Submit Response</>
            )}
          </Button>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}