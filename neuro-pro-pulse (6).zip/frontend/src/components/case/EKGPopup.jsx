import React, { useEffect, useRef, useState } from 'react';
import { X, Activity } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// ─────────────────────────────────────────────────────────────────────────────
// Beat morphology — t ∈ [0,1] over one RR interval, returns y-deflection
// ─────────────────────────────────────────────────────────────────────────────
function makeBeat({ P=0.12, Q=-0.06, R=1.0, S=-0.18, ST=0, T=0.28, Tinv=false } = {}) {
  return (t, amp) => {
    if (t < 0.08)  return amp * P * Math.sin(Math.PI * t / 0.08);
    if (t < 0.14)  return 0;
    if (t < 0.17)  return amp * Q * ((t - 0.14) / 0.03);
    if (t < 0.20)  return amp * R * ((t - 0.17) / 0.03);
    if (t < 0.23)  return amp * R * (1 - (t - 0.20) / 0.03);
    if (t < 0.26)  return amp * S * ((t - 0.23) / 0.03);
    if (t < 0.29)  return amp * S * (1 - (t - 0.26) / 0.03);
    if (t < 0.38)  return amp * ST;
    if (t < 0.60) {
      const tv = Math.sin(Math.PI * (t - 0.38) / 0.22);
      return amp * T * (Tinv ? -tv : tv);
    }
    return 0;
  };
}

const BEATS = {
  'I':   makeBeat({ P: 0.10, Q:-0.04, R: 0.90, S:-0.10, T: 0.22 }),
  'II':  makeBeat({ P: 0.14, Q:-0.06, R: 1.00, S:-0.18, T: 0.28 }),
  'III': makeBeat({ P: 0.08, Q:-0.04, R: 0.60, S:-0.24, T: 0.20 }),
  'aVR': makeBeat({ P:-0.10, Q: 0.06, R:-0.85, S: 0.14, T:-0.22, Tinv:true }),
  'aVL': makeBeat({ P: 0.06, Q:-0.03, R: 0.45, S:-0.30, T: 0.16 }),
  'aVF': makeBeat({ P: 0.12, Q:-0.05, R: 0.70, S:-0.22, T: 0.24 }),
  'V1':  makeBeat({ P: 0.06, Q: 0.00, R: 0.22, S:-0.80, T: 0.10 }),
  'V2':  makeBeat({ P: 0.08, Q:-0.04, R: 0.50, S:-0.70, T: 0.20 }),
  'V3':  makeBeat({ P: 0.10, Q:-0.05, R: 0.75, S:-0.50, T: 0.25 }),
  'V4':  makeBeat({ P: 0.12, Q:-0.06, R: 1.00, S:-0.30, T: 0.30 }),
  'V5':  makeBeat({ P: 0.12, Q:-0.06, R: 0.95, S:-0.20, T: 0.28 }),
  'V6':  makeBeat({ P: 0.10, Q:-0.05, R: 0.80, S:-0.14, T: 0.22 }),
};

// Standard 4×3 layout
const LAYOUT = [
  { lead:'I',   col:0, row:0 },
  { lead:'aVR', col:1, row:0 },
  { lead:'V1',  col:2, row:0 },
  { lead:'V4',  col:3, row:0 },
  { lead:'II',  col:0, row:1 },
  { lead:'aVL', col:1, row:1 },
  { lead:'V2',  col:2, row:1 },
  { lead:'V5',  col:3, row:1 },
  { lead:'III', col:0, row:2 },
  { lead:'aVF', col:1, row:2 },
  { lead:'V3',  col:2, row:2 },
  { lead:'V6',  col:3, row:2 },
];

// ─────────────────────────────────────────────────────────────────────────────
// Draw a single static 12-lead ECG onto a canvas
// ─────────────────────────────────────────────────────────────────────────────
function drawStaticECG(canvas) {
  const ctx = canvas.getContext('2d');
  const W = canvas.width;
  const H = canvas.height;

  const COLS = 4;
  const ROWS = 3;
  const cellW = W / COLS;
  const cellH = H / ROWS;

  // Background
  ctx.fillStyle = '#0d1a0d';
  ctx.fillRect(0, 0, W, H);

  // Minor grid (1mm)
  const MINOR = Math.max(3, Math.floor(cellW / 50));
  ctx.strokeStyle = 'rgba(220,60,60,0.12)';
  ctx.lineWidth = 0.4;
  for (let x = 0; x <= W; x += MINOR) {
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
  }
  for (let y = 0; y <= H; y += MINOR) {
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
  }

  // Major grid (5mm)
  const MAJOR = MINOR * 5;
  ctx.strokeStyle = 'rgba(220,60,60,0.28)';
  ctx.lineWidth = 0.7;
  for (let x = 0; x <= W; x += MAJOR) {
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
  }
  for (let y = 0; y <= H; y += MAJOR) {
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
  }

  // Cell borders (stronger)
  ctx.strokeStyle = 'rgba(220,60,60,0.45)';
  ctx.lineWidth = 1;
  for (let c = 1; c < COLS; c++) {
    ctx.beginPath(); ctx.moveTo(c * cellW, 0); ctx.lineTo(c * cellW, H); ctx.stroke();
  }
  for (let r = 1; r < ROWS; r++) {
    ctx.beginPath(); ctx.moveTo(0, r * cellH); ctx.lineTo(W, r * cellH); ctx.stroke();
  }

  // Calibration pulse: 1mV = 10mm tall — draw a small cal pulse at left of each cell row start
  const AMP = cellH * 0.30; // amplitude in px
  const BEATS_PER_CELL = 3;   // show 3 beats per lead cell
  const beatPx = cellW / BEATS_PER_CELL;

  LAYOUT.forEach(({ lead, col, row }) => {
    const beatFn = BEATS[lead];
    const xBase = col * cellW;
    const yBase = row * cellH;
    const mid = yBase + cellH / 2;
    const PAD = 6;

    // ── Lead label ──
    ctx.font = `bold ${Math.max(9, Math.floor(cellW / 20))}px monospace`;
    ctx.fillStyle = 'rgba(255, 210, 80, 0.92)';
    ctx.fillText(lead, xBase + PAD, yBase + 14);

    // ── Isoelectric baseline ──
    ctx.strokeStyle = 'rgba(0,180,0,0.18)';
    ctx.lineWidth = 0.5;
    ctx.setLineDash([3, 4]);
    ctx.beginPath();
    ctx.moveTo(xBase + PAD, mid);
    ctx.lineTo(xBase + cellW - PAD, mid);
    ctx.stroke();
    ctx.setLineDash([]);

    // ── 1mV calibration pulse (left edge, small) ──
    const calW = 6;
    const calH = AMP * 0.6; // ~0.6 of full amp = 6mm
    ctx.strokeStyle = 'rgba(0,220,0,0.45)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(xBase + PAD, mid);
    ctx.lineTo(xBase + PAD, mid - calH);
    ctx.lineTo(xBase + PAD + calW, mid - calH);
    ctx.lineTo(xBase + PAD + calW, mid);
    ctx.stroke();

    // ── Waveform ──
    const waveStartX = xBase + PAD + calW + 4;
    const waveW = cellW - PAD - calW - 4 - PAD;
    const POINTS = waveW * 2; // sub-pixel resolution

    ctx.beginPath();
    ctx.strokeStyle = '#00e000';
    ctx.lineWidth = 1.4;
    ctx.shadowColor = '#00ff00';
    ctx.shadowBlur = 2;

    for (let i = 0; i <= POINTS; i++) {
      const frac = i / POINTS;
      const t = (frac * BEATS_PER_CELL) % 1;
      const y = mid - beatFn(t, AMP);
      const x = waveStartX + frac * waveW;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
    ctx.shadowBlur = 0;
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// Rhythm strip — static Lead II full width
// ─────────────────────────────────────────────────────────────────────────────
function drawRhythmStrip(canvas) {
  const ctx = canvas.getContext('2d');
  const W = canvas.width;
  const H = canvas.height;
  const beatFn = BEATS['II'];
  const AMP = H * 0.34;
  const mid = H / 2;

  ctx.fillStyle = '#0d1a0d';
  ctx.fillRect(0, 0, W, H);

  // Grid
  const MINOR = 4;
  ctx.strokeStyle = 'rgba(220,60,60,0.12)';
  ctx.lineWidth = 0.4;
  for (let x = 0; x <= W; x += MINOR) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke(); }
  for (let y = 0; y <= H; y += MINOR) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke(); }
  ctx.strokeStyle = 'rgba(220,60,60,0.25)';
  ctx.lineWidth = 0.7;
  for (let x = 0; x <= W; x += 20) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke(); }
  for (let y = 0; y <= H; y += 20) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke(); }

  // Waveform — ~8 beats across full width
  const BEATS_COUNT = 8;
  const beatPx = W / BEATS_COUNT;
  ctx.beginPath();
  ctx.strokeStyle = '#00e000';
  ctx.lineWidth = 1.5;
  ctx.shadowColor = '#00ff00';
  ctx.shadowBlur = 2;
  for (let px = 0; px <= W; px++) {
    const t = ((px / beatPx) % 1);
    const y = mid - beatFn(t, AMP);
    if (px === 0) ctx.moveTo(px, y); else ctx.lineTo(px, y);
  }
  ctx.stroke();
  ctx.shadowBlur = 0;
}

// ─────────────────────────────────────────────────────────────────────────────
// Canvas components
// ─────────────────────────────────────────────────────────────────────────────
function StaticECGCanvas({ width, height }) {
  const ref = useRef(null);
  useEffect(() => {
    if (ref.current) drawStaticECG(ref.current);
  }, [width, height]);
  return <canvas ref={ref} width={width} height={height} style={{ display: 'block', imageRendering: 'crisp-edges' }} />;
}

function StaticRhythmCanvas({ width }) {
  const H = 52;
  const ref = useRef(null);
  useEffect(() => {
    if (ref.current) drawRhythmStrip(ref.current);
  }, [width]);
  return <canvas ref={ref} width={width} height={H} style={{ display: 'block', imageRendering: 'crisp-edges', width: '100%' }} />;
}

function SizedECG() {
  const ref = useRef(null);
  const [size, setSize] = React.useState(null);
  useEffect(() => {
    if (!ref.current) return;
    const ro = new ResizeObserver(e => {
      const { width, height } = e[0].contentRect;
      if (width > 0 && height > 0) setSize({ width: Math.floor(width), height: Math.floor(height) });
    });
    ro.observe(ref.current);
    return () => ro.disconnect();
  }, []);
  return (
    <div ref={ref} style={{ width: '100%', height: '100%' }}>
      {size && <StaticECGCanvas width={size.width} height={size.height} />}
    </div>
  );
}

function SizedRhythm() {
  const ref = useRef(null);
  const [width, setWidth] = React.useState(null);
  useEffect(() => {
    if (!ref.current) return;
    const ro = new ResizeObserver(e => {
      const w = e[0].contentRect.width;
      if (w > 0) setWidth(Math.floor(w));
    });
    ro.observe(ref.current);
    return () => ro.disconnect();
  }, []);
  return (
    <div ref={ref} style={{ width: '100%' }}>
      {width && <StaticRhythmCanvas width={width} />}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Popup
// ─────────────────────────────────────────────────────────────────────────────
export default function EKGPopup({ open, onClose }) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: 8 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 8 }}
          transition={{ duration: 0.18 }}
          className="absolute inset-2 z-50 rounded-xl overflow-hidden flex flex-col"
          style={{ background: '#0d1a0d', border: '1px solid rgba(0,200,0,0.28)', boxShadow: '0 0 40px rgba(0,255,0,0.07)' }}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-2 border-b shrink-0" style={{ borderColor: 'rgba(0,200,0,0.18)' }}>
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-green-400" />
              <div>
                <p className="text-xs font-bold text-green-300 leading-none">12-Lead ECG</p>
                <p className="text-[9px] text-green-700 mt-0.5">Normal Sinus Rhythm — Post-ROSC · 72 bpm · QTc 438 ms · Axis +42°</p>
              </div>
            </div>
            <div className="flex items-center gap-4 text-[9px] font-mono text-green-700">
              <span>25 mm/s</span>
              <span>10 mm/mV</span>
              <span>0.15–40 Hz</span>
              <button onClick={onClose} className="text-green-700 hover:text-green-400 ml-2 transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* 12-lead grid — static, fills space */}
          <div className="flex-1 min-h-0 w-full">
            <SizedECG />
          </div>

          {/* Rhythm strip — Lead II */}
          <div className="shrink-0 border-t" style={{ borderColor: 'rgba(0,200,0,0.15)' }}>
            <div className="px-3 pt-1 pb-0.5 flex items-center gap-3">
              <p className="text-[9px] font-mono text-yellow-600 uppercase tracking-wider">Rhythm Strip — Lead II</p>
              <span className="text-[9px] font-mono text-green-800">72 bpm · Regular</span>
            </div>
            <SizedRhythm />
          </div>

          {/* Interpretation bar */}
          <div className="px-3 py-2 shrink-0 flex flex-wrap gap-2 text-[9px] font-mono border-t" style={{ borderColor: 'rgba(0,200,0,0.12)' }}>
            {[
              ['Rhythm', 'Normal Sinus'],
              ['Rate', '72 bpm'],
              ['PR', '162 ms'],
              ['QRS', '88 ms'],
              ['QT/QTc', '372/438 ms'],
              ['P-Axis', '+52°'],
              ['QRS Axis', '+42°'],
              ['T-Axis', '+44°'],
            ].map(([k, v]) => (
              <div key={k} className="flex items-center gap-1 rounded px-2 py-1"
                style={{ background: 'rgba(0,0,0,0.3)', border: '1px solid rgba(0,180,0,0.15)' }}>
                <span className="text-green-800">{k}:</span>
                <span className="text-green-400">{v}</span>
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}