import React from 'react';
import { motion } from 'framer-motion';
import { Brain, ChevronRight, BookOpen, AlertCircle, ListChecks } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function PreBriefScreen({ onStart }) {
  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4 sm:p-6">
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: 'easeOut' }}
        className="max-w-2xl w-full"
      >
        {/* Header */}
        <div className="text-center mb-6 sm:mb-10">
          <div className="inline-flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-teal-500/10 border border-teal-500/30 mb-4 sm:mb-5">
            <Brain className="w-7 h-7 sm:w-8 sm:h-8 text-teal-400" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">Neuroprognostication Simulation</h1>
          <p className="text-slate-400 mt-2 text-sm">Read the instructions below before beginning</p>
        </div>

        <div className="space-y-4">
          {/* Objective */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
            <div className="flex items-center gap-2 mb-2">
              <BookOpen className="w-4 h-4 text-teal-400" />
              <h2 className="text-sm font-semibold text-teal-300 uppercase tracking-wider">Objective</h2>
            </div>
            <p className="text-slate-300 text-sm leading-relaxed">
              Practice structured neuroprognostication after cardiac arrest using a phased clinical reasoning approach.
            </p>
          </div>

          {/* How It Works */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
            <div className="flex items-center gap-2 mb-3">
              <ListChecks className="w-4 h-4 text-blue-400" />
              <h2 className="text-sm font-semibold text-blue-300 uppercase tracking-wider">How It Works</h2>
            </div>
            <p className="text-slate-400 text-sm mb-3">You will progress through <strong className="text-white">4 sequential stages</strong>:</p>
            <div className="grid grid-cols-2 gap-2 mb-4">
              {['History', 'Physical Exam', 'Ancillary Testing', 'Prognosis'].map((stage, i) => (
                <div key={i} className="flex flex-col items-center justify-center bg-slate-800/80 border border-slate-700/60 rounded-xl px-2 py-3 text-center gap-1.5">
                  <div className="w-6 h-6 rounded-full bg-teal-500/20 border border-teal-500/40 flex items-center justify-center">
                    <span className="text-[11px] font-bold text-teal-400">{i + 1}</span>
                  </div>
                  <div className="text-[10px] font-medium text-slate-300 leading-tight">{stage}</div>
                </div>
              ))}
            </div>
            <ul className="space-y-2">
              {[
                'You must request all information through the chatbot',
                'You will receive feedback after each stage',
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-slate-300">
                  <div className="w-1.5 h-1.5 rounded-full bg-blue-400 mt-1.5 shrink-0" />
                  {item}
                </li>
              ))}
            </ul>
          </div>

          {/* Key Rules */}
          <div className="bg-slate-900 border border-amber-500/30 rounded-xl p-5">
            <div className="flex items-center gap-2 mb-3">
              <AlertCircle className="w-4 h-4 text-amber-400" />
              <h2 className="text-sm font-semibold text-amber-300 uppercase tracking-wider">Key Rules</h2>
            </div>
            <ul className="space-y-2">
              {[
                'Do not make early prognostic conclusions',
                'Always assess for confounders (e.g., sedation, metabolic factors)',
                'Use a stepwise clinical reasoning approach',
              ].map((rule, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-slate-300">
                  <div className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5 shrink-0" />
                  {rule}
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Start Button */}
        <div className="mt-6 sm:mt-8">
          <Button
            onClick={onStart}
            size="lg"
            className="w-full bg-teal-600 hover:bg-teal-700 text-white py-4 text-base font-semibold rounded-xl gap-2"
          >
            Start Case
            <ChevronRight className="w-5 h-5" />
          </Button>
        </div>
      </motion.div>
    </div>
  );
}