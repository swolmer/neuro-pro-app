import React, { useState } from 'react';
import { ChevronDown, Beaker } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const AVAILABLE_LABS = {
  'Stage 3': [
    'EEG — electroencephalography',
    'MRI Brain — diffusion-weighted imaging (DWI)',
    'SSEP — somatosensory evoked potentials',
    'Apnea test — assess brainstem reflexes',
    'CT Head — rule out structural lesion',
    'Troponin, BNP — cardiac markers',
    'Complete blood count (CBC)',
    'Comprehensive metabolic panel (CMP)',
    'Coagulation studies (PT/INR, PTT)',
    'Lactate — tissue perfusion marker',
    'Ammonia level',
    'Toxicology screen',
  ],
};

export default function AvailableLabsPanel({ currentStage, caseData }) {
  const [isOpen, setIsOpen] = useState(false);
  const stageName = caseData?.stages?.[currentStage - 1]?.stage_name;
  const labs = AVAILABLE_LABS[stageName] || [];

  if (labs.length === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2 }}
      className="bg-indigo-50 border border-indigo-200 rounded-lg mb-4"
    >
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between px-4 py-3 hover:bg-indigo-100/50 transition-all"
      >
        <div className="flex items-center gap-2">
          <Beaker className="w-4 h-4 text-indigo-600" />
          <span className="font-semibold text-sm text-indigo-900">Available Labs & Tests</span>
        </div>
        <motion.div animate={{ rotate: isOpen ? 180 : 0 }} transition={{ duration: 0.2 }}>
          <ChevronDown className="w-4 h-4 text-indigo-600" />
        </motion.div>
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="px-4 pb-4 pt-2 border-t border-indigo-200"
          >
            <p className="text-xs text-indigo-700 mb-3">
              You can order any of these tests. Ask the team explicitly: <em>"I'd like to order [test name]"</em>
            </p>
            <div className="grid grid-cols-1 gap-2">
              {labs.map((lab, idx) => (
                <div key={idx} className="flex items-start gap-2 p-2 bg-white rounded border border-indigo-100 text-sm text-indigo-900">
                  <span className="shrink-0 text-indigo-400 font-bold">•</span>
                  <span>{lab}</span>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}