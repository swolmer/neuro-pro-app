import React, { useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

// Three photorealistic ICU patient images, one per case, generated via
// Gemini Nano Banana and matched to the case prompt's age / sex / ethnicity.
// Sources: /app/frontend/public/patients/*.png

const CASE_1_IMAGES = {
  patient: '/patients/case1_baseline_54f_black.png',
  withDoctor: '/patients/case1_baseline_54f_black.png',
};

const CASE_2_IMAGES = {
  patient: '/patients/case2_teaching_67m_hispanic.png',
  withDoctor: '/patients/case2_teaching_67m_hispanic.png',
};

const CASE_3_IMAGES = {
  patient: '/patients/case3_eval_71f_white.png',
  withDoctor: '/patients/case3_eval_71f_white.png',
};

function getCaseImages(caseId = '', caseInfo = {}) {
  const id = String(caseId || '').toLowerCase();
  const cid = String(caseInfo?.case_id || '').toUpperCase();

  if (id.includes('baseline') || cid.includes('BASELINE') || cid.includes('CA-BASELINE') || id.endsWith('001')) {
    return CASE_1_IMAGES;
  }
  if (id.includes('teach') || cid.includes('TEACH') || cid.includes('CA-TEACH') || id.endsWith('002')) {
    return CASE_2_IMAGES;
  }
  if (id.includes('eval') || cid.includes('EVAL') || cid.includes('CA-LATE') || id.endsWith('003')) {
    return CASE_3_IMAGES;
  }
  return CASE_1_IMAGES;
}

export default function PatientAvatar({ isExamPhase = false, caseId = '', caseInfo = {} }) {
  const images = useMemo(() => getCaseImages(caseId, caseInfo), [caseId, caseInfo]);
  const activeImg = isExamPhase ? images.withDoctor : images.patient;

  return (
    <div className="w-full h-full relative overflow-hidden bg-slate-800 select-none">
      <AnimatePresence mode="crossfade">
        <motion.img
          key={activeImg}
          src={activeImg}
          alt="Patient"
          className="w-full h-full object-cover"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.4 }}
        />
      </AnimatePresence>

      {/* Vignette */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{ background: 'radial-gradient(ellipse at center, transparent 70%, rgba(0,0,0,0.2) 100%)' }}
      />

      {/* Monitoring indicator */}
      <motion.div
        className="absolute top-3 left-3 flex items-center gap-1.5 bg-slate-900/70 border border-slate-700/50 rounded-full px-2 py-1"
        animate={{ opacity: [1, 0.6, 1] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <span className="w-1.5 h-1.5 rounded-full bg-green-400" />
        <span className="text-[9px] text-green-400 font-mono font-bold">MONITORING</span>
      </motion.div>
    </div>
  );
}
