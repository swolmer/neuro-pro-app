import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { Loader2, X, Zap } from 'lucide-react';

const ANCILLARY_TESTS = [
  {
    id: 'eeg',
    label: 'EEG (Electroencephalography)',
    icon: 'Zap',
    description: 'Assess brain electrical activity',
    image: 'https://media.base44.com/images/public/69b57344646fa5ad499c244d/2460e2357_generated_image.png',
    results: [
      'Suppressed background (<10 μV)',
      'Burst suppression pattern',
      'Absent reactivity to stimuli',
      'No sleep-wake differentiation'
    ]
  },
  {
    id: 'ssep',
    label: 'SSEP (Somatosensory Evoked Potentials)',
    icon: 'Zap',
    description: 'Test peripheral-to-cortical pathway',
    image: 'https://media.base44.com/images/public/69b57344646fa5ad499c244d/c902d8ab5_generated_image.png',
    results: [
      'Bilateral absent N20 wave',
      'Intact peripheral responses',
      'No cortical response'
    ]
  },
  {
    id: 'ct_brain',
    label: 'CT Brain',
    icon: 'Zap',
    description: 'Structural imaging',
    image: 'https://media.base44.com/images/public/69b57344646fa5ad499c244d/4fc5de050_generated_image.png',
    results: [
      'Diffuse loss of gray-white differentiation',
      'Sulcal effacement',
      'Diffuse cerebral edema'
    ]
  },
  {
    id: 'mri_brain',
    label: 'MRI Brain (DWI)',
    icon: 'Zap',
    description: 'Detect ischemic injury',
    image: 'https://media.base44.com/images/public/69b57344646fa5ad499c244d/8fc678d22_generated_image.png',
    results: [
      'Diffuse restricted diffusion',
      'Gray matter involvement',
      'White matter involvement',
      'Bilateral hemispheric pattern'
    ]
  },
  {
    id: 'apnea_test',
    label: 'Apnea Test',
    icon: 'Zap',
    description: 'Assess spontaneous breathing',
    image: 'https://media.base44.com/images/public/69b57344646fa5ad499c244d/f88bee79b_generated_image.png',
    results: [
      'No spontaneous breaths at PaCO₂ >60',
      'Spinal reflexes may be preserved',
      'Consistent with brainstem dysfunction'
    ]
  }
];

export default function AncillaryTests({ caseData, currentStage, onNewMessage, attemptId, messages = [] }) {
  const [selectedTest, setSelectedTest] = useState(null);

  // Detect test requests from chat messages
  React.useEffect(() => {
    if (messages.length === 0) return;
    
    const latestMessage = messages[messages.length - 1];
    if (!latestMessage || latestMessage.role !== 'assistant') return;

    const content = latestMessage.content?.toLowerCase() || '';
    
    // Check which test was mentioned
    let detectedTest = null;
    if (content.includes('eeg')) {
      detectedTest = ANCILLARY_TESTS.find(t => t.id === 'eeg');
    } else if (content.includes('ssep')) {
      detectedTest = ANCILLARY_TESTS.find(t => t.id === 'ssep');
    } else if (content.includes('ct brain') || content.includes('ct imaging')) {
      detectedTest = ANCILLARY_TESTS.find(t => t.id === 'ct_brain');
    } else if (content.includes('mri') || content.includes('dwi')) {
      detectedTest = ANCILLARY_TESTS.find(t => t.id === 'mri_brain');
    } else if (content.includes('apnea')) {
      detectedTest = ANCILLARY_TESTS.find(t => t.id === 'apnea_test');
    }

    if (detectedTest) {
      setSelectedTest(detectedTest);
    }
  }, [messages]);

  const handleRequestTest = (test) => {
    setSelectedTest(test);
    onNewMessage({
      role: 'assistant',
      content: `📊 **${test.label}** results are ready:\n\n${test.results.map(r => `• ${r}`).join('\n')}`,
      timestamp: new Date().toISOString()
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-800/60 border border-slate-700 rounded-lg p-4 space-y-3"
    >
      {/* Only show test image if one has been requested */}
      {selectedTest && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="space-y-2"
        >
          <div className="relative bg-slate-900 border border-slate-700 rounded-lg overflow-hidden">
            <img
              src={selectedTest.image}
              alt={`${selectedTest.label} results`}
              className="w-full h-auto max-h-96 object-cover"
            />
            <button
              onClick={() => setSelectedTest(null)}
              className="absolute top-2 right-2 p-1.5 bg-slate-900/80 hover:bg-slate-800 rounded-lg border border-slate-700 text-slate-400 hover:text-white transition-all"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="bg-slate-900/60 rounded-lg p-3 space-y-2">
            <p className="text-xs font-semibold text-slate-200">{selectedTest.label}</p>
            <ul className="space-y-1">
              {selectedTest.results.map((result, i) => (
                <li key={i} className="text-[10px] text-slate-400 flex items-start gap-2">
                  <span className="text-teal-400 mt-0.5">•</span>
                  <span>{result}</span>
                </li>
              ))}
            </ul>
          </div>
        </motion.div>
      )}
    </motion.div>
  );
}