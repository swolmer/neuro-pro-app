import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { Badge } from '@/components/ui/badge';
import { Stethoscope, X, Activity, Wind, ClipboardList } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import LabsPanel from './LabsPanel.jsx';
import EKGPopup from './EKGPopup.jsx';
import VentilatorPopup from './VentilatorPopup.jsx';
import AncillaryTests from './AncillaryTests.jsx';
import SystemTooltip from './SystemTooltip.jsx';
import AnatomyLabels from './AnatomyLabels.jsx';

// ── Region triggers ────────────────────────────────────────────────────────────
const REGION_TRIGGERS = {
  // Neuro
  pupil: 'neuro', corneal: 'neuro', eye: 'neuro', oculocephalic: 'neuro', doll: 'neuro',
  pupillary: 'neuro', cornea: 'neuro', gcs: 'neuro', eeg: 'neuro', ssep: 'neuro',
  mri: 'neuro', ct: 'neuro', neuroimaging: 'neuro', brainstem: 'neuro', brain: 'neuro',
  // Cardio
  heart: 'cardio', hemodynamic: 'cardio', vasopressor: 'cardio', cardiac: 'cardio',
  // Pulm
  cough: 'pulm', breath: 'pulm', apnea: 'pulm', lung: 'pulm', respiratory: 'pulm',
  vent: 'pulm', spo2: 'pulm',
  // Hepatic
  liver: 'hepatic', hepatic: 'hepatic', bilirubin: 'hepatic', ast: 'hepatic', alt: 'hepatic',
  // Renal
  kidney: 'renal', renal: 'renal', creatinine: 'renal', urine: 'renal', foley: 'renal',
  // GI / Bowel
  bowel: 'gi', intestin: 'gi', gi: 'gi', stool: 'gi', rectal: 'gi', abdomen: 'gi', ng: 'gi', distend: 'gi', guarding: 'gi',
  // MSK / Motor
  motor: 'msk', posturing: 'msk', extremit: 'msk', limb: 'msk', myoclonus: 'msk',
  reflex: 'msk', dtrs: 'msk', patellar: 'msk', babinski: 'msk', leg: 'msk', tone: 'msk',
};

// ── Systems ────────────────────────────────────────────────────────────────────
const SYSTEMS = {
  neuro: {
    label: 'Neuro',
    systemName: 'Neurologic',
    color: '#a855f7',
    finding: 'Severe Traumatic Brain Injury',
    examFindings: [
      { label: 'GCS', value: '3 (E1V1M1) — 6 hours post-injury' },
      { label: 'Pupils', value: '5mm bilaterally, sluggish reaction' },
      { label: 'Corneal reflex', value: 'Present but diminished' },
      { label: 'Oculocephalic', value: "Intact — normal doll's eyes" },
      { label: 'Motor response', value: 'No purposeful movement' },
      { label: 'CT Head', value: 'Diffuse axonal injury, bilateral temporal contusions, traumatic SAH' },
      { label: 'Imaging findings', value: 'Midline shift ~5mm, loss of basal cisterns' },
    ],
  },
  cardio: {
    label: 'Cardio',
    systemName: 'Cardiovascular',
    color: '#ef4444',
    finding: 'Hypertensive, on Vasopressor Support',
    examFindings: [
      { label: 'HR', value: '94 bpm — sinus tachycardia' },
      { label: 'BP', value: '158/92 mmHg (MAP 114)' },
      { label: 'Vasopressors', value: 'Norepinephrine 0.15 mcg/kg/min' },
      { label: 'Heart sounds', value: 'Regular, no murmur' },
      { label: 'Peripheral pulses', value: '2+ bilaterally' },
      { label: 'Troponin I', value: '0.8 ng/mL (normal)' },
    ],
  },
  pulm: {
    label: 'Pulm',
    systemName: 'Pulmonary',
    color: '#3b82f6',
    finding: 'Intubated & Mechanically Ventilated',
    examFindings: [
      { label: 'Ventilator', value: 'AC/VC — FiO₂ 50%, PEEP 8' },
      { label: 'Breath sounds', value: 'Clear bilaterally, equal air entry' },
      { label: 'SpO₂', value: '99% on vent' },
      { label: 'PaO₂', value: '156 mmHg' },
      { label: 'PaCO₂', value: '36 mmHg' },
      { label: 'Cough reflex', value: 'Present to suctioning' },
      { label: 'Gag reflex', value: 'Present but diminished' },
    ],
  },
  hepatic: {
    label: 'Hepatic',
    systemName: 'Hepatic',
    color: '#22c55e',
    finding: 'Coagulation Abnormalities Post-Trauma',
    examFindings: [
      { label: 'AST', value: '124 U/L ↑ (ref <40)' },
      { label: 'ALT', value: '98 U/L ↑ (ref <35)' },
      { label: 'Total Bilirubin', value: '0.9 mg/dL (normal)' },
      { label: 'Albumin', value: '3.1 g/dL (low)' },
      { label: 'INR', value: '1.6 ↑ (coagulopathy from trauma)' },
    ],
  },

  renal: {
    label: 'Renal',
    systemName: 'Renal',
    color: '#ec4899',
    finding: 'Acute Kidney Injury — Stage I',
    examFindings: [
      { label: 'Creatinine', value: '1.4 mg/dL ↑ (baseline likely ~1.0)' },
      { label: 'BUN', value: '24 mg/dL' },
      { label: 'UO', value: '0.8 mL/kg/hr (oliguria)' },
      { label: 'Foley catheter', value: 'In place, dark yellow urine' },
      { label: 'eGFR', value: '50-60 — early AKI' },
    ],
  },
  gi: {
    label: 'GI / Bowel',
    systemName: 'GI / Bowel',
    color: '#94a3b8',
    finding: 'No Obstruction — Sedated',
    examFindings: [
      { label: 'Abdomen', value: 'Soft, non-distended, no guarding' },
      { label: 'Bowel sounds', value: 'Hypoactive' },
      { label: 'NG tube', value: 'In place, on continuous feeds (TF held post-intubation)' },
      { label: 'Stool', value: 'None yet post-admission' },
    ],
  },
  msk: {
    label: 'MSK',
    systemName: 'Musculoskeletal',
    color: '#14b8a6',
    finding: 'Sedated — Minimal Spontaneous Activity',
    examFindings: [
      { label: 'Tone', value: 'Normal on sedation (propofol + fentanyl drips)' },
      { label: 'Upper extremities', value: 'No spontaneous movement — sedated' },
      { label: 'Lower extremities', value: 'No spontaneous movement — sedated' },
      { label: 'Patellar reflex', value: 'Present but diminished' },
      { label: 'Achilles reflex', value: 'Present but diminished' },
      { label: 'Babinski', value: 'Downgoing bilaterally' },
      { label: 'Myoclonus', value: 'None observed' },
    ],
  },
};

// ── Hotspot dot positions — % of the IMAGE itself, not the container ──────────
// Tuned for the patient illustration. x=left%, y=top% within the image.
const HOTSPOT_POSITIONS = {
  neuro:   { x: 50,  y: 10  },  // Brain label
  cardio:  { x: 44,  y: 36  },  // Heart label
  pulm:    { x: 56,  y: 28  },  // Lungs label
  hepatic: { x: 58,  y: 44  },  // Liver label
  renal:   { x: 38,  y: 48  },  // Kidneys label
  gi:      { x: 50,  y: 54  },  // GI label
  msk:     { x: 50,  y: 76  },  // Neuro Exam label
};

// ── ECG line ──────────────────────────────────────────────────────────────────
function ECGLine() {
  return (
    <svg viewBox="0 0 200 30" className="w-full h-6" preserveAspectRatio="none">
      <motion.path
        d="M0,15 L18,15 L22,15 L26,3 L30,27 L34,15 L50,15 L54,8 L58,22 L62,15 L80,15 L84,3 L88,27 L92,15 L110,15 L114,8 L118,22 L122,15 L140,15 L144,3 L148,27 L152,15 L200,15"
        fill="none" stroke="#34d399" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"
        initial={{ pathLength: 0, opacity: 0 }}
        animate={{ pathLength: 1, opacity: 1 }}
        transition={{ duration: 2.2, ease: 'linear', repeat: Infinity, repeatDelay: 0.2 }}
      />
    </svg>
  );
}

// ── Vitals bar ────────────────────────────────────────────────────────────────
function VitalsBar({ onOpenEKG, onOpenVent, onOpenLabs, labsOpen }) {
  return (
    <div className="bg-slate-900/80 border border-slate-800/50 rounded-lg px-1 py-0.5 sm:px-2 sm:py-2 font-mono text-xs sm:text-sm">
      <div className="flex items-center gap-0.5 mb-0.5 sm:mb-1">
        <div className="w-1 h-1 rounded-full bg-green-400 animate-pulse shrink-0" />
        <div className="flex items-center gap-0.5 ml-auto">
          <motion.button onClick={onOpenEKG} whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.95 }}
            title="ECG"
            className="p-0.5 sm:p-1.5 rounded-md text-green-500/60 hover:text-green-400 hover:bg-green-500/10 transition-all">
            <Activity className="w-2.5 h-2.5 sm:w-3.5 sm:h-3.5" />
          </motion.button>
          <motion.button onClick={onOpenVent} whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.95 }}
            title="Ventilator"
            className="p-0.5 sm:p-1.5 rounded-md text-sky-500/60 hover:text-sky-400 hover:bg-sky-500/10 transition-all">
            <Wind className="w-2.5 h-2.5 sm:w-3.5 sm:h-3.5" />
          </motion.button>
          <motion.button onClick={onOpenLabs} whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.95 }}
            title="Labs"
            className={`p-0.5 sm:p-1.5 rounded-md transition-all ${labsOpen ? 'text-indigo-300 bg-indigo-500/20' : 'text-indigo-500/60 hover:text-indigo-400 hover:bg-indigo-500/10'}`}>
            <ClipboardList className="w-2.5 h-2.5 sm:w-3.5 sm:h-3.5" />
          </motion.button>
        </div>
      </div>
      <div className="grid grid-cols-5 gap-0.5 sm:gap-1">
        {[
          { label: 'HR',    value: '94',     unit: 'bpm',  color: 'text-amber-400' },
          { label: 'SpO₂',  value: '99',     unit: '%',    color: 'text-cyan-400' },
          { label: 'MAP',   value: '114',    unit: 'mmHg', color: 'text-red-400' },
          { label: 'BP',    value: '158/92', unit: 'mmHg', color: 'text-red-400' },
          { label: 'TEMP',  value: '37.2',   unit: '°C',   color: 'text-orange-400' },
        ].map(({ label, value, unit, color }) => (
          <div key={label} className="bg-slate-900 rounded px-0.5 py-0.5 sm:rounded sm:py-1 sm:px-1 text-center">
            <p className="text-[10px] sm:text-[11px] text-slate-500 mb-1 uppercase tracking-tight font-semibold">{label}</p>
            <motion.p className={`font-bold text-[14px] sm:text-base leading-tight ${color}`}
              animate={{ opacity: [1, 0.75, 1] }} transition={{ duration: 1.5, repeat: Infinity }}>
              {value}
            </motion.p>
            <p className="text-[8px] sm:text-[9px] text-slate-600 mt-0.5">{unit}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Physical exam only filter ─────────────────────────────────────────────────
const PHYSICAL_EXAM_KEYWORDS = ['pupil', 'corneal', 'reflex', 'tone', 'movement', 'sounds', 'breath', 'heart', 'puls', 'extremit', 'postur', 'babinski', 'doll', 'eye', 'abdomen', 'distend', 'guarding', 'ng', 'foley', 'catheter', 'urine', 'bowel', 'stool', 'cough', 'apnea', 'ventilat'];

function isPhysicalExamFinding(label) {
  const labelLower = label.toLowerCase();
  return PHYSICAL_EXAM_KEYWORDS.some(keyword => labelLower.includes(keyword));
}

// ── Body Systems Sidebar ──────────────────────────────────────────────────
const BodySystemsSidebar = React.memo(function BodySystemsSidebar({ selectedRegion, revealedRegions, onSelectRegion }) {
  const systemList = useMemo(() => Object.keys(SYSTEMS).map(key => ({ key, ...SYSTEMS[key] })), []);
  
  return (
    <motion.div
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.3 }}
      className="w-48 bg-slate-900 border-r border-slate-800 flex flex-col overflow-hidden"
    >
      <div className="px-3 py-2 border-b border-slate-800">
        <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Body Systems</p>
      </div>
      <div className="flex-1 overflow-y-auto space-y-1 p-2">
        {systemList.map(({ key, label, color }) => {
          const isRevealed = revealedRegions.has(key);
          const isSelected = selectedRegion === key;
          return (
            <motion.button
              key={key}
              onClick={() => onSelectRegion(isSelected ? null : key)}
              whileHover={{ x: 2 }}
              className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                isSelected
                  ? 'bg-slate-700 text-white ring-1'
                  : 'bg-slate-800/60 text-slate-200 hover:bg-slate-800'
              }`}
            >
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: color }} />
                <span>{label}</span>
                {!isRevealed && <span className="text-[10px] text-slate-500 ml-auto">🔒</span>}
              </div>
            </motion.button>
          );
        })}
      </div>
    </motion.div>
  );
});

BodySystemsSidebar.displayName = 'BodySystemsSidebar';

// ── Exam drawer ───────────────────────────────────────────────────────────────
const ExamDrawer = React.memo(({ region, revealedRegions, onClose, clinicalData }) => {
  const sys = SYSTEMS[region];
  // Always call useMemo unconditionally (Rules of Hooks)
  const physicalExamFindings = useMemo(() => sys?.examFindings?.filter(({ label }) => isPhysicalExamFinding(label)) || [], [sys]);

  if (!sys) return null;
  const revealed = revealedRegions.has(region);

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      className="absolute top-0 right-0 h-full w-64 z-30 flex flex-col"
      style={{ background: 'rgba(10,16,36,0.97)', borderLeft: `2px solid ${sys.color}44` }}
    >
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800">
        <div>
          <p className="text-xs font-bold text-white">{sys.systemName}</p>
          <p className="text-[10px] text-slate-500 mt-0.5">Physical Exam</p>
        </div>
        <button onClick={onClose} className="text-slate-500 hover:text-white transition-colors">
          <X className="w-4 h-4" />
        </button>
      </div>

      {revealed ? (
        <div className="flex-1 overflow-auto px-4 py-3 space-y-2">
          <div className="flex items-center gap-1.5 mb-3">
            <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: sys.color }} />
            <span className="text-xs font-semibold" style={{ color: sys.color }}>{sys.finding}</span>
          </div>
          {physicalExamFindings.length > 0 ? (
            physicalExamFindings.map(({ label, value }) => (
              <div key={label} className="bg-slate-800/60 rounded-lg px-3 py-2">
                <p className="text-[9px] text-slate-500 uppercase tracking-wider mb-0.5">{label}</p>
                <p className="text-xs text-slate-200 leading-snug">{value}</p>
              </div>
            ))
          ) : (
            <p className="text-xs text-slate-500 italic">No physical exam findings for this system.</p>
          )}
        </div>
      ) : (
        <div className="flex-1 flex flex-col items-center justify-center px-4 py-6 text-center gap-3">
          <div className="w-10 h-10 rounded-full border-2 border-dashed border-slate-700 flex items-center justify-center">
            <Stethoscope className="w-4 h-4 text-slate-600" />
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            Ask the ICU team about <span className="text-white font-medium">{sys.systemName}</span> to reveal findings.
          </p>
          <p className="text-[10px] text-slate-600 italic">e.g. "What are the {sys.systemName.toLowerCase()} findings?"</p>
        </div>
      )}
    </motion.div>
  );
});

ExamDrawer.displayName = 'ExamDrawer';

import PatientAvatar from './PatientAvatar.jsx';

// ── Main PatientPanel ─────────────────────────────────────────────────────────
export default function PatientPanel({ caseData, currentStage, attempt, isAdmin, tourCompleted, currentPhase = 'data', onNewMessage, attemptId, messages = [], caseId = '' }) {
  const stage = caseData?.stages?.[currentStage - 1];
  const allActions = attempt?.actionsPerformed || [];


  const [revealedRegions, setRevealedRegions] = useState(new Set());
  const [selectedRegion, setSelectedRegion] = useState(null);
  const [labsOpen, setLabsOpen] = useState(false);
  const [ekgOpen, setEkgOpen] = useState(false);
  const [ventOpen, setVentOpen] = useState(false);


  useEffect(() => {
    const regions = new Set();
    
    // During exam phase, unlock all systems
    const isExamPhase = currentStage === 2;
    if (isExamPhase) {
      Object.keys(SYSTEMS).forEach(key => regions.add(key));
    } else {
      // If tour just completed, auto-reveal systems from stage clinical_data
      if (tourCompleted && stage?.clinical_data) {
        const clinicalDataStr = JSON.stringify(stage.clinical_data).toLowerCase();
        Object.entries(REGION_TRIGGERS).forEach(([keyword, region]) => {
          if (clinicalDataStr.includes(keyword)) regions.add(region);
        });
      }
      
      // Also reveal from user actions
      allActions.forEach(action => {
        const text = (action.action_text || action.action || '').toLowerCase();
        Object.entries(REGION_TRIGGERS).forEach(([keyword, region]) => {
          if (text.includes(keyword)) regions.add(region);
        });
      });
    }
    setRevealedRegions(regions);
  }, [allActions, tourCompleted, stage, currentStage]);

  const handleRegionSelect = useCallback((region) => {
    setLabsOpen(false); setEkgOpen(false); setVentOpen(false);
    setSelectedRegion(prev => prev === region ? null : region);
  }, []);

  const handleLabsClick = useCallback(() => {
    setEkgOpen(false); setVentOpen(false);
    setLabsOpen(v => !v);
  }, []);

  const handleEkgOpen = useCallback(() => {
    setLabsOpen(false); setVentOpen(false);
    setEkgOpen(v => !v);
  }, []);

  const handleVentOpen = useCallback(() => {
    setLabsOpen(false); setEkgOpen(false);
    setVentOpen(v => !v);
  }, []);

  const isExamPhase = currentStage === 2;

  return (
    <div className="h-full flex flex-col bg-slate-950 overflow-hidden text-xs sm:text-sm">
      {/* Patient figure + sidebar layout */}
      <div className="relative flex-1 min-h-0 flex overflow-hidden">
        {/* Left sidebar - body systems (exam phase only) */}
        {isExamPhase && (
          <BodySystemsSidebar 
            selectedRegion={selectedRegion} 
            revealedRegions={revealedRegions}
            onSelectRegion={(region) => {
              setLabsOpen(false); setEkgOpen(false); setVentOpen(false);
              setSelectedRegion(selectedRegion === region ? null : region);
            }}
          />
        )}

        {/* Main patient image area */}
        <div className="relative flex-1 min-h-0 px-0 sm:px-2 py-0 sm:py-1 flex flex-col items-center justify-center">
          {/* Image container */}
          <div className="flex-1 w-full min-h-0 relative">
            <PatientAvatar isExamPhase={isExamPhase} caseId={caseId || caseData?.case_id} />

            {/* Interactive Hotspots with Findings Popover */}
            {selectedRegion && revealedRegions.has(selectedRegion) && SYSTEMS[selectedRegion] && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="absolute bottom-1 left-1 right-1 z-30 bg-slate-800/95 border border-slate-700 rounded-lg p-3 space-y-2"
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: SYSTEMS[selectedRegion].color }} />
                    <span className="text-xs font-semibold text-white">{SYSTEMS[selectedRegion].systemName}</span>
                  </div>
                  <button onClick={() => setSelectedRegion(null)} className="text-slate-500 hover:text-white transition-colors">
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
                <div className="text-[10px] text-slate-400 mb-2">{SYSTEMS[selectedRegion].finding}</div>
                <div className="space-y-1.5 max-h-32 overflow-auto">
                  {SYSTEMS[selectedRegion].examFindings
                    ?.filter(({ label }) => isPhysicalExamFinding(label))
                    .map(({ label, value }) => (
                      <div key={label} className="bg-slate-700/50 rounded px-2 py-1">
                        <p className="text-[8px] text-slate-500 uppercase tracking-wider mb-0.5">{label}</p>
                        <p className="text-xs text-slate-200">{value}</p>
                      </div>
                    )) || []}
                </div>
              </motion.div>
            )}



            <LabsPanel open={labsOpen} onClose={() => setLabsOpen(false)} />
            <EKGPopup open={ekgOpen} onClose={() => setEkgOpen(false)} />
            <VentilatorPopup open={ventOpen} onClose={() => setVentOpen(false)} />
            </div>
            </div>
            </div>

      {/* Bedside monitor & ancillary tests */}
      <div className="px-0.5 pb-0.5 sm:px-2 sm:pb-1 shrink-0 space-y-1">
        <VitalsBar onOpenEKG={handleEkgOpen} onOpenVent={handleVentOpen} onOpenLabs={handleLabsClick} labsOpen={labsOpen} />
        {onNewMessage && attemptId && stage?.stage_name?.toLowerCase().includes('test') && <AncillaryTests caseData={caseData} currentStage={currentStage} onNewMessage={onNewMessage} attemptId={attemptId} messages={messages} />}
      </div>
    </div>
  );
}