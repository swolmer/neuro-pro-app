import React from 'react';
import { Button } from '@/components/ui/button';
import { ChevronRight } from 'lucide-react';
import { motion } from 'framer-motion';

export default function CompletionPrompt({ onComplete, isLoading }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
      className="fixed inset-0 bg-black/60 flex items-center justify-center z-40 p-4"
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.3, delay: 0.1 }}
        className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-8 text-center"
      >
        <h2 className="text-2xl font-bold text-slate-900 mb-3">
          Case Assessment Complete
        </h2>
        <p className="text-slate-600 mb-8 leading-relaxed">
          You've completed all stages. Review your clinical reasoning and performance metrics.
        </p>
        <Button
          onClick={onComplete}
          disabled={isLoading}
          className="w-full bg-teal-600 hover:bg-teal-700 text-white text-base font-semibold py-3 h-auto"
        >
          {isLoading ? 'Generating Feedback...' : 'View Feedback'} 
          {!isLoading && <ChevronRight className="w-5 h-5 ml-2" />}
        </Button>
      </motion.div>
    </motion.div>
  );
}