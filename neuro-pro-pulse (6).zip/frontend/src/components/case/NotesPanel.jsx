import React, { useState } from 'react';
import { NotebookPen, ChevronDown, ChevronUp } from 'lucide-react';

export default function NotesPanel({ notes, onNotesChange }) {
  const [open, setOpen] = useState(false);

  return (
    <div className="border-t border-slate-800 shrink-0 bg-slate-950">
      <button
        onClick={() => setOpen(v => !v)}
        className="w-full flex items-center justify-between px-3 py-1.5 text-xs text-slate-500 hover:text-slate-300 transition-colors"
      >
        <div className="flex items-center gap-1.5">
          <NotebookPen className="w-3 h-3" />
          <span>My Notes</span>
          {notes && <span className="w-1.5 h-1.5 rounded-full bg-teal-400 shrink-0" />}
        </div>
        {open ? <ChevronDown className="w-3 h-3" /> : <ChevronUp className="w-3 h-3" />}
      </button>

      {open && (
        <div className="px-2 pb-2">
          <textarea
            value={notes}
            onChange={e => onNotesChange(e.target.value)}
            placeholder="Jot down key findings, hypotheses, or reminders… (saved across stages)"
            className="w-full h-28 bg-slate-900 border border-slate-700 rounded-lg text-xs text-slate-200 placeholder:text-slate-600 p-2.5 resize-none focus:outline-none focus:border-teal-500 leading-relaxed"
          />
        </div>
      )}
    </div>
  );
}