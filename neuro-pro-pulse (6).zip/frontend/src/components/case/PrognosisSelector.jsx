import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { CheckCircle2, Loader2, Lightbulb, BookOpen, ChevronDown } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const PROGNOSIS_OPTIONS = [
  { id: 'poor_outcome_high_confidence',    label: 'Poor Outcome — High Confidence',    color: 'red',    definition: 'Multiple concordant moderately reliable predictors present (e.g. bilateral absent pupils + bilateral absent N20 on SSEP + malignant EEG). Low false-positive risk. Extended observation may still be warranted.' },
  { id: 'poor_outcome_moderate_confidence', label: 'Poor Outcome — Moderate Confidence', color: 'orange', definition: 'Some moderately reliable predictors present but findings are not fully concordant or evidence is incomplete. Explicit uncertainty required. Consider extended observation.' },
  { id: 'indeterminate',                   label: 'Indeterminate',                      color: 'amber',  definition: 'Evidence is insufficient or conflicting. Cannot reliably predict outcome. Extended observation (≥1–2 weeks per NCS 2024) is strongly recommended.' },
  { id: 'favorable_possible',              label: 'Favorable Outcome Possible',         color: 'green',  definition: 'Absence of poor prognostic indicators, or presence of signs suggesting potential for meaningful recovery. Continued aggressive support recommended.' },
];

const colorMap = {
  red:    { border: 'border-red-500',    bg: 'bg-red-500/10',    text: 'text-red-400',    ring: 'ring-red-500'    },
  orange: { border: 'border-orange-500', bg: 'bg-orange-500/10', text: 'text-orange-400', ring: 'ring-orange-500' },
  amber:  { border: 'border-amber-500',  bg: 'bg-amber-500/10',  text: 'text-amber-400',  ring: 'ring-amber-500'  },
  green:  { border: 'border-green-500',  bg: 'bg-green-500/10',  text: 'text-green-400',  ring: 'ring-green-500'  },
};

const PROGNOSIS_TEACHINGS = [
  {
    action: 'Integrate findings: clinical exam + EEG + imaging + SSEP',
    reason: 'NCS 2023 is explicit: NO single predictor is sufficient. Multimodal approach required. Concordance across modalities is far more reliable than isolated findings.',
  },
  {
    action: 'Assess concordance—do findings agree across modalities?',
    reason: 'Concordant poor findings = higher confidence. Discordant findings (e.g., absent pupils but reactive EEG) = greater uncertainty and warrant extended observation.',
  },
  {
    action: 'Communicate explicit uncertainty in prognosis statement',
    reason: 'Even with multiple poor prognostic indicators, up to 25% of patients may recover meaningfully. Families deserve honesty: "likely but not certain poor outcome."',
  },
  {
    action: 'Recommend extended observation (≥7-14 days) if evidence incomplete',
    reason: 'Late recovery is documented. If multimodal assessment is incomplete or discordant, NCS 2023 supports extended observation before family discussions about WLST.',
  },
];

export default function PrognosisSelector({ caseData, orderedTests, testResults, actionsPerformed, onComplete, attemptId }) {
  const navigate = useNavigate();
  // Pull the prognosis/synthesis stage data from caseData
  const prognosisStage = caseData?.stages?.find(s =>
    /synthesis|prognosis/i.test(s.stage_name) || s.stage_number === 4
  );
  const criticalActions = prognosisStage?.critical_actions || [];
  const [selected, setSelected] = useState(null);
  const [justification, setJustification] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedback, setFeedback] = useState(null);
  const [showHint, setShowHint] = useState(false);
  const [selectedTeachingIndex, setSelectedTeachingIndex] = useState(null);

  const handleSubmit = async () => {
    if (!selected || !justification.trim()) return;
    setIsSubmitting(true);

    const option = PROGNOSIS_OPTIONS.find(o => o.id === selected);

    const prompt = `You are an expert neurologist evaluating a trainee's prognostic determination in a neuroprognostication simulation (NCS 2024 guidelines).

CASE: ${caseData?.title}
DIAGNOSIS: ${caseData?.diagnosis || 'Anoxic brain injury post-cardiac arrest'}
BEST PRACTICE SUMMARY: ${caseData?.best_practice_summary || ''}

CRITICAL ACTIONS FOR THIS STAGE:
${criticalActions.map(a => `- ${a}`).join('\n') || 'N/A'}

TESTS ORDERED: ${orderedTests.join(', ') || 'None'}
TEST RESULTS:
${Object.entries(testResults || {}).map(([k, v]) => `- ${k}: ${v}`).join('\n') || 'None'}

TRAINEE SELECTED: "${option?.label}" (${option?.id})
TRAINEE JUSTIFICATION: "${justification}"

Per NCS 2024 guidelines:
- "Poor Outcome — High Confidence": requires multiple concordant moderately reliable predictors (e.g. bilateral absent pupils + bilateral absent N20 SSEP + malignant EEG). Still requires explicit uncertainty.
- "Poor Outcome — Moderate Confidence": some moderately reliable predictors but incomplete/discordant evidence. Considerable uncertainty must be stated.
- "Indeterminate": insufficient or conflicting evidence; extended observation ≥1–2 weeks recommended.
- "Favorable Outcome Possible": no reliable poor prognostic indicators or signs of potential meaningful recovery.

Key NCS 2024 principles:
- NO single predictor is sufficient alone; multimodal approach required.
- Bilateral absent pupils are MODERATELY reliable (not "reliable") — must have corroborating evidence.
- Bilateral absent N20 on SSEP is the most reliable individual predictor.
- Malignant EEG (suppressed/burst-suppression/absent reactivity) is moderately reliable.
- CT/MRI findings are moderately reliable if concordant.
- Early prognostication (<72h post-ROSC or <3 days post-TBI) is NOT valid.
- All prognoses must be communicated with explicit uncertainty. Up to 25% of patients with initially poor signs may recover meaningfully.

Evaluate whether the trainee's selected category and justification align with NCS 2024.

Return JSON (use ONLY these exact id values for correct_answer):
{
  "correct": true/false,
  "correct_answer": "poor_outcome_high_confidence|poor_outcome_moderate_confidence|indeterminate|favorable_possible",
  "why_correct": "1-2 sentences explaining WHY that category is correct based on the evidence in this case",
  "feedback": "2-3 sentence specific feedback on their choice and reasoning",
  "key_teaching_point": "1 sentence core NCS 2024 principle they should remember"
}`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      model: 'claude_sonnet_4_6',
      response_json_schema: {
        type: 'object',
        properties: {
          correct: { type: 'boolean' },
          correct_answer: { type: 'string', enum: ['poor_outcome_high_confidence', 'poor_outcome_moderate_confidence', 'indeterminate', 'favorable_possible'] },
          why_correct: { type: 'string' },
          feedback: { type: 'string' },
          key_teaching_point: { type: 'string' },
        },
        required: ['correct', 'correct_answer', 'why_correct', 'feedback', 'key_teaching_point'],
      },
    });

    setFeedback(result);
    setIsSubmitting(false);
  };

  if (feedback) {
     const correct = feedback.correct;
     const correctAnswer = feedback.correct_answer || 'indeterminate'; // Fallback to indeterminate if undefined
     const correctOption = PROGNOSIS_OPTIONS.find(o => o.id === correctAnswer);

    return (
      <div className="h-full flex flex-col overflow-hidden bg-slate-950">
        <div className="px-3 py-2.5 border-b border-slate-800 bg-slate-950 shrink-0">
          <p className="text-xs font-semibold text-slate-300">Stage 4 — Prognosis Feedback</p>
        </div>
        <div className="flex-1 overflow-y-auto p-3 space-y-3 min-h-0">
          {/* Result - Both Answers */}
          {/* Verdict banner */}
          <div className={`rounded-xl border p-4 flex items-center gap-3 ${correct ? 'bg-green-950/30 border-green-600/50' : 'bg-red-950/30 border-red-600/50'}`}>
            <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${correct ? 'bg-green-500/20' : 'bg-red-500/20'}`}>
              <span className="text-xl">{correct ? '✓' : '✗'}</span>
            </div>
            <div>
              <p className={`text-base font-bold ${correct ? 'text-green-300' : 'text-red-300'}`}>
                {correct ? 'Correct!' : 'Incorrect'}
              </p>
              <p className="text-xs text-slate-400 mt-0.5">
                {correct
                  ? `"${PROGNOSIS_OPTIONS.find(o => o.id === selected)?.label}" — well reasoned.`
                  : `You selected "${PROGNOSIS_OPTIONS.find(o => o.id === selected)?.label}". The correct answer was "${correctOption?.label}".`}
              </p>
            </div>
          </div>

          <div className="space-y-2">
            {/* Correct Answer explanation */}
            {correctOption && (
              <div className="rounded-xl border border-green-700/50 bg-green-950/20 p-3">
                <p className="text-[10px] font-bold text-green-400 uppercase tracking-wide mb-1.5">Correct Answer — {correctOption.label}</p>
                {feedback.why_correct && (
                  <p className="text-xs text-slate-200 leading-relaxed">{feedback.why_correct}</p>
                )}
              </div>
            )}
            {/* Feedback on their reasoning */}
            {!correct && feedback.feedback && (
              <div className="rounded-xl border border-red-700/40 bg-red-950/10 p-3">
                <p className="text-[10px] font-bold text-red-400 uppercase tracking-wide mb-1.5">Feedback</p>
                <p className="text-xs text-slate-300 leading-relaxed">{feedback.feedback}</p>
              </div>
            )}
          </div>



  

          {/* Teaching point */}
          {feedback.key_teaching_point && (
            <div className="bg-teal-950/20 border border-teal-700/40 rounded-xl p-3">
              <p className="text-[10px] font-bold text-teal-400 uppercase tracking-wide mb-1">Key Teaching Point</p>
              <p className="text-xs text-slate-300 leading-relaxed">{feedback.key_teaching_point}</p>
            </div>
          )}

           {/* Their justification */}
           <div className="bg-slate-800/40 rounded-xl p-3">
             <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1">Your Justification</p>
             <p className="text-xs text-slate-400 leading-relaxed italic">"{justification}"</p>
           </div>
        </div>
        <div className="p-3 border-t border-slate-800 shrink-0 bg-slate-950 relative z-50">
          <button onClick={onComplete} className="w-full px-4 py-2 rounded bg-teal-600 hover:bg-teal-700 text-white text-sm font-semibold transition cursor-pointer" type="button">
            Continue →
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col overflow-hidden">
      {/* Header */}
      <div className="px-3 py-2.5 border-b border-slate-800 bg-slate-950 shrink-0">
        <div className="flex items-center justify-between gap-2">
          <div className="flex-1">
            <p className="text-xs font-semibold text-slate-300">Stage 4 — Determine Prognosis</p>
            <p className="text-[10px] text-slate-500 mt-0.5">Select the most appropriate prognostic category per NCS 2024, then justify your reasoning.</p>
          </div>
          <button
            onClick={() => setShowHint(!showHint)}
            className="p-1.5 rounded-lg text-slate-600 hover:text-amber-400 hover:bg-amber-500/10 transition-all shrink-0"
            title="Show correct answer"
          >
            <Lightbulb className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {/* Hint banner */}
        {showHint && (
          <div className="bg-amber-950/20 border border-amber-700/40 rounded-xl p-3 mb-2">
            <p className="text-[10px] font-bold text-amber-400 uppercase tracking-wide mb-1.5">💡 Case Guidance</p>
            <p className="text-xs text-slate-200 leading-relaxed">{caseData?.best_practice_summary || 'Review the case evidence to determine the appropriate prognostic category.'}</p>
          </div>
        )}

        {/* Options */}
        <p className="text-[10px] text-slate-400 uppercase tracking-wide font-semibold mb-1">Select Prognosis</p>
        {PROGNOSIS_OPTIONS.map(option => {
          const c = colorMap[option.color];
          const isSelected = selected === option.id;
          return (
            <motion.button
              key={option.id}
              onClick={() => setSelected(option.id)}
              whileTap={{ scale: 0.98 }}
              className={`w-full text-left rounded-xl border-2 px-3 py-2.5 transition-all ${
                isSelected ? `${c.bg} ${c.border} ring-1 ${c.ring}` : 'bg-slate-900 border-slate-700 hover:border-slate-600'
              }`}
            >
              <div className="flex items-center gap-2">
                <div className={`w-3.5 h-3.5 rounded-full border-2 shrink-0 flex items-center justify-center ${isSelected ? `${c.border} ${c.bg}` : 'border-slate-600'}`}>
                  {isSelected && <div className={`w-1.5 h-1.5 rounded-full ${c.bg.replace('/10', '')} bg-current ${c.text}`} />}
                </div>
                <span className={`text-sm font-semibold ${isSelected ? c.text : 'text-slate-300'}`}>{option.label}</span>
              </div>
            </motion.button>
          );
        })}

        {/* Justification */}
        <AnimatePresence>
          {selected && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-2 space-y-2"
            >
              <p className="text-[10px] text-slate-400 uppercase tracking-wide font-semibold">Justify Your Reasoning</p>
              <p className="text-[10px] text-slate-500 leading-relaxed">
                Reference the specific predictors you used, address confounders and timing, and explain why your evidence supports this category.
              </p>
              <Textarea
                value={justification}
                onChange={e => setJustification(e.target.value)}
                placeholder="e.g. I selected 'Poor Outcome — High Confidence' because bilateral absent N20 on SSEP combined with bilateral absent pupils at ≥72h post-ROSC (both moderately reliable per NCS 2024) are concordant. Confounders ruled out — no active sedation, normothermia, no metabolic derangements. Malignant EEG (burst-suppression) adds further concordance. However, up to 25% of patients with poor initial signs may still recover, so explicit uncertainty must be communicated..."
                className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-600 resize-none text-xs min-h-[100px]"
                rows={5}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="p-3 border-t border-slate-800 shrink-0 bg-slate-950 relative z-50">
        <button
          onClick={handleSubmit}
          disabled={!selected || !justification.trim() || isSubmitting}
          className="w-full px-4 py-2 rounded bg-teal-600 hover:bg-teal-700 disabled:opacity-50 disabled:cursor-not-allowed text-white text-sm font-semibold transition cursor-pointer flex items-center justify-center gap-2"
          type="button"
        >
          {isSubmitting ? (
            <><Loader2 className="w-4 h-4 animate-spin" /> Evaluating…</>
          ) : (
            'Submit Prognosis'
          )}
        </button>
      </div>
    </div>
  );
}