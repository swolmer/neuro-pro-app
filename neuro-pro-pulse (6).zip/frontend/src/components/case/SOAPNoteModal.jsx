import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { X, FileText, Save } from 'lucide-react';
import { motion } from 'framer-motion';

export default function SOAPNoteModal({ 
  isOpen, 
  caseData, 
  currentStage, 
  actionsPerformed,
  onSubmit, 
  onClose 
}) {
  const [soapNote, setSoapNote] = useState({
    subjective: '',
    objective: '',
    assessment: '',
    plan: '',
  });

  if (!isOpen || !caseData) return null;

  const handleChange = (section, value) => {
    setSoapNote(prev => ({ ...prev, [section]: value }));
  };

  const handleSubmit = () => {
    onSubmit(soapNote);
  };

  const criticalActions = caseData.stages?.flatMap(s => s.critical_actions || []) || [];
  const completedActions = actionsPerformed.filter(a => a.is_critical || a.action_type === 'critical');

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        transition={{ duration: 0.2 }}
        className="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 bg-gradient-to-r from-slate-900 to-slate-800 text-white px-6 py-4 flex items-center justify-between border-b border-slate-700">
          <div className="flex items-center gap-3">
            <FileText className="w-6 h-6" />
            <div>
              <h2 className="text-xl font-bold">Clinical Documentation</h2>
              <p className="text-xs text-slate-300 mt-1">{caseData.title}</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-300 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Case Summary Reference */}
          <div className="bg-slate-50 border border-slate-200 rounded-lg p-4">
            <p className="text-xs font-semibold text-slate-700 mb-2 uppercase tracking-wide">Case Summary</p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
              <div>
                <p className="text-slate-600">Patient Presentation</p>
                <p className="text-slate-900 font-medium mt-1 line-clamp-2">{caseData.patient_summary}</p>
              </div>
              <div>
                <p className="text-slate-600">Diagnosis</p>
                <p className="text-slate-900 font-medium mt-1">{caseData.diagnosis}</p>
              </div>
              <div>
                <p className="text-slate-600">Actions Completed</p>
                <p className="text-slate-900 font-medium mt-1">{completedActions.length} of {criticalActions.length} critical</p>
              </div>
            </div>
          </div>

          {/* Subjective */}
          <div className="border-l-4 border-blue-500 pl-4">
            <label className="block mb-2">
              <span className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-blue-100 text-blue-700 text-xs font-bold">S</span>
                Subjective
              </span>
              <p className="text-xs text-slate-500 mt-1">Chief complaint, history of present illness, family concerns, patient/family wishes</p>
            </label>
            <Textarea
              value={soapNote.subjective}
              onChange={(e) => handleChange('subjective', e.target.value)}
              placeholder="Patient presented to the ICU with... The family reports... Key concerns include... The patient's wishes regarding..."
              className="bg-white border-slate-300 text-slate-900 placeholder:text-slate-400 text-sm resize-none"
              rows={5}
            />
          </div>

          {/* Objective */}
          <div className="border-l-4 border-green-500 pl-4">
            <label className="block mb-2">
              <span className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-green-100 text-green-700 text-xs font-bold">O</span>
                Objective
              </span>
              <p className="text-xs text-slate-500 mt-1">Vital signs, physical exam findings, imaging & lab results, diagnostic testing</p>
            </label>
            <Textarea
              value={soapNote.objective}
              onChange={(e) => handleChange('objective', e.target.value)}
              placeholder="Vitals: HR __, BP __, SpO2 __. Physical exam: Pupils are... Reflexes are... Imaging findings include... Laboratory values show... EEG demonstrates..."
              className="bg-white border-slate-300 text-slate-900 placeholder:text-slate-400 text-sm resize-none"
              rows={5}
            />
          </div>

          {/* Assessment */}
          <div className="border-l-4 border-purple-500 pl-4">
            <label className="block mb-2">
              <span className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-purple-100 text-purple-700 text-xs font-bold">A</span>
                Assessment
              </span>
              <p className="text-xs text-slate-500 mt-1">Clinical impression, diagnosis, clinical reasoning, differential diagnosis considered</p>
            </label>
            <Textarea
              value={soapNote.assessment}
              onChange={(e) => handleChange('assessment', e.target.value)}
              placeholder="This patient presents with a clinical picture consistent with... The examination findings are consistent with... The imaging and lab work support... Differential diagnosis includes... The most likely diagnosis is..."
              className="bg-white border-slate-300 text-slate-900 placeholder:text-slate-400 text-sm resize-none"
              rows={5}
            />
          </div>

          {/* Plan */}
          <div className="border-l-4 border-orange-500 pl-4">
            <label className="block mb-2">
              <span className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-orange-100 text-orange-700 text-xs font-bold">P</span>
                Plan
              </span>
              <p className="text-xs text-slate-500 mt-1">Next steps, recommendations, follow-up, family discussions, code status, goals of care</p>
            </label>
            <Textarea
              value={soapNote.plan}
              onChange={(e) => handleChange('plan', e.target.value)}
              placeholder="Recommend... Next diagnostic step is... Will discuss with family regarding... Code status should be... Goals of care discussion should focus on... Follow-up with primary team to..."
              className="bg-white border-slate-300 text-slate-900 placeholder:text-slate-400 text-sm resize-none"
              rows={5}
            />
          </div>

          {/* Completed Actions Reference */}
          {completedActions.length > 0 && (
            <div className="bg-teal-50 border border-teal-200 rounded-lg p-4">
              <p className="text-xs font-semibold text-teal-900 mb-2 uppercase tracking-wide">Your Clinical Actions</p>
              <div className="flex flex-wrap gap-2">
                {completedActions.slice(0, 8).map((action, idx) => (
                  <span key={idx} className="inline-flex items-center gap-1 bg-teal-100 text-teal-800 text-xs px-2.5 py-1.5 rounded-full font-medium">
                    ✓ {(action.action || action.action_text).substring(0, 30)}...
                  </span>
                ))}
                {completedActions.length > 8 && (
                  <span className="text-xs text-teal-700 italic">+{completedActions.length - 8} more</span>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 bg-slate-50 border-t border-slate-200 px-6 py-4 flex gap-3 justify-end">
          <Button
            onClick={onClose}
            variant="outline"
            className="border-slate-300 text-slate-700 hover:bg-slate-100"
          >
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={!soapNote.subjective || !soapNote.objective || !soapNote.assessment || !soapNote.plan}
            className="bg-slate-900 hover:bg-slate-800 text-white flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            Save SOAP Note
          </Button>
        </div>
      </motion.div>
    </motion.div>
  );
}