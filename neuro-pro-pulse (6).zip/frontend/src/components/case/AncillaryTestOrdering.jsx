import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, Send, X, CheckCircle2, AlertCircle } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const ANCILLARY_TESTS = [
  {
    id: 'eeg',
    keywords: ['eeg', 'electroencephalog'],
    fullLabel: 'EEG (Electroencephalography)',
    image: 'https://media.base44.com/images/public/69b57344646fa5ad499c244d/2460e2357_generated_image.png',
    results: ['Suppressed background (<10 μV)', 'Burst suppression pattern', 'Absent reactivity to stimuli', 'No sleep-wake differentiation'],
    relevance: 'critical',
    reasoning: 'Per NCS 2023, EEG patterns including suppressed background and absent reactivity are moderately reliable predictors of poor outcome when assessed ≥72h post-ROSC.',
  },
  {
    id: 'ssep',
    keywords: ['ssep', 'somatosensory', 'evoked potential'],
    fullLabel: 'SSEP (Somatosensory Evoked Potentials)',
    image: 'https://media.base44.com/images/public/69b57344646fa5ad499c244d/c902d8ab5_generated_image.png',
    results: ['Bilateral absent N20 wave', 'Intact peripheral responses', 'No cortical response bilaterally'],
    relevance: 'critical',
    reasoning: 'Bilateral absence of N20 cortical responses on SSEP is a highly reliable predictor of poor neurological outcome per NCS 2023 (FPR <5% when technically valid).',
  },
  {
    id: 'ct_brain',
    keywords: ['ct brain', 'ct head', 'computed tomography', 'cat scan'],
    fullLabel: 'CT Brain (without contrast)',
    image: 'https://media.base44.com/images/public/69b57344646fa5ad499c244d/4fc5de050_generated_image.png',
    results: ['Diffuse loss of gray-white differentiation', 'Sulcal effacement throughout', 'Diffuse cerebral edema'],
    relevance: 'critical',
    reasoning: 'CT brain showing diffuse loss of gray-white differentiation is a moderately reliable predictor of poor outcome per NCS 2023.',
  },
  {
    id: 'mri_brain',
    keywords: ['mri', 'magnetic resonance', 'dwi', 'diffusion'],
    fullLabel: 'MRI Brain (DWI)',
    image: 'https://media.base44.com/images/public/69b57344646fa5ad499c244d/8fc678d22_generated_image.png',
    results: ['Diffuse restricted diffusion on DWI', 'Bilateral gray matter involvement', 'White matter involvement', 'Bilateral hemispheric pattern'],
    relevance: 'critical',
    reasoning: 'MRI DWI showing diffuse restricted diffusion is a moderately reliable predictor of poor outcome per NCS 2023.',
  },
  {
    id: 'apnea_test',
    keywords: ['apnea'],
    fullLabel: 'Apnea Test (Brain Death Evaluation)',
    image: 'https://media.base44.com/images/public/69b57344646fa5ad499c244d/f88bee79b_generated_image.png',
    results: ['No spontaneous breaths at PaCO₂ >60 mmHg', 'Spinal reflexes may be preserved', 'Consistent with brainstem dysfunction'],
    relevance: 'appropriate',
    reasoning: 'Apnea testing is part of brain death determination per AAN guidelines. Not a standalone prognostic tool in the NCS 2023 neuroprognostication framework.',
  },
];

const NOT_RECOMMENDED_KEYWORDS = {
  'ohca': 'The OHCA score has poor reliability per NCS 2023 and should not be used as a standalone prognostic tool.',
  'cahp': 'The CAHP score has limited validation and is not recommended as a primary prognostic tool per NCS 2023.',
  'gofar': 'The GOFAR score is miscalibrated per NCS 2023 — not recommended for neuroprognostication.',
  'troponin': 'Troponin is a cardiac biomarker and is not a neurological prognostic marker per NCS 2023.',
  'chest x': 'Chest X-ray is not relevant to neuroprognostication per NCS 2023 guidelines.',
  'cxr': 'Chest X-ray is not relevant to neuroprognostication per NCS 2023 guidelines.',
  'gfap': 'GFAP alone is not a validated standalone predictor per NCS 2023.',
  'nse': 'NSE has high variability and hemolysis artifacts — not recommended as a standalone predictor per NCS 2023.',
};

function matchTest(input) {
  const lower = input.toLowerCase();
  return ANCILLARY_TESTS.find(t => t.keywords.some(k => lower.includes(k))) || null;
}

function matchNotRecommended(input) {
  const lower = input.toLowerCase();
  for (const [key, reason] of Object.entries(NOT_RECOMMENDED_KEYWORDS)) {
    if (lower.includes(key)) return reason;
  }
  return null;
}

// ── Result Modal ───────────────────────────────────────────────────────────────
function TestResultModal({ test, onClose }) {
  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.92, opacity: 0, y: 16 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.92, opacity: 0, y: 16 }}
        transition={{ type: 'spring', damping: 22, stiffness: 300 }}
        className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden max-h-[90vh] flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div>
            <p className="text-xs text-teal-400 font-bold uppercase tracking-widest">{test.fullLabel}</p>
            <p className={`text-xs font-semibold mt-0.5 ${test.relevance === 'critical' ? 'text-green-400' : 'text-amber-400'}`}>
              {test.relevance === 'critical' ? '✓ Critical NCS 2023 Test' : '● Supportive Test'}
            </p>
          </div>
          <button onClick={onClose} className="text-slate-500 hover:text-white transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto">
          <img src={test.image} alt={test.fullLabel} className="w-full" />
          <div className="px-5 py-4 space-y-3">
            <div>
              <p className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold mb-2">Findings</p>
              <ul className="space-y-1.5">
                {test.results.map((r, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-slate-200">
                    <span className="text-teal-400 mt-0.5 shrink-0">•</span>
                    <span>{r}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-slate-800/40 rounded-xl px-4 py-3 border border-slate-700/40">
              <p className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold mb-1">Clinical Educator Note</p>
              <p className="text-xs text-slate-400 leading-relaxed">{test.reasoning}</p>
            </div>
          </div>
        </div>
        <div className="px-5 pb-4 shrink-0">
          <Button onClick={onClose} className="w-full bg-slate-700 hover:bg-slate-600 text-white text-sm">Close</Button>
        </div>
      </motion.div>
    </motion.div>
  );
}

// ── Main Component ─────────────────────────────────────────────────────────────
export default function AncillaryTestOrdering({ caseData, orderedTests, onOrderTest, onAllDone, onTestRelevanceFeedback }) {
  const [messages, setMessages] = useState([
    { role: 'assistant', content: 'You are now in the Ancillary Testing phase. Type the name of any test you would like to order.' }
  ]);
  const [input, setInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [orderedSet, setOrderedSet] = useState(new Set());
  const [viewingTest, setViewingTest] = useState(null);
  const [showConfirm, setShowConfirm] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  const handleSend = async () => {
    const text = input.trim();
    if (!text || isProcessing) return;
    setInput('');
    setIsProcessing(true);

    const userMsg = { role: 'user', content: text };
    setMessages(prev => [...prev, userMsg, { role: 'assistant', content: '...', isLoading: true }]);

    // Small delay to feel natural
    await new Promise(r => setTimeout(r, 400));

    const matched = matchTest(text);
    const notRecommendedReason = !matched ? matchNotRecommended(text) : null;

    let reply;

    if (matched) {
      if (orderedSet.has(matched.id)) {
        reply = { role: 'assistant', content: `${matched.fullLabel} has already been ordered. Tap "View Results" to review the findings.`, testId: matched.id };
      } else {
        const newSet = new Set(orderedSet);
        newSet.add(matched.id);
        setOrderedSet(newSet);
        onOrderTest(matched.id, matched.results.join('\n'));
        if (onTestRelevanceFeedback) {
          onTestRelevanceFeedback(matched.id, { relevance: matched.relevance, reasoning: matched.reasoning });
        }
        const relevanceNote = matched.relevance === 'critical'
          ? '✅ This is a critical NCS 2023 prognostic test.'
          : '📋 This is a supportive test per NCS 2023.';
        reply = { role: 'assistant', content: `**${matched.fullLabel}** ordered. ${relevanceNote}`, testId: matched.id };
      }
    } else if (notRecommendedReason) {
      reply = { role: 'assistant', content: `⚠️ **Not Recommended per NCS 2023**\n\n${notRecommendedReason}`, isWarning: true };
    } else {
      // Unknown test — ask LLM if it's a real medical test
      try {
        const result = await base44.integrations.Core.InvokeLLM({
          prompt: `A trainee in a neuroprognostication simulation ordered: "${text}". Is this a real medical test/lab/procedure? If yes, briefly explain in 1-2 sentences whether it is useful for neuroprognostication per NCS 2023 guidelines and why or why not. If it is not a real medical test, say so. Be concise and educational.`,
          model: 'claude_sonnet_4_6',
        });
        reply = { role: 'assistant', content: result };
      } catch {
        reply = { role: 'assistant', content: `"${text}" is not recognized in the test library. Try: EEG, SSEP, CT brain, MRI brain, or Apnea Test.` };
      }
    }

    setMessages(prev => {
      const updated = [...prev];
      updated[updated.length - 1] = reply;
      return updated;
    });
    setIsProcessing(false);
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); }
  };

  const orderedCount = orderedSet.size;
  const orderedList = ANCILLARY_TESTS.filter(t => orderedSet.has(t.id));

  return (
    <div className="h-full flex flex-col overflow-hidden bg-slate-950">
      {/* Header */}
      <div className="px-4 py-3 border-b border-slate-800 shrink-0">
        <p className="text-xs font-semibold text-slate-300">Stage 3 — Ancillary Testing</p>
        <p className="text-[10px] text-slate-500 mt-0.5">{orderedCount} test{orderedCount !== 1 ? 's' : ''} ordered</p>
      </div>

      {/* Ordered tests chips */}
      {orderedList.length > 0 && (
        <div className="px-4 py-2 border-b border-slate-800 shrink-0 flex flex-wrap gap-1.5">
          {orderedList.map(t => (
            <button
              key={t.id}
              onClick={() => setViewingTest(t)}
              className="flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-semibold border bg-teal-900/30 border-teal-700/50 text-teal-300 hover:bg-teal-900/50 transition-all"
            >
              <CheckCircle2 className="w-2.5 h-2.5" />
              {t.fullLabel.split(' (')[0]} · View Results
            </button>
          ))}
        </div>
      )}

      {/* Chat messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3 min-h-0">
        {messages.map((m, i) => (
          <div key={i} className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'}`}>
            {m.role === 'user' ? (
              <div className="bg-teal-600 text-white rounded-2xl rounded-tr-sm px-3 py-2 text-xs max-w-[80%]">{m.content}</div>
            ) : m.isLoading ? (
              <div className="flex items-center gap-2 text-slate-500 text-xs bg-slate-800 rounded-2xl rounded-tl-sm px-3 py-2">
                <Loader2 className="w-3 h-3 animate-spin" /> Processing…
              </div>
            ) : (
              <div className="space-y-1.5 max-w-[90%]">
                <div className={`rounded-2xl rounded-tl-sm px-3 py-2 text-xs leading-relaxed whitespace-pre-line ${
                  m.isWarning ? 'bg-red-950/40 border border-red-700/40 text-red-200' : 'bg-slate-800 text-slate-200'
                }`}>
                  {m.content.split('**').map((part, pi) =>
                    pi % 2 === 1
                      ? <strong key={pi} className={m.isWarning ? 'text-red-300' : 'text-white'}>{part}</strong>
                      : part
                  )}
                </div>
                {m.testId && orderedSet.has(m.testId) && (
                  <button
                    onClick={() => setViewingTest(ANCILLARY_TESTS.find(t => t.id === m.testId))}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-semibold bg-teal-500/10 border-teal-500/40 text-teal-300 hover:bg-teal-500/20 transition-all"
                  >
                    View Results →
                  </button>
                )}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Input */}
      <div className="p-4 border-t border-slate-800 shrink-0 space-y-2">
        <div className="flex gap-2 items-end">
          <Textarea
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder='Type a test to order…'
            rows={1}
            disabled={isProcessing}
            className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500 focus:border-teal-500 resize-none text-xs min-h-[36px] max-h-20"
          />
          <Button
            onClick={handleSend}
            size="icon"
            disabled={!input.trim() || isProcessing}
            className="bg-teal-600 hover:bg-teal-700 h-9 w-9 shrink-0"
          >
            {isProcessing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
          </Button>
        </div>
        <Button
          onClick={() => setShowConfirm(true)}
          className="w-full bg-slate-700 hover:bg-slate-600 text-white text-xs font-semibold"
        >
          {orderedCount === 0 ? 'Skip & Proceed to Prognosis →' : `Proceed to Prognosis (${orderedCount} test${orderedCount !== 1 ? 's' : ''}) →`}
        </Button>
      </div>

      {/* Confirm dialog */}
      <AnimatePresence>
        {showConfirm && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.92, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.92, opacity: 0 }}
              className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-sm shadow-2xl p-5"
            >
              <p className="text-white font-semibold mb-2">Proceed to Prognosis?</p>
              <p className="text-slate-400 text-sm mb-1">Tests ordered: <span className="text-white font-semibold">{orderedCount}</span></p>
              {orderedCount === 0 && (
                <div className="flex items-start gap-2 mb-3 bg-amber-900/20 border border-amber-700/30 rounded-lg px-3 py-2">
                  <AlertCircle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                  <p className="text-xs text-amber-300">You haven't ordered any ancillary tests. This may affect your prognostic accuracy.</p>
                </div>
              )}
              <p className="text-slate-500 text-xs mb-5">You'll use your findings to make a prognostic determination.</p>
              <div className="flex gap-2">
                <Button onClick={() => setShowConfirm(false)} variant="outline" className="flex-1 border-slate-600 text-slate-300">Go Back</Button>
                <Button onClick={() => { setShowConfirm(false); onAllDone(); }} className="flex-1 bg-teal-600 hover:bg-teal-700">Review & Continue</Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Test result modal */}
      <AnimatePresence>
        {viewingTest && (
          <TestResultModal test={viewingTest} onClose={() => setViewingTest(null)} />
        )}
      </AnimatePresence>
    </div>
  );
}