import React from 'react';
import { motion } from 'framer-motion';

export default function SystemTooltip({ system, examFindings, visible }) {
  if (!visible) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.2 }}
      className="absolute bottom-full left-0 mb-2 bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 z-40 pointer-events-none text-xs min-w-[200px]"
    >
      <p className="text-slate-300 font-semibold mb-2">{system.systemName}</p>
      <div className="space-y-1">
        {examFindings.slice(0, 3).map(({ label, value }) => (
          <div key={label} className="text-slate-400 text-[11px]">
            <span className="text-teal-300 font-medium">{label}:</span> {value}
          </div>
        ))}
      </div>
    </motion.div>
  );
}