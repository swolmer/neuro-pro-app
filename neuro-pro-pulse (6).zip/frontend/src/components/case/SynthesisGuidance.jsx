import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ChevronDown, Lightbulb } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const SYNTHESIS_TEMPLATE = {
  title: 'Prognostic Determination',
  template: 'Based on [key exam findings], I believe this patient has [diagnosis]. The prognosis is [prognosis level] because [clinical reasoning]. The most important prognostic factors are [factors]. My confidence in this determination is [confidence level] because [basis].',
  placeholders: [
    'e.g., fixed dilated pupils, absent brainstem reflexes',
    'e.g., severe anoxic brain injury, brain death',
    'e.g., poor, guarded, grave',
    'e.g., severity of injury, imaging findings',
    'e.g., absent corneal reflex, absent doll\'s eyes',
    'e.g., high, moderate, low',
    'e.g., comprehensive exam, confirmatory testing'
  ],
};

export default function SynthesisGuidance({ currentStage, onSubmit, submitted }) {
  const [isOpen, setIsOpen] = useState(false);
  const [response, setResponse] = useState('');

  if (currentStage !== 4) return null;

  const handleSubmit = () => {
    if (response.trim()) {
      onSubmit({ synthesis: response, template: 'prognostic' });
      setResponse('');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-lg mb-4"
    >
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between px-4 py-3 hover:bg-amber-100/30 transition-all"
      >
        <div className="flex items-center gap-2">
          <Lightbulb className="w-4 h-4 text-amber-600" />
          <span className="font-semibold text-sm text-amber-900">Synthesis Guide (Optional)</span>
        </div>
        <motion.div animate={{ rotate: isOpen ? 180 : 0 }} transition={{ duration: 0.2 }}>
          <ChevronDown className="w-4 h-4 text-amber-600" />
        </motion.div>
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="px-4 pb-4 pt-2 border-t border-amber-200 space-y-3"
          >
            <div>
              <p className="text-xs font-semibold text-amber-900 mb-2">Mad Libs Template:</p>
              <p className="text-xs text-amber-800 bg-white rounded px-3 py-2 border border-amber-100 italic mb-3">
                {SYNTHESIS_TEMPLATE.template}
              </p>
            </div>

            <div>
              <label className="text-xs font-medium text-amber-900 block mb-2">
                Fill in your prognostic determination:
              </label>
              <Textarea
                value={response}
                onChange={(e) => setResponse(e.target.value)}
                placeholder={`Based on ${SYNTHESIS_TEMPLATE.placeholders[0]}, I believe this patient has ${SYNTHESIS_TEMPLATE.placeholders[1]}...`}
                className="bg-white border-amber-200 text-slate-900 placeholder:text-amber-600 text-sm resize-none"
                rows={4}
                disabled={submitted}
              />
            </div>

            <div className="flex gap-2">
              <Button
                onClick={handleSubmit}
                disabled={!response.trim() || submitted}
                className="flex-1 bg-amber-600 hover:bg-amber-700 text-white text-xs h-8"
              >
                {submitted ? '✓ Submitted' : 'Submit Determination'}
              </Button>
              <Button
                onClick={() => setIsOpen(false)}
                variant="ghost"
                className="text-amber-700 hover:text-amber-900 text-xs h-8"
              >
                Close
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}