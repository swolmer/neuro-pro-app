import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { ChevronRight, Lightbulb } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';

// Teaching rationales by stage and topic
const TEACHING_DATABASE = {
  'history_timing': {
    title: 'Understanding the Timeline',
    teaching: 'The timing of the arrest, ROSC, and downtime are critical context. They help you determine if ≥72h has passed since ROSC—the mandatory threshold before any prognostication attempt. Never prognosticate earlier.',
  },
  'history_confounders': {
    title: 'Identifying Confounders Early',
    teaching: 'Active sedation, recent seizures, metabolic issues, and hypothermia use must be documented from the outset. These are the gatekeepers of interpretation—if any are present, you cannot reliably interpret neuro exams or EEG later.',
  },
  'history_prior_neuro': {
    title: 'Prior Neurologic Status',
    teaching: 'Knowing baseline cognitive function and any prior strokes, dementia, or neurologic disease is essential. You assess *change* from baseline—not absolute function.',
  },
  'exam_pupils': {
    title: 'Pupils: A Reliable Predictor',
    teaching: 'Bilateral absent pupils at ≥72h post-ROSC (with confounders ruled out) is one of only two highly reliable predictors per NCS 2023 (FPR <5%). This is a critical finding you cannot miss.',
  },
  'exam_motor': {
    title: 'Motor Response Assessment',
    teaching: 'Detailed motor exam (response to commands vs pain, extension vs withdrawal) provides context but is NOT reliably predictive alone. It must be combined with other modalities like EEG and imaging.',
  },
  'exam_brainstem': {
    title: 'Brainstem Reflexes Matter',
    teaching: 'Corneal, gag, and cough reflexes help assess brainstem integrity. While not individually predictive, their absence when combined with other findings strengthens a poor prognosis assessment.',
  },
  'ancillary_ssep': {
    title: 'SSEP/N20: The Gold Standard Test',
    teaching: 'Bilateral absent N20 on SSEP (≥48h with valid peripheral responses) is the most reliable single predictor per NCS 2023 (FPR <3%). This test should be obtained whenever possible.',
  },
  'ancillary_eeg': {
    title: 'EEG: Mandatory for Multimodal Assessment',
    teaching: 'Malignant patterns (suppression, burst-suppression, absent reactivity) are moderately reliable only when sedation is explicitly ruled out. Never interpret EEG without confirming the sedation status.',
  },
  'ancillary_imaging': {
    title: 'Imaging: Add Concordance',
    teaching: 'CT diffuse gray-white loss and MRI DWI restriction are moderately reliable predictors. While less powerful than pupils or SSEP alone, they add critical weight when concordant with other findings.',
  },
  'prognosis_multimodal': {
    title: 'Multimodal Integration is Mandatory',
    teaching: 'NCS 2023 is clear: NO single predictor suffices. You must combine exam (pupils), electrophysiology (SSEP, EEG), imaging (CT/MRI), and timing. Skipping any major modality weakens your conclusion.',
  },
  'prognosis_uncertainty': {
    title: 'Always Communicate Uncertainty',
    teaching: 'Even with poor-prognosis indicators, up to 25% of patients may recover meaningfully. Your prognosis statement must explicitly acknowledge uncertainty and support extended observation when evidence is incomplete.',
  },
  'prognosis_concordance': {
    title: 'Assess Concordance',
    teaching: 'Do your findings agree across modalities? Concordant findings (e.g., absent pupils + malignant EEG + diffuse DWI) are far more predictive than isolated abnormalities. Discordant findings warrant caution.',
  },
};

export default function MissedItemsTeaching({ missedItems, onDone, stageName = '' }) {
  const [currentItemIndex, setCurrentItemIndex] = useState(0);
  const [teachingContent, setTeachingContent] = useState(null);
  const [isLoadingTeaching, setIsLoadingTeaching] = useState(false);

  // Flatten all missed items into a single list
  const allMissedItems = missedItems.flatMap(section => section.items);

  const handleLoadTeaching = async (item) => {
    setIsLoadingTeaching(true);
    try {
      // Try to find a pre-built teaching point using stage + item key
      const stagePrefix = stageName.toLowerCase().replace(/\s+/g, '_').replace(/[^\w]/g, '');
      const itemKey = item.toLowerCase().split(' ').slice(0, 2).join('_').replace(/[^\w]/g, '');
      const lookupKey = `${stagePrefix}_${itemKey}`;

      let content = TEACHING_DATABASE[lookupKey];

      if (!content) {
        // Try generic search across all keys
        const allKeys = Object.keys(TEACHING_DATABASE);
        const matchedKey = allKeys.find(k => 
          item.toLowerCase().includes(k.split('_').pop()) || 
          k.split('_').pop().includes(item.toLowerCase().split(' ')[0])
        );
        if (matchedKey) {
          content = TEACHING_DATABASE[matchedKey];
        }
      }

      if (!content) {
        // Fall back to AI if no pre-built content
        const aiTeaching = await base44.integrations.Core.InvokeLLM({
          prompt: `You are a clinical educator explaining why a critical action matters in neuroprognostication (NCS 2023 guidelines).
Stage: ${stageName}
Missed action: "${item}"

Provide a 2-3 sentence teaching point explaining:
1. Why this action is critical for accurate prognostication
2. What risks occur if you skip it
3. The clinical principle it teaches

Keep it direct and actionable.`,
          model: 'claude_sonnet_4_6',
        });
        content = {
          title: item,
          teaching: aiTeaching,
        };
      }

      setTeachingContent(content);
    } finally {
      setIsLoadingTeaching(false);
    }
  };

  if (teachingContent) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-blue-50 border border-blue-200 rounded-lg p-5"
      >
        <div className="flex items-start gap-3 mb-4">
          <Lightbulb className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-bold text-blue-900">{teachingContent.title}</p>
          </div>
        </div>

        <div className="bg-white rounded-lg p-4 mb-4">
          <p className="text-sm text-blue-900 leading-relaxed">{teachingContent.teaching}</p>
        </div>

        <div className="flex gap-2">
          {currentItemIndex < allMissedItems.length - 1 ? (
            <>
              <Button
                onClick={() => {
                  setCurrentItemIndex(currentItemIndex + 1);
                  setTeachingContent(null);
                  handleLoadTeaching(allMissedItems[currentItemIndex + 1]);
                }}
                className="flex-1 bg-blue-600 hover:bg-blue-700"
              >
                Next Lesson <ChevronRight className="w-4 h-4 ml-2" />
              </Button>
              <Button
                onClick={onDone}
                variant="outline"
                className="border-blue-300 text-blue-900 hover:bg-blue-100"
              >
                Done
              </Button>
            </>
          ) : (
            <Button
              onClick={onDone}
              className="w-full bg-blue-600 hover:bg-blue-700"
            >
              Done with Learning <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
          )}
        </div>

        <p className="text-xs text-blue-700 mt-4 text-center">
          {currentItemIndex + 1} of {allMissedItems.length}
        </p>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-blue-50 border border-blue-200 rounded-lg p-5"
    >
      <div className="flex items-start gap-3 mb-4">
        <Lightbulb className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
        <div>
          <p className="text-sm font-bold text-blue-900">Learning Checkpoint</p>
          <p className="text-sm text-blue-800 mt-1">Let's walk through what you missed and why each action matters.</p>
        </div>
      </div>

      <div className="space-y-2 mb-4">
        {allMissedItems.map((item, idx) => (
          <motion.button
            key={idx}
            onClick={() => {
              setCurrentItemIndex(idx);
              handleLoadTeaching(item);
            }}
            disabled={isLoadingTeaching}
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.98 }}
            className="w-full text-left bg-white border border-blue-200 rounded-lg p-3 hover:bg-blue-100 transition-colors disabled:opacity-50"
          >
            <p className="text-sm font-semibold text-blue-900">{item}</p>
            <p className="text-xs text-blue-700 mt-0.5">Click to learn why this matters →</p>
          </motion.button>
        ))}
      </div>

      <Button
        onClick={onDone}
        variant="outline"
        className="w-full border-blue-300 text-blue-900 hover:bg-blue-100"
      >
        Skip Learning
      </Button>
    </motion.div>
  );
}