import React, { useEffect, useRef } from 'react';
import { X, Wind } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

function drawWaveform(canvas, type) {
  const ctx = canvas.getContext('2d');
  const W = canvas.width; const H = canvas.height;
  ctx.clearRect(0, 0, W, H);
  ctx.fillStyle = '#030d18'; ctx.fillRect(0, 0, W, H);

  // Grid
  ctx.strokeStyle = 'rgba(56,189,248,0.08)'; ctx.lineWidth = 0.5;
  for (let x = 0; x < W; x += 20) { ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,H); ctx.stroke(); }
  for (let y = 0; y < H; y += 10) { ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(W,y); ctx.stroke(); }

  ctx.beginPath();
  ctx.strokeStyle = type === 'pressure' ? '#38bdf8' : type === 'flow' ? '#34d399' : '#fb923c';
  ctx.lineWidth = 1.5;
  ctx.shadowColor = ctx.strokeStyle;
  ctx.shadowBlur = 4;

  const cycleW = 90;
  const numCycles = Math.ceil(W / cycleW) + 1;
  const mid = H / 2;

  let first = true;
  for (let c = 0; c < numCycles; c++) {
    for (let px = 0; px < cycleW; px++) {
      const t = px / cycleW;
      const x = c * cycleW + px;
      let y;

      if (type === 'pressure') {
        // Square-ish pressure waveform (AC/VC)
        if (t < 0.02) y = mid - (t / 0.02) * H * 0.38;
        else if (t < 0.35) y = mid - H * 0.38;
        else if (t < 0.40) y = mid - H * 0.38 * (1 - (t - 0.35) / 0.05);
        else y = mid;
      } else if (type === 'flow') {
        // Decelerating flow (AC/VC)
        if (t < 0.01) y = mid - (t / 0.01) * H * 0.42;
        else if (t < 0.35) y = mid - H * 0.42 * Math.exp(-3 * (t - 0.01) / 0.34);
        else if (t < 0.40) y = mid + H * 0.22 * ((t - 0.35) / 0.05);
        else if (t < 0.65) y = mid + H * 0.22;
        else if (t < 0.70) y = mid + H * 0.22 * (1 - (t - 0.65) / 0.05);
        else y = mid;
      } else {
        // EtCO2 capnography waveform
        if (t < 0.05) y = mid + H * 0.35;
        else if (t < 0.15) y = mid + H * 0.35 * (1 - (t - 0.05) / 0.10);
        else if (t < 0.40) {
          const slope = (t - 0.15) / 0.25;
          y = mid - H * 0.28 * slope;
        }
        else if (t < 0.45) y = mid - H * 0.28;
        else if (t < 0.55) y = mid - H * 0.28 + H * 0.63 * ((t - 0.45) / 0.10);
        else y = mid + H * 0.35;
      }

      if (first) { ctx.moveTo(x, y); first = false; } else ctx.lineTo(x, y);
    }
  }
  ctx.stroke();
}

function WaveformCanvas({ type, label, color }) {
  const ref = useRef(null);
  useEffect(() => { if (ref.current) drawWaveform(ref.current, type); }, [type]);
  return (
    <div className="flex flex-col gap-1">
      <p className="text-[9px] font-mono uppercase tracking-wider" style={{ color }}>{label}</p>
      <canvas ref={ref} width={480} height={52} className="w-full rounded" style={{ imageRendering: 'crisp-edges', border: `1px solid ${color}22` }} />
    </div>
  );
}

const PARAMS = [
  { label: 'Mode',   value: 'AC/VC',    unit: '',      color: '#38bdf8' },
  { label: 'RR Set', value: '16',       unit: '/min',  color: '#38bdf8' },
  { label: 'RR Tot', value: '16',       unit: '/min',  color: '#34d399' },
  { label: 'TV Set', value: '450',      unit: 'mL',    color: '#38bdf8' },
  { label: 'TV Exp', value: '443',      unit: 'mL',    color: '#34d399' },
  { label: 'PEEP',   value: '5',        unit: 'cmH₂O', color: '#38bdf8' },
  { label: 'FiO₂',  value: '40',       unit: '%',     color: '#38bdf8' },
  { label: 'Ppeak',  value: '22',       unit: 'cmH₂O', color: '#fb923c' },
  { label: 'Pplat',  value: '18',       unit: 'cmH₂O', color: '#fb923c' },
  { label: 'EtCO₂', value: '38',       unit: 'mmHg',  color: '#fb923c' },
  { label: 'SpO₂',  value: '97',       unit: '%',     color: '#34d399' },
  { label: 'I:E',    value: '1:2',      unit: '',      color: '#a78bfa' },
];

export default function VentilatorPopup({ open, onClose }) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          className="absolute inset-4 z-50 rounded-2xl overflow-hidden flex flex-col"
          style={{ background: '#030d18', border: '1px solid rgba(56,189,248,0.25)', boxShadow: '0 0 40px rgba(56,189,248,0.06)' }}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-2.5 border-b shrink-0" style={{ borderColor: 'rgba(56,189,248,0.18)' }}>
            <div className="flex items-center gap-2">
              <Wind className="w-4 h-4 text-sky-400" />
              <div>
                <p className="text-xs font-bold text-sky-300">Mechanical Ventilator</p>
                <p className="text-[9px] text-sky-800">Assist Control · Volume Control · Puritan Bennett 980</p>
              </div>
            </div>
            <button onClick={onClose} className="text-sky-800 hover:text-sky-400 transition-colors">
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Parameters grid */}
          <div className="px-4 pt-3 pb-2 shrink-0 grid grid-cols-6 gap-2">
            {PARAMS.map(({ label, value, unit, color }) => (
              <div key={label} className="rounded-lg px-2 py-2 text-center" style={{ background: 'rgba(255,255,255,0.03)', border: `1px solid ${color}22` }}>
                <p className="text-[8px] text-slate-600 mb-1 uppercase tracking-wide">{label}</p>
                <p className="font-mono font-bold text-base leading-none" style={{ color }}>{value}</p>
                {unit && <p className="text-[8px] text-slate-600 mt-1">{unit}</p>}
              </div>
            ))}
          </div>

          {/* Waveforms */}
          <div className="flex-1 px-4 pb-3 space-y-3 overflow-auto">
            <WaveformCanvas type="pressure" label="Airway Pressure (cmH₂O)" color="#38bdf8" />
            <WaveformCanvas type="flow"     label="Flow (L/min)" color="#34d399" />
            <WaveformCanvas type="etco2"    label="EtCO₂ Capnography (mmHg)" color="#fb923c" />
          </div>

          {/* Alarm bar */}
          <div className="px-4 pb-3 shrink-0">
            <div className="rounded-lg px-3 py-2 flex items-center gap-2" style={{ background: 'rgba(52,211,153,0.05)', border: '1px solid rgba(52,211,153,0.15)' }}>
              <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
              <p className="text-[9px] font-mono text-green-600">No active alarms · Patient-vent synchrony: Good · Leak: &lt;5%</p>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}