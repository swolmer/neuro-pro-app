import React, { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ChevronDown, Clipboard, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function ClinicalJustification({ currentStage, caseData, onSubmit, submitted }) {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedFindings, setSelectedFindings] = useState(new Set());
  const [justification, setJustification] = useState('');

  // Collect all findings from all stages
  const allFindings = useMemo(() => {
    const findings = [];
    caseData?.stages?.forEach((stage) => {
      if (stage.clinical_data) {
        Object.entries(stage.clinical_data).forEach(([key, value]) => {
          findings.push(`${key}: ${value}`);
        });
      }
    });
    return [...new Set(findings)]; // Remove duplicates
  }, [caseData]);

  if (currentStage !== 5) return null;

  const toggleFinding = (finding) => {
    const newSelected = new Set(selectedFindings);
    if (newSelected.has(finding)) {
      newSelected.delete(finding);
    } else {
      newSelected.add(finding);
    }
    setSelectedFindings(newSelected);
  };

  const handleSubmit = () => {
    if (selectedFindings.size > 0 && justification.trim()) {
      onSubmit({
        selectedFindings: Array.from(selectedFindings),
        justification,
        template: 'clinical-justification',
      });
      setSelectedFindings(new Set());
      setJustification('');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="bg-gradient-to-r from-blue-50 to-cyan-50 border border-blue-200 rounded-lg mb-4"
    >
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between px-4 py-3 hover:bg-blue-100/30 transition-all"
      >
        <div className="flex items-center gap-2">
          <Clipboard className="w-4 h-4 text-blue-600" />
          <span className="font-semibold text-sm text-blue-900">Clinical Justification</span>
          {selectedFindings.size > 0 && (
            <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-600 text-white">
              {selectedFindings.size} selected
            </span>
          )}
        </div>
        <motion.div animate={{ rotate: isOpen ? 180 : 0 }} transition={{ duration: 0.2 }}>
          <ChevronDown className="w-4 h-4 text-blue-600" />
        </motion.div>
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="px-4 pb-4 pt-2 border-t border-blue-200 space-y-3"
          >
            <div>
              <label className="text-xs font-semibold text-blue-900 block mb-2">
                Select the most important findings for prognostication:
              </label>
              <div className="bg-white border border-blue-100 rounded-lg p-3 max-h-48 overflow-y-auto space-y-2">
                {allFindings.length > 0 ? (
                  allFindings.map((finding, idx) => (
                    <motion.button
                      key={idx}
                      onClick={() => toggleFinding(finding)}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      className={`w-full flex items-start gap-3 p-2.5 rounded-lg border-2 transition-all text-left text-xs ${
                        selectedFindings.has(finding)
                          ? 'bg-blue-100 border-blue-500'
                          : 'bg-slate-50 border-slate-200 hover:border-blue-300'
                      }`}
                    >
                      <div
                        className={`shrink-0 w-4 h-4 rounded border-2 flex items-center justify-center mt-0.5 ${
                          selectedFindings.has(finding)
                            ? 'bg-blue-600 border-blue-600'
                            : 'border-slate-300'
                        }`}
                      >
                        {selectedFindings.has(finding) && (
                          <Check className="w-3 h-3 text-white" />
                        )}
                      </div>
                      <span className={selectedFindings.has(finding) ? 'font-medium text-blue-900' : 'text-slate-700'}>
                        {finding}
                      </span>
                    </motion.button>
                  ))
                ) : (
                  <p className="text-xs text-slate-500 italic">No findings available yet.</p>
                )}
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-blue-900 block mb-2">
                Justify why these findings are prognostically significant:
              </label>
              <Textarea
                value={justification}
                onChange={(e) => setJustification(e.target.value)}
                placeholder="Reference NCS guidelines, explain the clinical significance of each selected finding, and how they support your prognosis..."
                className="bg-white border-blue-200 text-slate-900 placeholder:text-blue-600 text-sm resize-none"
                rows={4}
                disabled={submitted}
              />
            </div>

            <div className="flex gap-2">
              <Button
                onClick={handleSubmit}
                disabled={selectedFindings.size === 0 || !justification.trim() || submitted}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white text-xs h-8"
              >
                {submitted ? '✓ Submitted' : 'Submit Justification'}
              </Button>
              <Button
                onClick={() => setIsOpen(false)}
                variant="ghost"
                className="text-blue-700 hover:text-blue-900 text-xs h-8"
              >
                Close
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}