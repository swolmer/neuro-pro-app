import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Trophy, ChevronRight, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import ProgressRing from '../dashboard/ProgressRing';

export default function CaseCompleteModal({ isOpen, score, caseTitle, diagnosis, attemptId, onContinue }) {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          transition={{ duration: 0.4, type: 'spring', stiffness: 300 }}
          className="bg-gradient-to-br from-slate-800 via-slate-850 to-slate-900 border border-teal-500/30 rounded-3xl max-w-md w-full overflow-hidden shadow-2xl"
        >
          {/* Animated background elements */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <motion.div
              className="absolute top-0 right-0 w-96 h-96 bg-teal-500/5 rounded-full filter blur-3xl"
              animate={{ x: [0, 40, 0], y: [0, 30, 0] }}
              transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
            />
          </div>

          {/* Content */}
          <div className="relative z-10 p-8 text-center">
            {/* Confetti animation */}
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="mb-6"
            >
              <Sparkles className="w-8 h-8 text-amber-400 mx-auto mb-4 animate-pulse" />
            </motion.div>

            {/* Score Ring */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3, duration: 0.5 }}
              className="flex justify-center mb-6"
            >
              <ProgressRing progress={score || 0} size={120} strokeWidth={8} />
            </motion.div>

            {/* Heading */}
            <motion.h2
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.4 }}
              className="text-2xl font-black text-white mb-2"
            >
              Case Complete!
            </motion.h2>

            {/* Score text */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.4 }}
              className="mb-6"
            >
              <p className="text-teal-300 font-semibold text-lg mb-1">{score}%</p>
              <p className="text-slate-400 text-sm mb-3">{caseTitle}</p>
              <p className="text-slate-500 text-xs italic">{diagnosis}</p>
            </motion.div>

            {/* Description */}
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6, duration: 0.4 }}
              className="text-slate-300 text-sm leading-relaxed mb-8"
            >
              Your case has been scored and analyzed. Review detailed feedback, rubric grading, and personalized teaching insights.
            </motion.p>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7, duration: 0.4 }}
              className="space-y-3"
            >
              <Link to={`/CaseDebrief?attemptId=${attemptId}`} className="block">
                <Button className="w-full bg-teal-600 hover:bg-teal-700 text-white font-semibold py-3 h-auto">
                  <Trophy className="w-4 h-4 mr-2" />
                  View Debrief & Feedback
                  <ChevronRight className="w-4 h-4 ml-auto" />
                </Button>
              </Link>
              <Button
                variant="ghost"
                onClick={onContinue}
                className="w-full text-slate-300 hover:text-white border border-slate-700 hover:border-slate-600 py-3 h-auto"
              >
                Continue to Survey
              </Button>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}