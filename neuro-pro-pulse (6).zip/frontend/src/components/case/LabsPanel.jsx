import React from 'react';
import { X, FlaskConical, TrendingUp, TrendingDown } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const LAB_SECTIONS = [
  {
    title: 'Neurologic Biomarkers',
    color: '#c084fc',
    labs: [
      { name: 'NSE',    value: '82',      unit: 'µg/L',   ref: '<17',    flag: 'high' },
      { name: 'GFAP',   value: '>10,000', unit: 'pg/mL',  ref: '<2500',  flag: 'high' },
      { name: 'S100B',  value: '3.8',     unit: 'µg/L',   ref: '<0.10',  flag: 'high' },
    ],
  },
  {
    title: 'Perfusion / Metabolic',
    color: '#fb923c',
    labs: [
      { name: 'Lactate', value: '4.1',  unit: 'mmol/L', ref: '<2.0',    flag: 'high' },
      { name: 'pH',      value: '7.31', unit: '',        ref: '7.35–7.45', flag: 'low' },
      { name: 'PaCO₂',  value: '38',   unit: 'mmHg',   ref: '35–45',   flag: null },
      { name: 'PaO₂',   value: '138',  unit: 'mmHg',   ref: '>80',     flag: null },
      { name: 'HCO₃',   value: '19',   unit: 'mEq/L',  ref: '22–26',   flag: 'low' },
    ],
  },
  {
    title: 'Basic Labs (BMP / CBC)',
    color: '#60a5fa',
    labs: [
      { name: 'Na',         value: '140',  unit: 'mEq/L',    ref: '136–145',  flag: null },
      { name: 'K',          value: '3.9',  unit: 'mEq/L',    ref: '3.5–5.0',  flag: null },
      { name: 'Creatinine', value: '1.1',  unit: 'mg/dL',    ref: '0.6–1.2',  flag: null },
      { name: 'Glucose',    value: '142',  unit: 'mg/dL',    ref: '70–100',   flag: 'high' },
      { name: 'WBC',        value: '11.2', unit: '×10³/µL',  ref: '4.5–11.0', flag: 'high' },
      { name: 'Hgb',        value: '9.8',  unit: 'g/dL',     ref: '13.5–17.5',flag: 'low' },
    ],
  },
  {
    title: 'Cardiac Markers',
    color: '#34d399',
    labs: [
      { name: 'Troponin I', value: '2.4', unit: 'ng/mL', ref: '<0.04', flag: 'high' },
      { name: 'CK-MB',      value: '28',  unit: 'ng/mL', ref: '<5',    flag: 'high' },
      { name: 'BNP',        value: '310', unit: 'pg/mL', ref: '<100',  flag: 'high' },
    ],
  },
  {
    title: 'Drug Levels / Tox',
    color: '#f87171',
    labs: [
      { name: 'Fentanyl',  value: 'Undetectable', unit: '',        ref: '—',    flag: null },
      { name: 'Propofol',  value: 'Undetectable', unit: '',        ref: '—',    flag: null },
      { name: 'EtOH',      value: '<10',           unit: 'mg/dL',  ref: '<10',  flag: null },
      { name: 'Ammonia',   value: '32',             unit: 'µmol/L', ref: '9–35', flag: null },
    ],
  },
];

const FLAG_CONFIG = {
  high: { color: 'text-red-400',  bg: 'bg-red-500/10',  arrow: '↑' },
  low:  { color: 'text-blue-400', bg: 'bg-blue-500/10', arrow: '↓' },
};

export default function LabsPanel({ open, onClose }) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.2 }}
          className="absolute top-0 left-0 h-full w-72 z-40 flex flex-col"
          style={{ background: 'rgba(8,14,31,0.98)', borderRight: '1px solid rgba(99,102,241,0.25)' }}
        >
          <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800 shrink-0">
            <div className="flex items-center gap-2">
              <FlaskConical className="w-4 h-4 text-indigo-400" />
              <div>
                <p className="text-xs font-bold text-white">Labs & Biomarkers</p>
                <p className="text-[10px] text-slate-500">Current values</p>
              </div>
            </div>
            <button onClick={onClose} className="text-slate-500 hover:text-white transition-colors p-1">
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="flex-1 overflow-auto px-3 py-3 space-y-4">
            {LAB_SECTIONS.map((section) => (
              <div key={section.title}>
                <div className="flex items-center gap-1.5 mb-2">
                  <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: section.color }} />
                  <p className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: section.color }}>
                    {section.title}
                  </p>
                </div>
                <div className="space-y-1">
                  {section.labs.map((lab) => {
                    const flag = lab.flag ? FLAG_CONFIG[lab.flag] : null;
                    return (
                      <div key={lab.name} className={`flex items-center justify-between rounded-lg px-3 py-2 ${flag ? flag.bg : 'bg-slate-800/40'}`}>
                        <div>
                          <p className="text-xs font-medium text-slate-200">{lab.name}</p>
                          <p className="text-[9px] text-slate-500 mt-0.5">ref: {lab.ref}</p>
                        </div>
                        <div className="text-right">
                          <p className={`text-sm font-bold font-mono ${flag ? flag.color : 'text-slate-100'}`}>
                            {lab.value}{flag && <span className="ml-1 text-xs">{flag.arrow}</span>}
                          </p>
                          {lab.unit && <p className="text-[9px] text-slate-500">{lab.unit}</p>}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}