import React, { useState, useRef, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, Send, MessageCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

export default function LearningCheckpointChatbot({ stageNum, stageConfig, onDone, caseId, attemptId }) {
  const navigate = useNavigate();
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: `Any questions about the ${stageConfig.title}? I'm here to help clarify these concepts.`,
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    const userMessage = input.trim();
    if (!userMessage || isLoading) return;

    setInput('');
    const userMsg = { role: 'user', content: userMessage };
    setMessages(prev => [...prev, userMsg]);
    setIsLoading(true);

    const context = stageConfig.items
      .map(item => `Action: ${item.action}\nWhy: ${item.reason}`)
      .join('\n\n');

    const systemPrompt = `You are an expert clinical educator for neuroprognostication training (NCS 2023/2024 guidelines). The learner just completed Stage ${stageNum}: ${stageConfig.title}.

TEACHING POINTS FOR THIS STAGE:
${context}

The learner is now asking follow-up questions. Answer clearly, concisely (2-3 sentences), and reference the specific teaching points when relevant. Be supportive and educational.`;

    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `${systemPrompt}\n\nLearner question: "${userMessage}"`,
        model: 'claude_sonnet_4_6',
      });

      const assistantMsg = { role: 'assistant', content: response };
      setMessages(prev => [...prev, assistantMsg]);
    } catch (error) {
      const errorMsg = {
        role: 'assistant',
        content: 'Sorry, I encountered an error. Please try again.',
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex flex-col w-full bg-gradient-to-b from-slate-900 to-slate-950">
      {/* Header */}
      <div className="border-b border-slate-800 bg-slate-950/80 backdrop-blur px-4 py-4 sm:px-6 shrink-0">
        <div className="flex items-center gap-3">
          <MessageCircle className="w-5 h-5 text-teal-400" />
          <h2 className="text-lg font-semibold text-white">Questions?</h2>
        </div>
        <p className="text-sm text-slate-400 mt-1">Ask anything about the teaching points above.</p>
      </div>

      {/* Chat messages */}
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4"
      >
        {messages.map((msg, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.05 }}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-xs sm:max-w-md lg:max-w-lg rounded-lg px-4 py-2.5 text-sm leading-relaxed ${
                msg.role === 'user'
                  ? 'bg-teal-600 text-white rounded-br-none'
                  : 'bg-slate-800 text-slate-200 rounded-bl-none'
              }`}
            >
              {msg.content}
            </div>
          </motion.div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-slate-800 text-slate-200 rounded-lg rounded-bl-none px-4 py-2.5 flex items-center gap-2">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span className="text-sm">Thinking...</span>
            </div>
          </div>
        )}
      </div>

      {/* Input area */}
      <div className="border-t border-slate-800 bg-slate-950/80 backdrop-blur p-4 sm:p-6 space-y-3 shrink-0">
        <div className="flex gap-2 items-end">
          <Textarea
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask a question..."
            disabled={isLoading}
            rows={1}
            className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500 focus:border-teal-500 resize-none text-sm min-h-[36px] max-h-20"
          />
          <Button
            onClick={handleSend}
            disabled={!input.trim() || isLoading}
            size="icon"
            className="bg-teal-600 hover:bg-teal-700 h-9 w-9 shrink-0"
          >
            {isLoading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
          </Button>
        </div>
        <Button
          onClick={() => {
            // Store next stage in sessionStorage and go back
            sessionStorage.setItem('returnToCaseStage', String(stageNum + 1));
            window.history.back();
          }}
          className="w-full bg-teal-600 hover:bg-teal-700 text-white font-semibold"
        >
          Continue to Stage {stageNum + 1} →
        </Button>
      </div>
    </div>
  );
}