import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ChevronDown, MessageCircle, AlertCircle, CheckCircle2, Users } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const COMMUNICATION_FRAMEWORK = {
  title: 'Communication Framework: SPIKES Protocol',
  steps: [
    {
      letter: 'S',
      title: 'Setting',
      guidance: 'Find a private, quiet room. Ensure family members have support present. Minimize interruptions. Sit at eye level.',
      examples: ['Schedule dedicated time (avoid rushed conversations)', 'Offer tissues and water', 'Allow time for emotions'],
    },
    {
      letter: 'P',
      title: 'Perception',
      guidance: 'Ask what the family understands about the patient\'s condition before you speak.',
      examples: ['"What has your understanding been so far?"', '"What have the other doctors told you?"', '"What are your biggest concerns?"'],
    },
    {
      letter: 'I',
      title: 'Invitation',
      guidance: 'Ask how much information the family wants to hear and their preferences for difficult news.',
      examples: ['"How much detail would you like to know?"', '"Would you prefer I give you all the information at once or step by step?"'],
    },
    {
      letter: 'K',
      title: 'Knowledge',
      guidance: 'Deliver information clearly, compassionately, and in understandable language. Avoid medical jargon.',
      examples: ['"The damage to your mother\'s brain is very severe and irreversible."', '"Her body is being supported by machines, but her brain is no longer functioning."'],
    },
    {
      letter: 'E',
      title: 'Emotions',
      guidance: 'Respond to their emotional reactions with empathy and silence when appropriate. Validate their feelings.',
      examples: ['"This must be incredibly difficult."', '"It\'s okay to feel [angry/sad/confused]."', 'Pause and listen.'],
    },
    {
      letter: 'S',
      title: 'Strategy & Support',
      guidance: 'Discuss next steps, goals of care, and ongoing support. Offer palliative care, chaplaincy, social work, grief counseling.',
      examples: ['Organ donation discussion (if appropriate)', 'Code status clarification', 'Timing of family meetings', 'Ongoing support resources'],
    },
  ],
};

const KEY_TALKING_POINTS = [
  { point: 'Clarity of diagnosis & prognosis', example: 'The neurological exam and tests show brain death/severe brain injury' },
  { point: 'Brain death declaration (if applicable)', example: 'This is legally and medically death—the brainstem is no longer functioning' },
  { point: 'Support measures are temporary', example: 'The ventilator is supporting the body, but the brain is not recovering' },
  { point: 'Goals of care realignment', example: 'Given this situation, what matters most to your family now?' },
  { point: 'Family wishes & values', example: 'What would your loved one want in this situation?' },
  { point: 'Next steps (withdrawal, organ donation, etc.)', example: 'We can discuss what comes next at your pace' },
];

const WHAT_TO_AVOID = [
  'Offering false hope or unrealistic recovery timelines',
  'Using clichés ("They\'re in a better place") without context',
  'Avoiding the word "death" if applicable—be direct',
  'Making assumptions about family preferences or values',
  'Abandoning the conversation when emotions arise',
  'Using overly technical language or medical jargon',
];

export default function CommunicationGuidance({ currentStage, onSubmit, submitted }) {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedTab, setSelectedTab] = useState('framework');
  const [approach, setApproach] = useState('');

  if (currentStage !== 6) return null;

  const handleSubmit = () => {
    if (approach.trim()) {
      onSubmit({
        communicationApproach: approach,
        template: 'communication-guidance',
      });
      setApproach('');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-200 rounded-lg mb-4"
    >
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between px-4 py-3 hover:bg-purple-100/30 transition-all"
      >
        <div className="flex items-center gap-2">
          <MessageCircle className="w-4 h-4 text-purple-600" />
          <span className="font-semibold text-sm text-purple-900">Communication Guidance</span>
        </div>
        <motion.div animate={{ rotate: isOpen ? 180 : 0 }} transition={{ duration: 0.2 }}>
          <ChevronDown className="w-4 h-4 text-purple-600" />
        </motion.div>
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="px-4 pb-4 pt-3 border-t border-purple-200 space-y-3"
          >
            {/* Tab buttons */}
            <div className="flex gap-2 flex-wrap">
              {[
                { id: 'framework', label: 'SPIKES Framework', icon: Users },
                { id: 'points', label: 'Key Points', icon: CheckCircle2 },
                { id: 'avoid', label: 'What to Avoid', icon: AlertCircle },
              ].map(({ id, label, icon: Icon }) => (
                <button
                  key={id}
                  onClick={() => setSelectedTab(id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    selectedTab === id
                      ? 'bg-purple-600 text-white'
                      : 'bg-white border border-purple-200 text-purple-700 hover:bg-purple-50'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {label}
                </button>
              ))}
            </div>

            {/* Framework */}
            {selectedTab === 'framework' && (
              <div className="space-y-2.5 bg-white border border-purple-100 rounded-lg p-3">
                <p className="text-xs font-semibold text-purple-900 mb-2">SPIKES Protocol for Breaking Bad News:</p>
                {COMMUNICATION_FRAMEWORK.steps.map((step, idx) => (
                  <div key={idx} className="border-l-4 border-purple-400 pl-3 pb-2">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-purple-600 text-white text-xs font-bold">
                        {step.letter}
                      </span>
                      <span className="text-xs font-semibold text-purple-900">{step.title}</span>
                    </div>
                    <p className="text-xs text-slate-700 mb-1">{step.guidance}</p>
                    <div className="text-xs text-slate-600 italic space-y-0.5">
                      {step.examples.map((ex, i) => (
                        <div key={i} className="ml-2">• {ex}</div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Key Points */}
            {selectedTab === 'points' && (
              <div className="space-y-2 bg-white border border-purple-100 rounded-lg p-3">
                <p className="text-xs font-semibold text-purple-900 mb-2">Critical Points to Address:</p>
                {KEY_TALKING_POINTS.map((item, idx) => (
                  <div key={idx} className="pb-2 border-b border-purple-100 last:border-b-0">
                    <p className="text-xs font-medium text-purple-900 mb-0.5">→ {item.point}</p>
                    <p className="text-xs text-slate-700 italic ml-2">"{item.example}"</p>
                  </div>
                ))}
              </div>
            )}

            {/* What to Avoid */}
            {selectedTab === 'avoid' && (
              <div className="space-y-2 bg-white border border-red-100 rounded-lg p-3">
                <p className="text-xs font-semibold text-red-900 mb-2">Common Pitfalls to Avoid:</p>
                {WHAT_TO_AVOID.map((item, idx) => (
                  <div key={idx} className="flex items-start gap-2 py-1.5">
                    <AlertCircle className="w-3.5 h-3.5 text-red-500 shrink-0 mt-0.5" />
                    <span className="text-xs text-slate-700">{item}</span>
                  </div>
                ))}
              </div>
            )}

            {/* Your Approach */}
            <div className="border-t border-purple-200 pt-3">
              <label className="text-xs font-semibold text-purple-900 block mb-2">
                How would you approach this conversation? Outline your strategy:
              </label>
              <Textarea
                value={approach}
                onChange={(e) => setApproach(e.target.value)}
                placeholder="I would start by... First, I'd assess their understanding by asking... Then I would convey... The key message I want to deliver is... I would address emotions by... Finally, I'd discuss next steps by..."
                className="bg-white border-purple-200 text-slate-900 placeholder:text-purple-600 text-sm resize-none"
                rows={4}
                disabled={submitted}
              />
            </div>

            <div className="flex gap-2">
              <Button
                onClick={handleSubmit}
                disabled={!approach.trim() || submitted}
                className="flex-1 bg-purple-600 hover:bg-purple-700 text-white text-xs h-8"
              >
                {submitted ? '✓ Submitted' : 'Submit Approach'}
              </Button>
              <Button
                onClick={() => setIsOpen(false)}
                variant="ghost"
                className="text-purple-700 hover:text-purple-900 text-xs h-8"
              >
                Close
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}