import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { X, CheckCircle2, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';

export default function EpicCaseCompletionModal({ 
  feedbackData, 
  onSubmitSOAP, 
  isLoading,
  caseData,
  actionsPerformed,
  scoreBreakdown
}) {
  const [subjective, setSubjective] = useState('');
  const [objective, setObjective] = useState('');
  const [assessment, setAssessment] = useState('');
  const [plan, setPlan] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async () => {
    if (!subjective.trim() || !objective.trim() || !assessment.trim() || !plan.trim()) {
      return;
    }
    setSubmitted(true);
    await onSubmitSOAP({ subjective, objective, assessment, plan });
  };

  const allFieldsFilled = subjective.trim() && objective.trim() && assessment.trim() && plan.trim();

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.2 }}
      className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4"
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.3 }}
        className="bg-white rounded-xl shadow-2xl w-full max-w-6xl max-h-[90vh] overflow-hidden flex flex-col"
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 to-slate-800 px-6 py-4 flex items-center justify-between border-b">
          <div>
            <h2 className="text-xl font-bold text-white">Case Complete — Clinical Documentation</h2>
            <p className="text-xs text-slate-400 mt-1">{caseData?.title}</p>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-teal-500/20 flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5 text-teal-400" />
            </div>
          </div>
        </div>

        {/* Split View */}
        <div className="flex-1 overflow-hidden flex min-h-0">
          {/* Left: Feedback */}
          <div className="w-1/2 border-r border-slate-200 overflow-auto bg-slate-50 p-6 space-y-4">
            <div>
              <p className="text-xs font-semibold text-slate-600 uppercase tracking-wide mb-2">Score Breakdown</p>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-700">Composite Score</span>
                  <span className="text-lg font-bold text-slate-900">{scoreBreakdown?.composite_score || 0}%</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-600">Critical Actions</span>
                  <span className="font-medium text-slate-800">{scoreBreakdown?.completed_critical || 0}/{scoreBreakdown?.total_critical || 0}</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-600">Order Accuracy</span>
                  <span className="font-medium text-slate-800">{scoreBreakdown?.order_accuracy_score || 0}%</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-600">Diagnostic Efficiency</span>
                  <span className="font-medium text-slate-800">{scoreBreakdown?.diagnostic_efficiency_score || 0}%</span>
                </div>
              </div>
            </div>

            <div className="h-px bg-slate-200" />

            <div>
              <p className="text-xs font-semibold text-slate-600 uppercase tracking-wide mb-2">AI Debrief</p>
              <div className="bg-white rounded-lg p-3 text-xs text-slate-700 leading-relaxed max-h-64 overflow-auto border border-slate-200">
                {feedbackData || 'Generating feedback...'}
              </div>
            </div>

            {scoreBreakdown?.correct_actions && scoreBreakdown.correct_actions.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-slate-600 uppercase tracking-wide mb-2">✓ Critical Actions Completed</p>
                <div className="space-y-1 text-xs">
                  {scoreBreakdown.correct_actions.map((action, i) => (
                    <div key={i} className="flex items-start gap-2 text-teal-700 bg-teal-50 rounded px-2 py-1">
                      <span className="text-teal-600 font-bold">✓</span>
                      <span>{action}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {scoreBreakdown?.missed_actions && scoreBreakdown.missed_actions.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-slate-600 uppercase tracking-wide mb-2">⚠ Missed Critical Actions</p>
                <div className="space-y-1 text-xs">
                  {scoreBreakdown.missed_actions.map((action, i) => (
                    <div key={i} className="flex items-start gap-2 text-amber-700 bg-amber-50 rounded px-2 py-1">
                      <span className="text-amber-600 font-bold">○</span>
                      <span>{action}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right: SOAP Note */}
          <div className="w-1/2 overflow-auto p-6 space-y-4 bg-white">
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-2">SUBJECTIVE</label>
              <Textarea
                value={subjective}
                onChange={(e) => setSubjective(e.target.value)}
                placeholder="Patient presentation, HPI, PMH, medications..."
                className="text-xs h-20 resize-none border-slate-300 focus:border-teal-500"
                disabled={submitted}
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-2">OBJECTIVE</label>
              <Textarea
                value={objective}
                onChange={(e) => setObjective(e.target.value)}
                placeholder="Vitals, exam findings, labs, imaging results..."
                className="text-xs h-20 resize-none border-slate-300 focus:border-teal-500"
                disabled={submitted}
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-2">ASSESSMENT</label>
              <Textarea
                value={assessment}
                onChange={(e) => setAssessment(e.target.value)}
                placeholder="Clinical impression, differential diagnosis, clinical reasoning..."
                className="text-xs h-20 resize-none border-slate-300 focus:border-teal-500"
                disabled={submitted}
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-2">PLAN</label>
              <Textarea
                value={plan}
                onChange={(e) => setPlan(e.target.value)}
                placeholder="Next steps, recommendations, clinical actions..."
                className="text-xs h-16 resize-none border-slate-300 focus:border-teal-500"
                disabled={submitted}
              />
            </div>

            <div className="flex gap-2 pt-2">
              <Button
                onClick={handleSubmit}
                disabled={!allFieldsFilled || isLoading || submitted}
                className="flex-1 bg-teal-600 hover:bg-teal-700 text-xs h-8"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-3 h-3 mr-1 animate-spin" /> Submitting...
                  </>
                ) : submitted ? (
                  <>
                    <CheckCircle2 className="w-3 h-3 mr-1" /> Submitted
                  </>
                ) : (
                  'Submit Documentation'
                )}
              </Button>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}