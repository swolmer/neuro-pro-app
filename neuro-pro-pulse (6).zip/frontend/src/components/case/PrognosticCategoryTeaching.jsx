import React, { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ChevronRight, CheckCircle2, AlertCircle } from 'lucide-react';

const PROGNOSTIC_CATEGORIES = [
  {
    id: 'poor_outcome_high_confidence',
    title: 'Poor Outcome — High Confidence',
    color: 'red',
    requirements: [
      {
        label: 'Multiple Concordant Moderately Reliable Predictors',
        description: 'Evidence from at least 2–3 different modalities all pointing to poor prognosis:',
        examples: [
          'Bilateral absent pupils + bilateral absent N20 on SSEP + malignant EEG (suppressed/burst-suppression)',
          'Bilateral absent pupils + diffuse DWI restriction on MRI + malignant EEG',
          'Bilateral absent N20 on SSEP + malignant EEG + diffuse loss of gray-white on CT',
        ],
      },
      {
        label: 'Low False-Positive Risk',
        description: 'When concordant findings present, FPR typically <10%, often <5% per NCS 2024.',
      },
      {
        label: 'Confounders Ruled Out',
        description: 'Normothermia (≥36°C), no active sedation, ≥72h post-ROSC/rewarming, significant metabolic derangement excluded.',
      },
      {
        label: 'Communication Requirement',
        description: 'Even with high-confidence poor prognosis, explicit uncertainty must be stated to families: "likely but not certain poor outcome" due to documented late recovery cases (up to 25%).',
      },
    ],
    clinicalNote: 'Extended observation (≥7–14 days) may still be warranted per NCS 2024 to allow time for possible unexpected recovery before family discussions about withdrawal of life-sustaining treatment.',
  },
  {
    id: 'poor_outcome_moderate_confidence',
    title: 'Poor Outcome — Moderate Confidence',
    color: 'orange',
    requirements: [
      {
        label: 'Some Moderately Reliable Predictors Present',
        description: 'Evidence suggests poor prognosis but findings are incomplete or partially discordant:',
        examples: [
          'Bilateral absent pupils + malignant EEG, but SSEP not obtained',
          'Bilateral absent N20 on SSEP + malignant EEG, but pupils reactive (discordant)',
          'Diffuse DWI restriction + malignant EEG, but exam findings less severe',
        ],
      },
      {
        label: 'Incomplete or Discordant Evidence',
        description: 'Not all expected poor indicators present, or findings conflict (e.g., some indicators point to poor outcome while others suggest possible recovery).',
      },
      {
        label: 'Moderate False-Positive Risk',
        description: 'FPR may be 10–20% or higher due to incomplete assessment. Meaningful recovery still possible.',
      },
      {
        label: 'Explicit Uncertainty Required',
        description: 'Communication must emphasize considerable uncertainty: "current evidence suggests poor prognosis, but we cannot rule out recovery."',
      },
    ],
    clinicalNote: 'Extended observation (≥7–14 days) is strongly recommended to allow completion of multimodal assessment and observation for signs of recovery before prognostic discussions.',
  },
  {
    id: 'indeterminate',
    title: 'Indeterminate',
    color: 'amber',
    requirements: [
      {
        label: 'Insufficient or Conflicting Evidence',
        description: 'Assessment is incomplete, findings contradict each other, or predictors are borderline/non-diagnostic:',
        examples: [
          'Only exam findings available, no EEG/SSEP/imaging obtained',
          'Bilateral absent pupils but reactive EEG with sleep-wake cycle (very discordant)',
          'Mild exam findings, normal EEG, normal imaging — cannot predict outcome',
        ],
      },
      {
        label: 'Cannot Reliably Predict Outcome',
        description: 'Available evidence does not meet thresholds for high/moderate confidence in poor outcome, and no indicators of favorable recovery.',
      },
      {
        label: 'High False-Positive Risk',
        description: 'If prognostic statement were made, risk of being wrong (patient recovers) is substantial (>20–30%).',
      },
      {
        label: 'Extended Observation Mandatory',
        description: 'Per NCS 2024, ≥1–2 weeks of continued observation and monitoring is strongly recommended before prognostic discussions.',
      },
      {
        label: 'Continued Aggressive Support',
        description: 'Maintain full life-sustaining care during the observation period. Allow time for spontaneous neurological recovery or completion of testing.',
      },
    ],
    clinicalNote: 'If assessment remains indeterminate after 7–14 days of observation, repeat testing (EEG, imaging) and reassess. Late recovery is well-documented and NCS 2024 explicitly supports extended observation as ethically appropriate.',
  },
  {
    id: 'favorable_possible',
    title: 'Favorable Outcome Possible',
    color: 'green',
    requirements: [
      {
        label: 'Absence of Poor Prognostic Indicators',
        description: 'No reliable or moderately reliable predictors of poor outcome present:',
        examples: [
          'Preserved bilateral pupils + reactive EEG with sleep-wake cycle + normal imaging',
          'Some motor response to command + preserved EEG reactivity + no diffuse DWI',
          'Absence of bilateral absent N20 on SSEP',
        ],
      },
      {
        label: 'Signs Suggesting Potential for Meaningful Recovery',
        description: 'Positive indicators may include: preserved brainstem reflexes, EEG reactivity, any purposeful motor response, absence of myoclonus, normal imaging.',
      },
      {
        label: 'Low False-Positive Risk for Poor Outcome',
        description: 'Current evidence does not support a poor prognosis determination; recovery is possible.',
      },
      {
        label: 'Continued Aggressive Support',
        description: 'Full life-sustaining care recommended. Allow adequate time for neurological recovery (typically ≥1–2 weeks minimum).',
      },
    ],
    clinicalNote: 'Prognosis for meaningful recovery should NOT be stated with certainty. Communicate that "current findings do not indicate a hopeless prognosis" but exact functional outcome remains uncertain. Continue monitoring and reassess as clinical status evolves.',
  },
];

const colorMap = {
  red: { bg: 'bg-red-50', border: 'border-red-200', text: 'text-red-900', accent: 'bg-red-100', label: 'text-red-700' },
  orange: { bg: 'bg-orange-50', border: 'border-orange-200', text: 'text-orange-900', accent: 'bg-orange-100', label: 'text-orange-700' },
  amber: { bg: 'bg-amber-50', border: 'border-amber-200', text: 'text-amber-900', accent: 'bg-amber-100', label: 'text-amber-700' },
  green: { bg: 'bg-green-50', border: 'border-green-200', text: 'text-green-900', accent: 'bg-green-100', label: 'text-green-700' },
};

export default function PrognosticCategoryTeaching({ onDone }) {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const attemptId = searchParams.get('attemptId');
  const [selectedCategory, setSelectedCategory] = useState(0);
  const category = PROGNOSTIC_CATEGORIES[selectedCategory];
  const c = colorMap[category.color];

  const handleContinue = () => {
    if (attemptId) {
      window.location.href = `/SOAPNotePage?attemptId=${attemptId}`;
    } else if (onDone) {
      onDone();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 px-4 py-6 sm:px-6 sticky top-0 z-20">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Prognostic Categories — NCS 2024</h1>
          <p className="text-slate-600">Detailed requirements and evidence standards for each category</p>
        </div>
      </div>

      {/* Main content */}
      <div className="p-4 sm:p-6 max-w-4xl mx-auto">
        {/* Category selector tabs */}
        <div className="flex flex-col sm:flex-row gap-2 mb-6 overflow-x-auto pb-2">
          {PROGNOSTIC_CATEGORIES.map((cat, idx) => (
            <motion.button
              key={cat.id}
              onClick={() => setSelectedCategory(idx)}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className={`flex-shrink-0 px-4 py-2 rounded-lg font-semibold text-sm transition-all border-2 whitespace-nowrap ${
                selectedCategory === idx
                  ? `${colorMap[cat.color].bg} ${colorMap[cat.color].border} ${colorMap[cat.color].text}`
                  : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
              }`}
            >
              {cat.title}
            </motion.button>
          ))}
        </div>

        {/* Category details */}
        <motion.div
          key={category.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.2 }}
          className={`${c.bg} border-2 ${c.border} rounded-xl p-6 space-y-6`}
        >
          {/* Title */}
          <div>
            <h2 className={`text-2xl font-bold ${c.text} mb-2`}>{category.title}</h2>
          </div>

          {/* Requirements */}
          <div className="space-y-4">
            {category.requirements.map((req, idx) => (
              <div key={idx} className={`${c.accent} rounded-lg p-4 border-l-4 ${c.border}`}>
                <h3 className={`font-semibold ${c.label} mb-1`}>{req.label}</h3>
                <p className={`text-sm ${c.text} mb-2`}>{req.description}</p>
                {req.examples && (
                  <ul className={`text-sm ${c.text} space-y-1 ml-4`}>
                    {req.examples.map((ex, i) => (
                      <li key={i} className="list-disc">
                        {ex}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>

          {/* Clinical note */}
          <div className={`${c.accent} rounded-lg p-4 border-l-4 ${c.border} flex items-start gap-3`}>
            <AlertCircle className={`w-5 h-5 ${c.label} shrink-0 mt-0.5`} />
            <div>
              <p className={`text-sm font-semibold ${c.label} mb-1`}>Clinical Note</p>
              <p className={`text-sm ${c.text}`}>{category.clinicalNote}</p>
            </div>
          </div>
        </motion.div>

        {/* Key principles at bottom */}
        <div className="mt-8 bg-blue-50 border-2 border-blue-200 rounded-xl p-6">
          <div className="flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-blue-900 mb-2">Core NCS 2024 Principles</h3>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>• <strong>No single predictor is sufficient</strong> — multimodal assessment required for defensible prognosis</li>
                <li>• <strong>Explicit uncertainty is mandatory</strong> — even "high confidence" prognoses must acknowledge late recovery possibility (up to 25%)</li>
                <li>• <strong>Extended observation (≥7–14 days)</strong> is standard of care when evidence is incomplete or indeterminate</li>
                <li>• <strong>Timing matters</strong> — assessments must be ≥72h post-ROSC/rewarming; confounders (sedation, hypothermia, metabolic derangement) must be ruled out</li>
                <li>• <strong>Concordance strengthens confidence</strong> — agreement across multiple modalities increases diagnostic certainty</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="border-t border-slate-200 bg-white px-4 py-4 sm:px-6 sticky bottom-0">
        <div className="max-w-4xl mx-auto">
          <Button
            onClick={handleContinue}
            className="w-full bg-teal-600 hover:bg-teal-700 text-white font-semibold py-3 flex items-center justify-center gap-2"
          >
            Continue to SOAP Note <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}