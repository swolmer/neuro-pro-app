import React from 'react';
import { Check, Target } from 'lucide-react';
import { motion } from 'framer-motion';

export default function NextStepsSidebar({ 
  criticalActions, 
  completedActions, 
  currentStage 
}) {
  if (!criticalActions || criticalActions.length === 0) return null;

  // Show 3 actions at a time: completed ones grayed out, next one highlighted
  const displayActions = criticalActions.slice(0, 3);

  return (
    <motion.div
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.3 }}
      className="bg-slate-900/60 border border-slate-800 rounded-lg p-3 mb-4"
    >
      <div className="flex items-center gap-2 mb-3">
        <Target className="w-4 h-4 text-teal-400" />
        <p className="text-xs font-semibold text-teal-300">Next Steps</p>
      </div>

      <div className="space-y-2">
        {displayActions
          .map((action, idx) => {
            const isCompleted = completedActions.some(c =>
              (c.action || c.action_text || '').toLowerCase().includes(
                action.toLowerCase().split(' ').slice(0, 2).join(' ')
              )
            );
            return { action, idx, isCompleted };
          })
          .filter(item => !item.isCompleted)
          .map(({ action, idx, isCompleted }) => {
            const isNext = idx === 0;

            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                transition={{ duration: 0.3 }}
                className={`flex items-start gap-2 px-3 py-2 rounded-lg text-xs transition-all ${
                  isNext
                    ? 'bg-teal-500/20 border border-teal-500/40 text-teal-200'
                    : 'bg-slate-800/30 text-slate-400'
                }`}
              >
                <div className="w-4 h-4 border border-current rounded-full mt-0.5" />
                <span>{action}</span>
              </motion.div>
            );
          })}
      </div>

      {criticalActions.length > 3 && (
        <p className="text-[10px] text-slate-500 mt-2 italic">
          +{criticalActions.length - 3} more...
        </p>
      )}
    </motion.div>
  );
}