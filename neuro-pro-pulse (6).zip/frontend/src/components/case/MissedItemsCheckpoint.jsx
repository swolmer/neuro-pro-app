import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { AlertCircle, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

const STAGE_TEACHINGS = {
  1: {
    title: 'Stage 1: History & Timeline',
    items: [
      {
        action: 'Confirm timing: ≥72 hours post-ROSC',
        reason: 'Per NCS 2023, prognostication before 72h is unreliable. Early prediction risks premature withdrawal of care and misses late recovery potential.',
      },
      {
        action: 'Rule out active sedation',
        reason: 'Sedation profoundly suppresses neurologic exam and EEG findings. You cannot interpret pupil responses, motor exam, or EEG patterns if the patient is actively sedated.',
      },
      {
        action: 'Confirm core temperature ≥36°C (normothermia)',
        reason: 'Hypothermia (<35°C) depresses neurologic function independently. NCS 2023 requires normothermia or ≥72h post-rewarming before prognostication.',
      },
      {
        action: 'Document metabolic panel (glucose, electrolytes, Cr, bilirubin)',
        reason: 'Severe metabolic derangement (glucose >400, severe hyperkalemia, uremia) can mimic poor neurologic prognosis. These are reversible confounders.',
      },
      {
        action: 'Establish baseline neurologic function',
        reason: 'You assess *change from baseline*, not absolute function. Prior dementia, prior stroke, or baseline disability changes interpretation of current exam findings.',
      },
    ],
  },
  2: {
    title: 'Stage 2: Physical Exam',
    items: [
      {
        action: 'Perform bilateral pupil assessment in dim light',
        reason: 'Bilateral absent pupils (absent light reflex) at ≥72h with confounders excluded is ONE of the most reliable predictors of poor outcome (FPR <5% per NCS 2023).',
      },
      {
        action: 'Document motor response to command AND pain separately',
        reason: 'Motor response alone has high false positive rate (FPR ~30%). You must combine with EEG, imaging, and SSEP findings for defensible prognostication.',
      },
      {
        action: 'Test corneal, gag, and cough reflexes',
        reason: 'While not individually predictive, absent brainstem reflexes combined with poor exam findings strengthen overall concordance and support poor prognosis determination.',
      },
      {
        action: 'Note myoclonic activity (generalized vs focal, timing)',
        reason: 'Myoclonus after 48h or generalized myoclonus with burst-suppression EEG carries prognostic weight. Early myoclonus (<48h) has less predictive value.',
      },
    ],
  },
};

export default function MissedItemsCheckpoint({ 
  stage, 
  caseData, 
  actionsPerformed, 
  onContinue, 
  onBack,
  attemptId 
}) {
  const navigate = useNavigate();
  const stageNum = stage ? (caseData.stages.findIndex(s => s === stage) + 1) : 2;

  const completedCritical = actionsPerformed
    .filter(a => a.stage === stageNum)
    .filter(a => a.is_critical || a.action_type === 'critical')
    .map(a => (a.action || a.action_text || '').toLowerCase());

  const dangerousActions = actionsPerformed
    .filter(a => a.stage === stageNum)
    .filter(a => a.action_type === 'dangerous');

  const missedCritical = (stage?.critical_actions || []).filter(ca =>
    !completedCritical.some(completed =>
      completed.includes(ca.toLowerCase().split(' ').slice(0, 2).join(' '))
    )
  );

  const missedItems = [];

  if (missedCritical.length > 0) {
    missedItems.push({
      type: 'missed',
      label: 'Critical actions not completed',
      items: missedCritical,
    });
  }

  if (dangerousActions.length > 0) {
    missedItems.push({
      type: 'dangerous',
      label: 'Dangerous actions taken',
      items: dangerousActions.map(a => a.action_text || a.action),
    });
  }

  const stageConfig = STAGE_TEACHINGS[stageNum];

  if (missedItems.length === 0) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-green-50 border border-green-200 rounded-lg p-4"
      >
        <div className="flex items-start gap-3">
          <div className="text-green-600 text-xl">✓</div>
          <div>
            <p className="text-sm font-semibold text-green-900 mb-1">Well done!</p>
            <p className="text-sm text-green-800">You completed all critical actions for this stage.</p>
          </div>
        </div>
        <Button 
          onClick={onContinue}
          className="w-full mt-4 bg-green-600 hover:bg-green-700"
        >
          Continue to Next Stage <ChevronRight className="w-4 h-4 ml-2" />
        </Button>
      </motion.div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Missed items header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-amber-50 border border-amber-200 rounded-lg p-4"
      >
        <div className="flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-amber-900">Here is what you missed:</p>
            <p className="text-sm text-amber-800 mt-0.5">
              These critical actions were not completed this stage.
            </p>
          </div>
        </div>

        <div className="space-y-3 mt-4 mb-0">
          {missedItems.map((section, idx) => (
            <div key={idx} className="bg-white rounded-lg p-3">
              <p className="text-xs font-semibold text-amber-900 uppercase tracking-wide mb-2">
                {section.label}
              </p>
              <ul className="space-y-1">
                {section.items.map((item, i) => (
                  <li key={i} className="text-sm text-amber-800 flex gap-2">
                    <span className="text-amber-600 shrink-0">•</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </motion.div>



      {/* Continue button */}
      <Button
        onClick={onContinue}
        className="w-full bg-teal-600 hover:bg-teal-700"
      >
        Continue to Next Stage <ChevronRight className="w-4 h-4 ml-2" />
      </Button>
    </div>
  );
}