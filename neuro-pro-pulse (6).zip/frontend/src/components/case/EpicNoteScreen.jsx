import React, { useState, useMemo } from 'react';
import { Loader2, CheckCircle2, AlertCircle, Brain, ChevronRight } from 'lucide-react';
import { base44 } from '@/api/base44Client';

// ── Tab bar ────────────────────────────────────────────────────────────────────
const TABS = ['Summary', 'Chart Review', 'Results', 'MAR', 'Flowsheets', 'Notes'];

// ── Static patient snapshot ───────────────────────────────────────────────────
const PATIENT = {
  name: 'J. Holloway',
  age: '58 yo M',
  admit: 'Out-of-hospital cardiac arrest',
  allergies: 'NKDA',
  precautions: 'Fall precautions',
  provider: 'Neurology Consult',
};

// ── Pull structured data from case / actions ──────────────────────────────────
function buildChartData(caseData, actionsPerformed) {
  const allData = {};
  caseData?.stages?.forEach(s => {
    if (s.clinical_data) Object.assign(allData, s.clinical_data);
  });

  const ordered = (actionsPerformed || []).map(a => (a.action_text || a.action || '').toLowerCase());

  const asked = (keyword) => ordered.some(t => t.includes(keyword));

  return {
    vitals: {
      hr: '72 bpm',
      bp: '122/74 mmHg',
      spo2: '97%',
      temp: '36.8 °C',
      rr: '14 / min (ventilated)',
    },
    neuro: {
      gcs: allData['GCS'] || '3T (E1V1M1)',
      pupils: asked('pupil') ? (allData['Pupils'] || '8 mm bilaterally, fixed & dilated') : '—  not assessed',
      corneal: asked('corneal') ? (allData['Corneal reflex'] || 'Absent bilaterally') : '—  not assessed',
      oculocephalic: asked('oculocephalic') || asked("doll") ? (allData['Oculocephalic reflex'] || "Absent (doll's eyes)") : '—  not assessed',
      motor: asked('motor') || asked('postur') ? (allData['Motor response'] || 'No response to noxious stimuli') : '—  not assessed',
      cough: asked('cough') ? (allData['Cough reflex'] || 'Absent to tracheal suction') : '—  not assessed',
      sedation: allData['Sedation'] || 'Midazolam 2 mg/hr (active infusion)',
    },
    ancillary: {
      eeg: asked('eeg') ? (allData['EEG'] || 'Burst-suppression; no seizure activity') : '—  not ordered',
      ct: asked('ct') ? (allData['CT Head'] || 'Diffuse cortical edema, loss of gray-white differentiation') : '—  not ordered',
      mri: asked('mri') ? (allData['MRI Brain'] || 'Diffuse cortical restricted diffusion — anoxic injury') : '—  not ordered',
      ssep: asked('ssep') ? (allData['SSEP'] || 'Bilateral absent N20 responses') : '—  not ordered',
      labs: allData['Labs'] || 'Na 138, K 3.9, Cr 1.1, Ammonia 22, Drug screen negative',
    },
  };
}

// ── Feedback Card ─────────────────────────────────────────────────────────────
function FeedbackCard({ feedback, onFinish }) {
  return (
    <div className="border border-emerald-600/40 bg-emerald-950/20 rounded-xl overflow-hidden">
      <div className="px-4 py-3 border-b border-emerald-700/30 flex items-center gap-2">
        <Brain className="w-4 h-4 text-emerald-400" />
        <span className="text-xs font-bold text-emerald-300 uppercase tracking-wider">Attending Evaluation — Neuroprognostication Note</span>
      </div>
      <div className="px-4 py-4 space-y-4">
        {feedback.clinical_synthesis && (
          <div>
            <div className="flex items-center gap-1.5 mb-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-green-400" />
              <span className="text-xs font-semibold text-green-400 uppercase tracking-wide">Clinical Synthesis</span>
            </div>
            <p className="text-sm text-slate-200 leading-relaxed">{feedback.clinical_synthesis}</p>
          </div>
        )}
        {feedback.missing_elements?.length > 0 && (
          <div>
            <div className="flex items-center gap-1.5 mb-1">
              <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-xs font-semibold text-amber-400 uppercase tracking-wide">Missing Elements</span>
            </div>
            <ul className="space-y-1">
              {feedback.missing_elements.map((el, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-slate-200">
                  <span className="text-amber-400 mt-0.5 shrink-0">⚠</span>{el}
                </li>
              ))}
            </ul>
          </div>
        )}
        {feedback.clinical_accuracy && (
          <div>
            <div className="flex items-center gap-1.5 mb-1">
              <Brain className="w-3.5 h-3.5 text-blue-400" />
              <span className="text-xs font-semibold text-blue-400 uppercase tracking-wide">Clinical Accuracy</span>
            </div>
            <p className="text-sm text-slate-200 leading-relaxed">{feedback.clinical_accuracy}</p>
          </div>
        )}
        <button
          onClick={onFinish}
          className="w-full mt-2 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold py-2.5 rounded-lg transition-all"
        >
          Complete Case →
        </button>
      </div>
    </div>
  );
}

// ── Main EpicNoteScreen ───────────────────────────────────────────────────────
export default function EpicNoteScreen({ caseData, actionsPerformed, committedPrognosis, onFinish }) {
  const [activeTab, setActiveTab] = useState('Notes');
  const [noteText, setNoteText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedback, setFeedback] = useState(null);
  const [showHint, setShowHint] = useState(false);

  const chart = useMemo(() => buildChartData(caseData, actionsPerformed), [caseData, actionsPerformed]);

  const handleSubmit = async () => {
    if (!noteText.trim() || noteText.trim().split(' ').length < 30) {
      setShowHint(true);
      return;
    }
    setIsSubmitting(true);

    const evalPrompt = `You are an expert neurologist evaluating a trainee's neuroprognostication note written in an EHR (Epic-style) interface.

CASE: ${caseData?.title || 'Post-cardiac arrest neuroprognostication'}
PROGNOSIS COMMITTED: "${committedPrognosis}"
CLINICAL NOTE: "${noteText}"

AVAILABLE CHART DATA:
- Vitals: HR ${chart.vitals.hr}, BP ${chart.vitals.bp}, SpO2 ${chart.vitals.spo2}
- Neuro Exam: Pupils ${chart.neuro.pupils}, Corneal ${chart.neuro.corneal}, Motor ${chart.neuro.motor}
- SEDATION: ${chart.neuro.sedation}  ← CRITICAL CONFOUNDER
- EEG: ${chart.ancillary.eeg}
- MRI: ${chart.ancillary.mri}
- SSEP: ${chart.ancillary.ssep}

Evaluate on three dimensions and return JSON:
{
  "clinical_synthesis": "1-2 sentence assessment — did they integrate vitals, exam, ancillary, and timing?",
  "missing_elements": ["supportive phrasing for any gaps — especially sedation/confounders, timing, specific prognostic indicators"],
  "clinical_accuracy": "1-2 sentence assessment — was their conclusion appropriate, premature, or overconfident?"
}

Rules: Be specific, not generic. Start positively. Always check if they addressed sedation as a confounder.`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt: evalPrompt,
      model: 'claude_sonnet_4_6',
      response_json_schema: {
        type: 'object',
        properties: {
          clinical_synthesis: { type: 'string' },
          missing_elements: { type: 'array', items: { type: 'string' } },
          clinical_accuracy: { type: 'string' },
        },
      },
    });

    setFeedback(result);
    setIsSubmitting(false);
  };

  return (
    <div className="h-screen flex flex-col bg-[#e8eef5] font-sans text-sm overflow-hidden">

      {/* ── Epic top bar ──────────────────────────────────────────────────── */}
      <div className="bg-[#003b6f] text-white px-4 py-1.5 flex items-center gap-4 shrink-0">
        <span className="font-bold text-base text-[#6cf] tracking-wide">Epic</span>
        <span className="text-xs text-blue-200 opacity-70">NeuroSim EHR — Training Environment</span>
        <div className="ml-auto text-xs text-blue-300 font-mono">
          {PATIENT.name} · {PATIENT.age} · {caseData?.case_id || 'CASE-001'}
        </div>
      </div>

      {/* ── Tab navigation ────────────────────────────────────────────────── */}
      <div className="bg-[#cdd9e8] border-b border-[#9aafcc] flex items-center gap-0 px-2 shrink-0">
        {TABS.map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 text-xs font-semibold border-x border-t border-transparent transition-all ${
              activeTab === tab
                ? 'bg-white text-[#003b6f] border-[#9aafcc] rounded-t-md -mb-px z-10 relative'
                : 'text-[#4a6080] hover:bg-[#beccde]'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* ── Three-panel layout ────────────────────────────────────────────── */}
      <div className="flex-1 flex overflow-hidden">

        {/* LEFT: Patient snapshot */}
        <div className="w-44 shrink-0 bg-[#d4dde9] border-r border-[#9aafcc] overflow-y-auto p-3 space-y-4">
          <div>
            <div className="text-[10px] font-bold text-[#003b6f] uppercase tracking-wide mb-1">Patient</div>
            <div className="text-xs font-semibold text-slate-800">{PATIENT.name}</div>
            <div className="text-[10px] text-slate-600">{PATIENT.age}</div>
            <div className="text-[10px] text-slate-500 mt-1">{PATIENT.admit}</div>
          </div>
          <div>
            <div className="text-[10px] font-bold text-[#c0392b] uppercase tracking-wide mb-1">Allergies</div>
            <div className="text-[10px] text-slate-700">{PATIENT.allergies}</div>
          </div>
          <div>
            <div className="text-[10px] font-bold text-[#e67e22] uppercase tracking-wide mb-1">Precautions</div>
            <div className="text-[10px] text-slate-700">{PATIENT.precautions}</div>
          </div>
          <div>
            <div className="text-[10px] font-bold text-[#003b6f] uppercase tracking-wide mb-1">Provider</div>
            <div className="text-[10px] text-slate-700">{PATIENT.provider}</div>
          </div>
          <div>
            <div className="text-[10px] font-bold text-[#003b6f] uppercase tracking-wide mb-1">Code Status</div>
            <div className="text-[10px] text-slate-700">Full code (pending goals)</div>
          </div>
          <div>
            <div className="text-[10px] font-bold text-[#003b6f] uppercase tracking-wide mb-1">Admit Date</div>
            <div className="text-[10px] text-slate-700">Today, ICU day 3</div>
          </div>
        </div>

        {/* CENTER: Chart data */}
        <div className="flex-1 overflow-y-auto bg-white border-r border-[#9aafcc] p-4 space-y-4">

          {/* Vitals */}
          <section>
            <div className="bg-[#003b6f] text-white text-[10px] font-bold uppercase tracking-wider px-3 py-1.5 rounded-t-md">
              📊 Vitals
            </div>
            <div className="border border-[#9aafcc] rounded-b-md overflow-hidden">
              <table className="w-full text-xs">
                <thead className="bg-[#e8eef5]">
                  <tr>
                    {['HR', 'BP', 'SpO₂', 'Temp', 'RR'].map(h => (
                      <th key={h} className="px-3 py-1.5 text-left font-semibold text-[#4a6080] border-b border-[#9aafcc]">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  <tr className="bg-white">
                    {[chart.vitals.hr, chart.vitals.bp, chart.vitals.spo2, chart.vitals.temp, chart.vitals.rr].map((v, i) => (
                      <td key={i} className="px-3 py-2 text-slate-800">{v}</td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
          </section>

          {/* Neurologic Exam */}
          <section>
            <div className="bg-[#4a3080] text-white text-[10px] font-bold uppercase tracking-wider px-3 py-1.5 rounded-t-md">
              🧠 Neurologic Exam
            </div>
            <div className="border border-[#9aafcc] rounded-b-md overflow-hidden divide-y divide-[#dde4ee]">
              {[
                { label: 'GCS', value: chart.neuro.gcs },
                { label: 'Pupils', value: chart.neuro.pupils },
                { label: 'Corneal reflex', value: chart.neuro.corneal },
                { label: 'Oculocephalic', value: chart.neuro.oculocephalic },
                { label: 'Motor response', value: chart.neuro.motor },
                { label: 'Cough reflex', value: chart.neuro.cough },
                {
                  label: '⚠ Sedation',
                  value: chart.neuro.sedation,
                  highlight: true,
                },
              ].map(({ label, value, highlight }) => (
                <div key={label} className={`flex px-3 py-1.5 ${highlight ? 'bg-amber-50' : 'bg-white'}`}>
                  <span className={`w-40 shrink-0 font-medium ${highlight ? 'text-amber-700' : 'text-[#4a6080]'}`}>{label}</span>
                  <span className={`${highlight ? 'text-amber-900 font-semibold' : 'text-slate-800'}`}>{value}</span>
                </div>
              ))}
            </div>
          </section>

          {/* Ancillary Results */}
          <section>
            <div className="bg-[#1a6040] text-white text-[10px] font-bold uppercase tracking-wider px-3 py-1.5 rounded-t-md">
              🔬 Ancillary Results
            </div>
            <div className="border border-[#9aafcc] rounded-b-md overflow-hidden divide-y divide-[#dde4ee]">
              {[
                { label: 'EEG', value: chart.ancillary.eeg },
                { label: 'CT Head', value: chart.ancillary.ct },
                { label: 'MRI Brain', value: chart.ancillary.mri },
                { label: 'SSEP', value: chart.ancillary.ssep },
                { label: 'Labs', value: chart.ancillary.labs },
              ].map(({ label, value }) => (
                <div key={label} className="flex px-3 py-1.5 bg-white">
                  <span className="w-24 shrink-0 font-medium text-[#4a6080]">{label}</span>
                  <span className={`text-slate-800 ${value.startsWith('—') ? 'text-slate-400 italic' : ''}`}>{value}</span>
                </div>
              ))}
            </div>
          </section>

          {/* Committed prognosis reminder */}
          {committedPrognosis && (
            <section>
              <div className="bg-[#0a4080] text-white text-[10px] font-bold uppercase tracking-wider px-3 py-1.5 rounded-t-md">
                🎯 Your Committed Prognosis
              </div>
              <div className="border border-[#9aafcc] rounded-b-md bg-blue-50 px-3 py-2 text-sm text-[#003b6f] italic">
                "{committedPrognosis}"
              </div>
            </section>
          )}
        </div>

        {/* RIGHT: Note writing */}
        <div className="w-96 shrink-0 flex flex-col bg-[#f4f7fb] border-l border-[#9aafcc] overflow-hidden">
          <div className="bg-[#003b6f] text-white px-4 py-2.5 shrink-0">
            <div className="text-xs font-bold uppercase tracking-wider text-blue-200">Notes</div>
            <div className="text-sm font-semibold text-white mt-0.5">Neuroprognostication Note</div>
          </div>

          {!feedback ? (
            <div className="flex-1 flex flex-col p-4 overflow-hidden">
              <p className="text-xs text-[#4a6080] mb-2 leading-relaxed">
                Using the available chart data, write a structured neuroprognostication note including your assessment and prognosis.
              </p>

              {/* Hint toggle */}
              {!showHint ? (
                <button
                  onClick={() => setShowHint(true)}
                  className="text-[10px] text-blue-500 underline mb-2 text-left"
                >
                  💡 Need help structuring your note?
                </button>
              ) : (
                <div className="bg-blue-50 border border-blue-200 rounded-lg px-3 py-2 mb-3 text-[11px] text-blue-800 leading-relaxed">
                  <span className="font-semibold">Suggested structure:</span>{' '}
                  Summary → Examination Findings → Ancillary Data → Confounders → Assessment → Prognosis
                </div>
              )}

              <textarea
                className="flex-1 bg-white border border-[#9aafcc] rounded-md p-3 text-sm text-slate-800 placeholder:text-slate-400 resize-none focus:outline-none focus:ring-2 focus:ring-[#003b6f]/30 leading-relaxed font-mono"
                placeholder={`Example:\n\n58-year-old male admitted following out-of-hospital cardiac arrest...\n\nNeurologic Examination:\n  - Pupils: ...\n  - Motor: ...\n  - Brainstem reflexes: ...\n  - Sedation: [IMPORTANT]\n\nAncillary:\n  - EEG: ...\n  - MRI: ...\n\nAssessment & Prognosis:\n  ...`}
                value={noteText}
                onChange={e => setNoteText(e.target.value)}
                disabled={isSubmitting}
              />

              <button
                onClick={handleSubmit}
                disabled={isSubmitting || !noteText.trim()}
                className="mt-3 bg-[#003b6f] hover:bg-[#004f99] disabled:opacity-50 text-white text-sm font-semibold py-2.5 rounded-md flex items-center justify-center gap-2 transition-all"
              >
                {isSubmitting ? (
                  <><Loader2 className="w-4 h-4 animate-spin" /> Evaluating note…</>
                ) : (
                  <>Sign & Submit Note <ChevronRight className="w-4 h-4" /></>
                )}
              </button>
            </div>
          ) : (
            <div className="flex-1 overflow-y-auto p-4">
              <FeedbackCard feedback={feedback} onFinish={onFinish} />
              <div className="mt-4 bg-white border border-[#9aafcc] rounded-md p-3">
                <div className="text-[10px] font-bold text-[#4a6080] uppercase tracking-wide mb-2">Your Submitted Note</div>
                <pre className="text-xs text-slate-700 whitespace-pre-wrap font-mono leading-relaxed">{noteText}</pre>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}