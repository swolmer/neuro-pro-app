/**
 * ChatPanel.jsx — Emergent version
 *
 * All LLM calls are proxied through our backend /api/llm/invoke endpoint.
 * The backend injects the NCS 2023 guideline as system context for every
 * prompt so responses stay grounded in Rajajee et al., Neurocrit Care 2023.
 */

import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Send, Loader2, Lightbulb, ChevronRight, Volume2, VolumeX } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { useNavigate } from 'react-router-dom';
import EpicNoteScreen from './EpicNoteScreen';
import NotesPanel from './NotesPanel';

// ---------------------------------------------------------------------------
// LLM HELPER — proxies to our backend which injects NCS 2023 context
// ---------------------------------------------------------------------------
const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const LLM_ENDPOINT = `${BACKEND_URL}/api/llm/invoke`;

/**
 * @param {string} prompt
 * @param {{ model?: string, provider?: string, response_json_schema?: object, extra_system?: string }} opts
 * @returns {Promise<string | object>} string normally; parsed object when response_json_schema is set
 */
async function invokeLLM(prompt, opts = {}) {
  const body = {
    prompt,
    model: opts.model,
    provider: opts.provider,
    response_json_schema: opts.response_json_schema,
    extra_system: opts.extra_system,
  };

  const resp = await fetch(LLM_ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });

  if (!resp.ok) {
    const txt = await resp.text();
    throw new Error(`LLM proxy error ${resp.status}: ${txt}`);
  }

  const data = await resp.json();
  if (data.error) {
    throw new Error(`LLM error: ${data.error}`);
  }

  if (opts.response_json_schema) {
    return data.data || {};
  }
  return data.text || '';
}

// ---------------------------------------------------------------------------
// CONSTANTS
// ---------------------------------------------------------------------------
const EXAM_EXPLORATION_KEYWORDS = {
  history: ['history', 'background', 'pmh', 'past medical', 'prior', 'baseline', 'chronic', 'medications', 'allerg', 'social'],
  vitals: ['vital', 'blood pressure', 'heart rate', 'temperature', 'spo2', 'oxygen', 'map', 'hemodynamic', 'bp', 'hr', 'temp'],
  timeline: ['timeline', 'when did', 'how long', 'time of', 'arrest', 'rosc', 'duration', 'onset', 'progression', 'since'],
};

const DONE_KEYWORDS = [
  "that's all", "thats all", "i'm done", "im done", "nothing else",
  "no more", "ready", "move on", "next phase", "proceed",
  "i think we're good", "we're good", "all good", "no", "nope", "done",
];

// ---------------------------------------------------------------------------
// PURE HELPERS
// ---------------------------------------------------------------------------
function detectDoneSignal(userMsg) {
  const lower = userMsg.toLowerCase().trim();
  return DONE_KEYWORDS.some(
    k => lower === k || lower.startsWith(k + ' ') || lower.endsWith(' ' + k) || lower.includes(' ' + k + ' ')
  );
}

function detectActiveSedation(caseData) {
  const SEDATION_TERMS = [
    'midazolam', 'versed', 'propofol', 'fentanyl', 'morphine',
    'lorazepam', 'ativan', 'sedation', 'sedative', 'paralytic',
    'vecuronium', 'cisatracurium', 'neuromuscular blockade',
  ];
  return SEDATION_TERMS.some(t =>
    JSON.stringify(caseData?.stages || {}).toLowerCase().includes(t)
  );
}

// ---------------------------------------------------------------------------
// TEXT-TO-SPEECH HOOK
// ---------------------------------------------------------------------------
function useTextToSpeech() {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const speak = (text) => {
    if (isSpeaking) { window.speechSynthesis.cancel(); setIsSpeaking(false); return; }
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.onend = () => setIsSpeaking(false);
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
    setIsSpeaking(true);
  };
  return { isSpeaking, speak };
}

// ---------------------------------------------------------------------------
// PROMPT BUILDER — unchanged from Base44 original
// ---------------------------------------------------------------------------
function buildClinicalPrompt({ caseData, stage, userMsg, actionsThisStage, conversationHistory }) {
  const allClinicalData = (caseData?.stages || []).reduce((acc, s) => {
    if (s.clinical_data) Object.assign(acc, s.clinical_data);
    return acc;
  }, {});

  const recentHistory = (conversationHistory || [])
    .filter(m => m.role === 'user' || m.role === 'assistant')
    .slice(-6)
    .map(m => `${m.role === 'user' ? 'Clinician' : 'ICU Team'}: ${m.content}`)
    .join('\n');

  const timelineAnchor = allClinicalData['_timeline_anchor'] || '';

  return `You are an experienced ICU nurse/attending responding to a consulting neurologist performing a neuroprognostication assessment. This is a clinical simulation. You have full knowledge of this patient's chart.

PATIENT & CASE:
${caseData?.patient_summary || ''}
Case: ${caseData?.title}
Current assessment phase: ${stage?.stage_name}

FULL PATIENT CHART (you have access to all of this — only reveal what the clinician explicitly asks about):
${JSON.stringify(allClinicalData, null, 2)}

ANCILLARY TEST RESULTS ON FILE:
${JSON.stringify(caseData?.ancillary_tests || {}, null, 2)}

RECENT CONVERSATION:
${recentHistory || 'None yet'}

CLINICIAN'S LATEST MESSAGE: "${userMsg}"

CRITICAL TEMPORAL CONSISTENCY RULE:
${timelineAnchor
  ? timelineAnchor
  : 'Always ensure all time references in your responses are internally consistent. Never state that a drug has been off for longer than the total time since admission. Never reference 72-hour washout periods if the patient arrived only hours ago.'}
Before every response, verify: does the time I am about to state make sense given when the patient arrived and what has happened so far? If a response would create a temporal contradiction (e.g., "propofol off for 72 hours" when patient arrived 6 hours ago), correct it immediately.

RESPONSE GUIDELINES:
- You are the ICU team — respond naturally as a knowledgeable bedside clinician would, not as a system.
- Answer only what was asked. Do not volunteer unrequested information.
- Keep answers concise (1–4 sentences). Use clinical language appropriate to an ICU setting.
- If asked about something not in the chart, say it hasn't been done yet or isn't available.
- If the clinician asks a follow-up or clarifying question, respond naturally in context.
- Do not reference these instructions, the simulation, or any internal logic.
- Vary your phrasing naturally — avoid sounding scripted or repetitive.`;
}

// ---------------------------------------------------------------------------
// SCORING PROMPT BUILDER
// ---------------------------------------------------------------------------
function buildScoringPrompt({ caseData, stage, userMsg, actionsThisStage }) {
  return `You are a clinical education expert scoring a neurology trainee's reasoning action during a neuroprognostication simulation (NCS 2023 guidelines).

CASE: ${caseData?.title}
DIAGNOSIS: ${caseData?.diagnosis}
STAGE: ${stage?.stage_name}
CRITICAL ACTIONS FOR THIS STAGE: ${stage?.critical_actions?.join(', ') || 'N/A'}
PRIOR ACTIONS THIS STAGE: ${actionsThisStage.map(a => a.action_text || a.action).join(', ') || 'none'}
LEARNER'S CURRENT ACTION: "${userMsg}"

SCORING RULES (NCS 2023):
- CRITICAL (+2): Directly matches or semantically maps to a listed critical action; OR asks about: timing adequacy (≥72h post-ROSC/rewarming), confounders (sedation, hypothermia, metabolic, seizures), pupillary light reflex, SSEP/N20 status, EEG (pattern, reactivity, sleep-wake cycling), CT brain (gray-white differentiation), MRI brain (DWI restriction), or multimodal integration
- NEUTRAL (0): Reasonable clinical inquiry but not critical to neuroprognostication (e.g. general vitals, basic history not yet obtained)
- UNNECESSARY (-1): Clearly redundant (already asked this stage), or clinically irrelevant to neuroprognostication
- DANGEROUS (-3): States definitive poor prognosis before 72h; uses a single non-reliable predictor as sole basis for WLST; ignores active sedation when interpreting neuro exam findings; treats NSE or OHCA/CAHP/GOFAR score as definitive

Cognitive errors — detect only if clearly present:
- premature_closure: commits to poor prognosis with insufficient evidence
- anchoring_bias: ignores a previously flagged confounder
- availability_bias: over-relies on one dramatic finding while ignoring multimodal requirement

Return JSON only, no explanation:
{"action_type":"critical|unnecessary|dangerous|neutral","matched_critical_action":null,"points":0,"cognitive_error":null,"hypothesis_detected":null}`;
}

// ---------------------------------------------------------------------------
// MAIN COMPONENT
// ---------------------------------------------------------------------------
export default function ChatPanel({
  caseData, currentStage, messages, onNewMessage, onAdvanceStage, isLastStage, onComplete,
  actionsPerformed, startTime, attemptId, facilitatorOverrideComplete,
}) {
  const navigate = useNavigate();
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [hintCountThisStage, setHintCountThisStage] = useState(0);
  const [awaitingConfirmation, setAwaitingConfirmation] = useState(false);
  const [isGeneratingFeedback, setIsGeneratingFeedback] = useState(false);
  const [finalStep, setFinalStep] = useState('data_gathering');
  const [committedPrognosis, setCommittedPrognosis] = useState('');
  const [showEpicNote, setShowEpicNote] = useState(false);
  const [exploredAreas, setExploredAreas] = useState({});
  const [nextNudge, setNextNudge] = useState('');
  const [caseNotes, setCaseNotes] = useState('');
  const [currentlySpeakingIndex, setCurrentlySpeakingIndex] = useState(null);

  const hasSedation = useMemo(() => detectActiveSedation(caseData), [caseData]);
  const scrollRef = useRef(null);
  const stage = caseData?.stages?.[currentStage - 1];
  const { speak } = useTextToSpeech();

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  // Hints / nudges are only shown on the TEACHING case. Baseline (Case 1)
  // measures pre-teaching reasoning and post-teaching evaluation (Case 3)
  // measures post-teaching performance — neither should be contaminated by
  // coaching prompts.
  const hintsEnabled = caseData?.purpose === 'teaching';

  useEffect(() => {
    setHintCountThisStage(0);
    setAwaitingConfirmation(false);
    setFinalStep('data_gathering');
    setExploredAreas({});
    setNextNudge('');
  }, [currentStage]);

  useEffect(() => {
    const userMsgs = messages.filter(m => m.role === 'user').map(m => (m.content || '').toLowerCase());
    const explored = {};
    for (const [area, keywords] of Object.entries(EXAM_EXPLORATION_KEYWORDS)) {
      explored[area] = userMsgs.some(msg => keywords.some(k => msg.includes(k)));
    }
    setExploredAreas(explored);
  }, [messages]);

  const triggerAnythingElse = () => {
    if (awaitingConfirmation) return;
    setAwaitingConfirmation(true);
    onNewMessage({
      role: 'assistant',
      content: `Before we move on to the next stage — do you have any other questions for the team?`,
      timestamp: new Date().toISOString(),
      isAnythingElse: true,
    });
  };

  const handleConfirmNo = () => {
    setAwaitingConfirmation(false);
    setIsLoading(false);
    setFinalStep('data_gathering');
    onAdvanceStage();
  };

  // -------------------------------------------------------------------------
  // SEND MESSAGE — main chatbot loop
  // -------------------------------------------------------------------------
  const sendMessage = async () => {
    const userMsg = input.trim();
    if (!userMsg || isLoading) return;
    const elapsed = Math.round((Date.now() - startTime) / 1000);
    setInput('');

    onNewMessage({ role: 'user', content: userMsg, timestamp: new Date().toISOString(), isStageTransition: false });

    // — Awaiting "anything else?" confirmation —
    if (awaitingConfirmation) {
      if (detectDoneSignal(userMsg)) {
        handleConfirmNo();
      } else {
        setAwaitingConfirmation(false);
        setIsLoading(true);
        try {
          const actionsThisStage = actionsPerformed?.filter(a => a.stage === currentStage) || [];
          const response = await invokeLLM(
            buildClinicalPrompt({ caseData, stage, userMsg, actionsThisStage, conversationHistory: messages })
          );
          onNewMessage({ role: 'assistant', content: response, timestamp: new Date().toISOString() });
        } finally {
          setIsLoading(false);
        }
      }
      return;
    }

    // — Awaiting formal prognosis statement —
    if (finalStep === 'awaiting_prognosis') {
      setIsLoading(true);
      try {
        const isVague = userMsg.split(' ').length <= 4;
        if (isVague) {
          const r = await invokeLLM(
            `An attending asks the neurology trainee for their formal neurologic prognosis. The trainee said: "${userMsg}". This is too vague. Per NCS 2023, a proper prognosis statement should include: prognostic category (very likely poor / likely poor / indeterminate / possibly favorable), the evidence basis (which reliable and moderately reliable predictors were used), confidence level, and whether multimodal findings are concordant. Ask them to be more specific, referencing 1-2 of these elements they are missing. 1-2 sentences.`
          );
          onNewMessage({ role: 'assistant', content: r, timestamp: new Date().toISOString() });
          return;
        }
        setCommittedPrognosis(userMsg);
        setFinalStep('awaiting_note');
        setShowEpicNote(true);
      } finally {
        setIsLoading(false);
      }
      return;
    }

    // — Standard data-gathering stage —
    if (finalStep !== 'done') {
      setIsLoading(true);
      try {
        const actionsThisStage = actionsPerformed?.filter(a => a.stage === currentStage) || [];

        const [response, classification] = await Promise.all([
          invokeLLM(buildClinicalPrompt({ caseData, stage, userMsg, actionsThisStage, conversationHistory: messages })),
          invokeLLM(buildScoringPrompt({ caseData, stage, userMsg, actionsThisStage }), {
            response_json_schema: {
              type: 'object',
              properties: {
                action_type: { type: 'string' },
                matched_critical_action: { type: 'string' },
                points: { type: 'number' },
                cognitive_error: { type: 'object' },
                hypothesis_detected: { type: 'object' },
              },
            },
          }),
        ]);

        onNewMessage({ role: 'assistant', content: response, timestamp: new Date().toISOString() });

        // Background nudge for next critical action — TEACHING case only
        if (hintsEnabled) {
          const remainingCritical = stage?.critical_actions?.filter(ca => {
            const done = [...actionsThisStage, { action_text: userMsg }];
            return !done.some(a => (a.action_text || a.action || '').toLowerCase().includes(ca.toLowerCase().split(' ').slice(0, 3).join(' ')));
          }) || [];

          if (remainingCritical.length > 0) {
            invokeLLM(
              `You are a clinical educator. The learner just asked: "${userMsg}". The next important thing they should evaluate is: "${remainingCritical[0]}". In ONE short sentence (max 10 words), give a gentle nudge suggesting what they should consider next. Do not be too direct. No quotes.`
            ).then(nudge => setNextNudge(nudge || '')).catch(() => {});
          } else {
            setNextNudge('');
          }
        } else {
          setNextNudge('');
        }

        // Emit classified action event
        onNewMessage({
          type: 'action_classified',
          action: classification.matched_critical_action || userMsg,
          action_text: userMsg,
          action_type: classification.action_type || 'neutral',
          points: classification.points ?? 0,
          is_critical: classification.action_type === 'critical',
          matched_critical_action: classification.matched_critical_action || null,
          cognitive_error: classification.cognitive_error || null,
          hypothesis_detected: classification.hypothesis_detected || null,
          stage: currentStage,
          elapsed_seconds: elapsed,
        });
      } finally {
        setIsLoading(false);
      }
    }
  };

  // -------------------------------------------------------------------------
  // HINT BUTTON
  // -------------------------------------------------------------------------
  const handleHint = async () => {
    setIsLoading(true);
    try {
      const actionsThisStage = actionsPerformed?.filter(a => a.stage === currentStage) || [];
      const criticalDoneThisStage = actionsThisStage
        .filter(a => a.is_critical || a.action_type === 'critical')
        .map(a => a.matched_critical_action || a.action);
      const remainingCritical = stage?.critical_actions?.filter(
        ca => !criticalDoneThisStage.some(done => done?.toLowerCase().includes(ca.toLowerCase().split(' ').slice(0, 3).join(' ')))
      ) || [];

      if (hintCountThisStage === 0) {
        const r = await invokeLLM(
          `You are a Socratic clinical educator coaching a neurology trainee through a neuroprognostication case (NCS 2023 guidelines). Stage: ${stage?.stage_name}. Learner has done: ${actionsThisStage.map(a => a.action_text || a.action).join(', ') || 'nothing yet'}. The next important item they have not addressed is: "${remainingCritical[0] || 'nothing — stage is complete'}". Without naming it directly, ask ONE Socratic question to guide them toward it. Consider: timing adequacy, confounders (sedation/hypothermia/metabolic), reliable predictors (pupils, SSEP N20), moderately reliable predictors (EEG patterns/reactivity, CT gray-white, MRI DWI), and multimodal integration. 1-2 sentences only.`
        );
        onNewMessage({ role: 'assistant', content: `> 💡 *${r}*`, timestamp: new Date().toISOString() });
        setHintCountThisStage(1);
      } else {
        onNewMessage({
          role: 'assistant',
          content: remainingCritical.length > 0
            ? `> ✓ **Next Action:** ${remainingCritical[0]}\n\nAsk the team about this directly.`
            : `> ✓ You've addressed the key items. You can advance when ready.`,
          timestamp: new Date().toISOString(),
        });
        setHintCountThisStage(2);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      setNextNudge('');
      sendMessage();
    }
  };

  // -------------------------------------------------------------------------
  // EPIC NOTE SCREEN
  // -------------------------------------------------------------------------
  if (showEpicNote) {
    return (
      <EpicNoteScreen
        caseData={caseData}
        actionsPerformed={actionsPerformed}
        committedPrognosis={committedPrognosis}
        onFinish={() => {
          setShowEpicNote(false);
          setFinalStep('done');
          onNewMessage({
            role: 'assistant',
            content: `---\n\nThank you for completing this case. Review your feedback on the next screen.`,
            timestamp: new Date().toISOString(),
            showFeedbackButton: true,
          });
        }}
      />
    );
  }

  // -------------------------------------------------------------------------
  // RENDER
  // -------------------------------------------------------------------------
  return (
    <div className="h-full flex flex-col text-xs sm:text-sm">
      {/* Header — visible on all viewports */}
      <div className="flex flex-wrap px-2 py-1.5 sm:px-3 sm:py-2 border-b border-slate-800 items-center justify-between gap-2 shrink-0 bg-slate-950 relative z-10">
        {hintsEnabled ? (
          <button
            onClick={handleHint}
            disabled={isLoading}
            title="Hint"
            className="p-1.5 rounded-lg text-slate-600 hover:text-amber-400 hover:bg-amber-500/10 transition-all disabled:opacity-30"
          >
            <Lightbulb className="w-3.5 h-3.5" />
          </button>
        ) : (
          <span aria-hidden="true" />
        )}
        {!awaitingConfirmation && finalStep !== 'awaiting_prognosis' && finalStep !== 'done' && (
          currentStage === 1 ? (
            <Button
              size="sm"
              onClick={onAdvanceStage}
              disabled={isLoading}
              className="bg-teal-600 hover:bg-teal-700 text-xs h-8 px-3 font-semibold ml-auto"
            >
              Next Stage <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
            </Button>
          ) : (
            <Button
              size="sm"
              onClick={() => triggerAnythingElse()}
              disabled={isLoading}
              className="bg-teal-600 hover:bg-teal-700 text-xs h-8 px-3 font-semibold ml-auto"
            >
              Ancillary Tests <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
            </Button>
          )
        )}
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-auto p-1 sm:p-3 space-y-1 sm:space-y-3">
        {hintsEnabled && stage?.teaching_points?.length > 0 && (
          <TeachingBanner
            title={stage.teaching_focus_title || 'NCS 2023 Focus for this step'}
            points={stage.teaching_points}
            stageKey={currentStage}
          />
        )}
        {messages.filter(m => m.role === 'user' || m.role === 'assistant').map((msg, i) => (
          <div key={i} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
            {msg.role === 'user' ? (
              <div className="max-w-[85%] w-fit">
                <div className="bg-teal-600 text-white rounded-2xl rounded-tr-sm px-2 py-1.5 sm:px-3 sm:py-2.5 break-words">
                  <p className="text-xs sm:text-sm leading-snug sm:leading-relaxed">{msg.content}</p>
                </div>
              </div>
            ) : msg.isFeedbackLoading ? (
              <div className="w-full border border-slate-700 rounded-lg px-2 py-3 sm:px-4 sm:py-5 flex items-center gap-2 sm:gap-3 bg-slate-900/60">
                <Loader2 className="w-3 h-3 sm:w-4 sm:h-4 animate-spin text-teal-400 shrink-0" />
                <div>
                  <p className="text-xs sm:text-sm text-slate-300 font-medium">Generating feedback…</p>
                  <p className="text-[10px] sm:text-xs text-slate-500 mt-0.5">Reviewing your stage</p>
                </div>
              </div>
            ) : msg.isAnythingElse ? (
              <div className="w-full bg-slate-800 border border-slate-600 rounded-xl px-4 py-4 space-y-3">
                <p className="text-sm text-slate-200 font-medium">{msg.content}</p>
                <div className="flex gap-2">
                  <button
                    onClick={handleConfirmNo}
                    className="flex-1 bg-teal-600 hover:bg-teal-700 text-white text-sm font-semibold py-2 rounded-lg transition-all"
                  >
                    Proceed to Ancillary Tests →
                  </button>
                </div>
              </div>
            ) : msg.isPhaseTransition ? (
              <div className="w-full bg-slate-800/60 border border-slate-700 rounded-xl px-4 py-3">
                <div className="text-sm text-slate-300 leading-relaxed"><ReactMarkdown>{msg.content}</ReactMarkdown></div>
              </div>
            ) : msg.showFeedbackButton ? (
              <div className="w-full flex flex-col gap-2">
                <div className="bg-white border border-slate-200 rounded-2xl rounded-tl-sm px-3 py-3">
                  <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">ICU Team</div>
                  <div className="text-sm text-slate-700 leading-relaxed">
                    <ReactMarkdown>{typeof msg.content === 'string' ? msg.content : ''}</ReactMarkdown>
                  </div>
                </div>
                <Button
                  onClick={onComplete}
                  disabled={isLoading || !attemptId}
                  className="w-full bg-teal-600 hover:bg-teal-700 text-white text-sm font-semibold py-3 rounded-xl"
                >
                  Take Me to Feedback
                </Button>
              </div>
            ) : (
              <div className="w-full">
                <div className="flex items-start gap-2">
                  <button
                    onClick={() => {
                      if (currentlySpeakingIndex === i) {
                        window.speechSynthesis.cancel();
                        setCurrentlySpeakingIndex(null);
                      } else {
                        window.speechSynthesis.cancel();
                        speak(msg.content.replace(/[#*>`_\[\]]/g, ''));
                        setCurrentlySpeakingIndex(i);
                      }
                    }}
                    className={`shrink-0 p-1.5 rounded-lg transition-all ${
                      currentlySpeakingIndex === i
                        ? 'bg-teal-100 text-teal-600'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {currentlySpeakingIndex === i ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                  </button>
                  <div className="space-y-2 flex-1 min-w-0">
                    <div className="bg-white border border-slate-200 rounded-2xl rounded-tl-sm px-3 py-3">
                      <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1.5">ICU Team</div>
                      <div className="text-sm text-slate-700 leading-relaxed break-words overflow-hidden">
                        <ReactMarkdown>{msg.content}</ReactMarkdown>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}

        {isLoading && (
          <div className="flex items-start">
            <div className="bg-white border border-slate-200 rounded-2xl rounded-tl-sm px-2 py-2 sm:px-4 sm:py-3 flex items-center gap-1.5 sm:gap-2">
              <Loader2 className="w-3 h-3 sm:w-4 sm:h-4 animate-spin text-teal-400 shrink-0" />
              <span className="text-xs sm:text-sm text-slate-500">Responding...</span>
            </div>
          </div>
        )}
      </div>

      <NotesPanel notes={caseNotes} onNotesChange={setCaseNotes} />

      {/* Input */}
      <div className="p-1 sm:p-3 pb-safe border-t border-slate-800 shrink-0 bg-slate-950">
        {hintsEnabled && nextNudge && !awaitingConfirmation && finalStep === 'data_gathering' && (
          <div className="flex items-center gap-2 mb-2 px-1">
            <span className="text-[10px] text-amber-400/80 bg-amber-500/10 border border-amber-500/20 rounded-full px-3 py-1 leading-snug flex-1">
              💭 {nextNudge}
            </span>
            <button onClick={() => setNextNudge('')} className="text-slate-600 hover:text-slate-400 text-[10px] shrink-0">✕</button>
          </div>
        )}
        <p className="text-[10px] sm:text-xs text-slate-600 mb-1 sm:mb-2 hidden sm:block">
          {awaitingConfirmation
            ? <span className="text-amber-400 font-medium">Reply "done" to proceed, or ask another question.</span>
            : finalStep === 'awaiting_prognosis'
            ? <span className="text-emerald-400 font-medium">State your neurologic prognosis</span>
            : <span className="text-slate-500"><kbd className="text-slate-400">Enter</kbd> to send</span>
          }
        </p>
        <div className="flex gap-1 items-end min-w-0">
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={
              finalStep === 'awaiting_prognosis'
                ? 'State your neurologic prognosis...'
                : 'Ask the team about the patient...'
            }
            className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500 focus:border-teal-500 resize-none min-h-[36px] sm:min-h-[48px] max-h-28 text-xs sm:text-sm"
            disabled={isLoading}
            rows={1}
          />
          <Button
            onClick={() => sendMessage()}
            size="icon"
            disabled={!input.trim() || isLoading}
            className="bg-teal-600 hover:bg-teal-700 shrink-0 h-8 w-8 sm:h-10 sm:w-10 p-1 sm:p-2"
          >
            <Send className="w-3 h-3 sm:w-4 sm:h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}


// ---------------------------------------------------------------------------
// TeachingBanner — step-specific NCS 2023 scaffolding (teaching case only).
// Collapsible; auto-opens on each new stage so learners see the focus points.
// ---------------------------------------------------------------------------
function TeachingBanner({ title, points, stageKey }) {
  const [open, setOpen] = React.useState(true);

  React.useEffect(() => {
    setOpen(true);
  }, [stageKey]);

  return (
    <div className="bg-amber-500/5 border border-amber-500/30 rounded-lg mb-2 overflow-hidden">
      <button
        type="button"
        onClick={() => setOpen(v => !v)}
        className="w-full flex items-center justify-between px-3 py-2 hover:bg-amber-500/10 transition"
      >
        <span className="text-[11px] sm:text-xs font-semibold text-amber-300 tracking-wide uppercase">
          📖 {title}
        </span>
        <span className="text-[10px] text-amber-400/80">
          {open ? 'Hide' : 'Show'}
        </span>
      </button>
      {open && (
        <ul className="px-4 pb-3 pt-0 space-y-1.5">
          {points.map((p, i) => (
            <li key={i} className="text-[11px] sm:text-xs text-amber-100/90 leading-snug flex gap-2">
              <span className="text-amber-400 shrink-0">•</span>
              <span>{p}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
