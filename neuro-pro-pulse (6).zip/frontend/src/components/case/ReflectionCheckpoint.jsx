import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ChevronRight, HelpCircle } from 'lucide-react';
import { motion } from 'framer-motion';

const REFLECTION_TEMPLATES = {
  neuro: {
    title: 'Neurologic Assessment',
    template: 'Based on [pupils/corneal reflex/oculocephalic], I see [finding]. This suggests [process]. To confirm, I should [next test].',
    placeholders: ['pupils/corneal reflex/oculocephalic', 'describe findings', 'process/diagnosis', 'next diagnostic step'],
  },
  cardio: {
    title: 'Cardiovascular Status',
    template: 'The patient\'s [vital sign] is [value], which means [interpretation]. This could be related to [mechanism]. I need to [next action].',
    placeholders: ['vital sign (HR/BP/MAP)', 'normal/elevated/low', 'clinical significance', 'next action'],
  },
  pulm: {
    title: 'Pulmonary Function',
    template: '[Breath sounds/Ventilator settings] show [finding], indicating [pathology]. To assess [function], I should [test].',
    placeholders: ['breath sounds/ventilator status', 'finding', 'process', 'next assessment'],
  },
  general: {
    title: 'Working Hypothesis',
    template: 'Based on [key findings], I believe the patient has [diagnosis/condition]. The evidence is [supporting findings]. Next, I should [next action].',
    placeholders: ['list key findings', 'diagnosis', 'supporting evidence', 'next action'],
  },
};

export default function ReflectionCheckpoint({ 
  caseData, 
  currentStage, 
  actionsPerformed, 
  onContinue, 
  onSkip 
}) {
  const [response, setResponse] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const stage = caseData?.stages?.[currentStage - 1];
  
  // Determine template based on stage or available actions
  const systemInStage = stage?.critical_actions?.[0]?.toLowerCase().includes('neuro') ? 'neuro' : 
                        stage?.critical_actions?.[0]?.toLowerCase().includes('cardio') ? 'cardio' :
                        stage?.critical_actions?.[0]?.toLowerCase().includes('pulm') ? 'pulm' : 'general';
  const template = REFLECTION_TEMPLATES[systemInStage];

  const handleSubmit = () => {
    setSubmitted(true);
    // Log reflection to attempt
    setTimeout(() => {
      onContinue({ reflection: response, template: systemInStage });
    }, 500);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: isOpen ? 1 : 0.5, y: isOpen ? 0 : 20 }}
      transition={{ duration: 0.2 }}
      className="bg-slate-800/40 border border-slate-700/50 rounded-lg p-4 mb-4 cursor-pointer"
      onClick={() => !isOpen && setIsOpen(true)}
    >
      {!isOpen ? (
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-4 h-4 text-cyan-400" />
            <span className="text-sm text-slate-300">Reflect on your findings (optional)</span>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-500" />
        </div>
      ) : (
        <div className="space-y-3">
          <div>
            <p className="text-xs font-semibold text-cyan-300 mb-2">{template.title}</p>
            <p className="text-xs text-slate-400 bg-slate-900/60 rounded px-3 py-2 mb-3 italic">
              {template.template}
            </p>
          </div>

          <Textarea
            value={response}
            onChange={(e) => setResponse(e.target.value)}
            placeholder={`E.g., Based on ${template.placeholders[0]}, I see ${template.placeholders[1]}, which suggests ${template.placeholders[2]}. To confirm, I should ${template.placeholders[3]}.`}
            className="bg-slate-900 border-slate-700 text-white placeholder:text-slate-600 text-sm resize-none"
            rows={3}
            disabled={submitted}
          />

          <div className="flex gap-2">
            <Button
              onClick={handleSubmit}
              disabled={!response.trim() || submitted}
              className="flex-1 bg-cyan-600 hover:bg-cyan-700 text-xs h-8"
            >
              {submitted ? '✓ Submitted' : 'Submit Reflection'}
            </Button>
            <Button
              onClick={() => {
                setIsOpen(false);
                onSkip();
              }}
              variant="ghost"
              className="text-slate-400 hover:text-slate-300 text-xs h-8"
            >
              Skip
            </Button>
          </div>
        </div>
      )}
    </motion.div>
  );
}