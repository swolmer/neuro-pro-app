import React from 'react';
import { Check } from 'lucide-react';

export default function StageProgress({ stages, currentStage }) {
  if (!stages || stages.length === 0) return null;

  return (
    <div className="bg-slate-900 border-b border-slate-800 px-6 py-2 flex-1">
      <div className="flex items-start gap-0 overflow-x-auto scrollbar-hide w-full">
        {stages.map((stage, i) => {
          const stageNum = i + 1;
          const isActive = stageNum === currentStage;
          const isComplete = stageNum < currentStage;
          const label = (stage.stage_name || '')
            .replace(/Initial Assessment/, 'Assessment')
            .replace(/History & Physical/, 'H&P')
            .replace(/Ancillary Tests/, 'Ancillary')
            .replace(/Prognosis/, 'Prognosis');

          return (
            <div key={i} className="flex items-start flex-1 min-w-0">
              {/* Step + label */}
              <div className="flex flex-col items-center w-full min-w-[64px]">
                <div className="flex items-center w-full">
                  {/* Left connector */}
                  <div className={`flex-1 h-px ${i === 0 ? 'invisible' : isComplete ? 'bg-teal-500/40' : 'bg-slate-700'}`} />
                  {/* Circle */}
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-medium shrink-0 transition-all ${
                    isActive
                      ? 'bg-teal-500 text-white ring-2 ring-teal-500/30'
                      : isComplete
                        ? 'bg-teal-500/20 text-teal-400'
                        : 'bg-slate-800 text-slate-500'
                  }`}>
                    {isComplete ? <Check className="w-3 h-3" /> : stageNum}
                  </div>
                  {/* Right connector */}
                  <div className={`flex-1 h-px ${i === stages.length - 1 ? 'invisible' : isComplete ? 'bg-teal-500/40' : 'bg-slate-700'}`} />
                </div>
                {/* Label */}
                <span className={`text-[8px] sm:text-[9px] leading-tight text-center mt-1 px-0.5 ${
                  isActive ? 'text-white font-semibold' : isComplete ? 'text-teal-400' : 'text-slate-500'
                }`}>
                  {label}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}