import React from 'react';
import { AlertCircle, CheckCircle2 } from 'lucide-react';
import { motion } from 'framer-motion';

const MEDICATIONS_DATA = [
  {
    name: 'Norepinephrine',
    dose: '0.08 mcg/kg/min IV (weaning)',
    lastGiven: 'Ongoing',
    relevance: 'No direct CNS effect',
    status: 'clear',
  },
  {
    name: 'Propofol',
    dose: '—',
    lastGiven: 'Discontinued 18h ago (03:00 AM)',
    relevance: 'May persist — see clearance',
    status: 'warning',
  },
  {
    name: 'Midazolam',
    dose: '—',
    lastGiven: 'Last bolus 22h ago (11:00 PM)',
    relevance: 'May persist — see clearance',
    status: 'warning',
  },
  {
    name: 'Fentanyl',
    dose: '—',
    lastGiven: 'Discontinued 16h ago (05:00 AM)',
    relevance: 'May persist — see clearance',
    status: 'warning',
  },
  {
    name: 'Vecuronium',
    dose: '—',
    lastGiven: 'Last dose >36 hours ago',
    relevance: 'Fully cleared',
    status: 'clear',
  },
  {
    name: 'Targeted Temp Mgmt',
    dose: '33°C protocol',
    lastGiven: 'Rewarmed to 36.8°C',
    relevance: 'May affect exam — see note',
    status: 'warning',
  },
];

export default function MedicationsChatDisplay() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="bg-white border border-slate-200 rounded-2xl rounded-tl-sm px-4 py-4 space-y-3"
    >
      <div>
        <p className="text-xs font-bold text-slate-900 mb-0.5">Active & Recent Medications</p>
        <p className="text-[10px] text-slate-500">Clearance times and CNS impact</p>
      </div>

      <div className="space-y-2">
        {MEDICATIONS_DATA.map((med, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, x: -8 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.04 }}
            className={`rounded-lg px-3 py-2 border ${
              med.status === 'warning'
                ? 'bg-amber-50 border-amber-200'
                : 'bg-green-50 border-green-200'
            }`}
          >
            <div className="flex items-start justify-between gap-2 mb-1">
              <p className="text-xs font-semibold text-slate-900">{med.name}</p>
              {med.status === 'warning' ? (
                <AlertCircle className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
              ) : (
                <CheckCircle2 className="w-3.5 h-3.5 text-green-600 shrink-0 mt-0.5" />
              )}
            </div>

            <div className="space-y-0.5 text-[10px] text-slate-700">
              <div className="flex justify-between">
                <span className="text-slate-600">Dose/Route:</span>
                <span className="font-medium">{med.dose}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Last Given:</span>
                <span className="font-medium">{med.lastGiven}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Relevant:</span>
                <span className={med.status === 'warning' ? 'text-amber-700 font-medium' : 'text-green-700 font-medium'}>
                  {med.relevance}
                </span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="pt-2 border-t border-slate-200 text-[9px] text-slate-600 space-y-1">
        <p><span className="text-amber-700 font-medium">Propofol:</span> ~18h post-discontinuation. Most cleared; trace CNS effects unlikely.</p>
        <p><span className="text-amber-700 font-medium">Midazolam:</span> ~22h post-discontinuation. Near complete clearance expected.</p>
        <p><span className="text-amber-700 font-medium">Fentanyl:</span> ~16h post-discontinuation. Minimal CNS effect expected.</p>
      </div>
    </motion.div>
  );
}