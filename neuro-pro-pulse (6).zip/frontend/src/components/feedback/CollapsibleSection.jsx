import React from 'react';
import { ChevronDown, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function CollapsibleSection({ title, children, isOpen, onToggle, checkedCount, totalCount }) {
  const allDone = totalCount > 0 && checkedCount === totalCount;

  return (
    <div className={`rounded-xl border transition-colors duration-200 overflow-hidden ${
      allDone ? 'border-green-500/30 bg-green-500/5' : 'border-slate-800 bg-slate-900'
    }`}>
      {/* Header */}
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between gap-3 px-5 py-4 hover:bg-slate-800/50 transition-colors text-left"
      >
        <div className="flex items-center gap-3 min-w-0">
          {allDone ? (
            <CheckCircle2 className="w-4 h-4 text-green-400 shrink-0" />
          ) : (
            <div className={`w-4 h-4 rounded-full border-2 shrink-0 ${
              checkedCount > 0 ? 'border-teal-400 bg-teal-400/20' : 'border-slate-600'
            }`}>
              {checkedCount > 0 && (
                <div className="w-full h-full rounded-full bg-teal-400/40" />
              )}
            </div>
          )}
          <span className={`font-semibold text-sm ${allDone ? 'text-green-400' : 'text-white'}`}>
            {title}
          </span>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          {totalCount > 0 && (
            <span className="text-xs text-slate-500 hidden sm:block">
              {checkedCount}/{totalCount}
            </span>
          )}
          <ChevronDown className={`w-4 h-4 text-slate-500 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
        </div>
      </button>

      {/* Content */}
      <AnimatePresence initial={false}>
        {isOpen && (
          <motion.div
            key="content"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2, ease: 'easeInOut' }}
            className="overflow-hidden"
          >
            <div className="px-5 pb-5 pt-1 border-t border-slate-800">
              {children}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}