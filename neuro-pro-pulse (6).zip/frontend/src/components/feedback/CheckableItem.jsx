import React, { useState } from 'react';
import { CheckCircle2, Circle, ChevronDown } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';

export default function CheckableItem({ text, subItems, checked, onToggle, subChecked, onSubToggle, quote }) {
  const [expanded, setExpanded] = useState(false);
  const hasSubItems = subItems && subItems.length > 0;

  if (quote) {
    return (
      <blockquote className="border-l-4 border-teal-500/60 pl-4 py-1 my-2 text-slate-400 text-sm italic leading-relaxed">
        {text}
      </blockquote>
    );
  }

  return (
    <div className={`rounded-lg border transition-all duration-150 ${
      checked ? 'border-green-500/20 bg-green-500/5' : 'border-slate-700/60 bg-slate-800/30 hover:border-slate-600/60'
    }`}>
      <div className="flex items-start gap-3 px-4 py-3">
        <button
          onClick={onToggle}
          className="shrink-0 mt-0.5 hover:scale-110 transition-transform"
        >
          {checked
            ? <CheckCircle2 className="w-4 h-4 text-green-400" />
            : <Circle className="w-4 h-4 text-slate-500" />}
        </button>

        <p className={`flex-1 text-sm leading-relaxed transition-all ${
          checked ? 'text-slate-500 line-through' : 'text-slate-200'
        }`}>
          {text}
        </p>

        {hasSubItems && (
          <button
            onClick={() => setExpanded(v => !v)}
            className="shrink-0 text-slate-600 hover:text-slate-400 transition-colors mt-0.5"
          >
            <ChevronDown className={`w-3.5 h-3.5 transition-transform ${expanded ? 'rotate-180' : ''}`} />
          </button>
        )}
      </div>

      {/* Sub-items */}
      <AnimatePresence initial={false}>
        {hasSubItems && expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="overflow-hidden"
          >
            <div className="pl-10 pr-4 pb-3 space-y-1.5 border-t border-slate-700/40 pt-2">
              {subItems.map((sub, si) => (
                <div key={si} className="flex items-start gap-2">
                  <button
                    onClick={() => onSubToggle && onSubToggle(si)}
                    className="shrink-0 mt-0.5 hover:scale-110 transition-transform"
                  >
                    {subChecked?.[si]
                      ? <CheckCircle2 className="w-3.5 h-3.5 text-green-400" />
                      : <Circle className="w-3.5 h-3.5 text-slate-600" />}
                  </button>
                  <p className={`text-xs leading-relaxed ${subChecked?.[si] ? 'text-slate-600 line-through' : 'text-slate-400'}`}>
                    {sub.text}
                  </p>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}