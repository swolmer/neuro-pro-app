import React, { useState } from 'react';
import { CheckCircle2, Circle, Info } from 'lucide-react';
import { motion } from 'framer-motion';

const CLINICAL_SIGNIFICANCE = {
  'timing': 'Prognostication is only valid ≥72h post-ROSC and post-rewarming. Early assessment carries high false-positive rates.',
  'confounders': 'Sedation, hypothermia, and metabolic derangements can mimic or mask neurological injury — must be excluded first.',
  'pupil': 'Bilateral fixed & dilated pupils (absent PLR) ≥72h is a reliable predictor of poor outcome (FPR <5%).',
  'corneal': 'Absent corneal reflex alone is not a reliable predictor — always combine with other modalities.',
  'ssep': 'Bilateral absent N20 on SSEP is a highly reliable predictor of poor outcome (FPR ~1%) when test is valid.',
  'eeg': 'Malignant EEG patterns (burst-suppression, isoelectric) are moderately reliable poor prognostic signs.',
  'mri': 'Diffuse DWI restriction on MRI (2–7 days post-ROSC) is a moderately reliable poor prognostic sign.',
  'ct': 'Loss of gray-white differentiation on early CT is associated with severe anoxic injury.',
  'nse': 'NSE is not reliable as a standalone predictor — use in context of other findings.',
  'multimodal': 'No single test predicts outcome with 100% specificity. Multimodal concordance reduces false-positive risk.',
  'family': 'Use probabilistic language. Avoid certainty. Even concordant poor signs carry a small false-positive rate.',
  'soap': 'Documentation should clearly state timing, confounders excluded, findings, and the basis for any prognostic determination.',
  'default': 'This is a critical action recommended by NCS 2023 and ERC-ESICM 2021 guidelines.',
};

function getSignificance(action) {
  const lower = (action || '').toLowerCase();
  for (const [key, val] of Object.entries(CLINICAL_SIGNIFICANCE)) {
    if (key !== 'default' && lower.includes(key)) return val;
  }
  return CLINICAL_SIGNIFICANCE.default;
}

function ActionItem({ action, checked, onToggle, index }) {
  const [showTip, setShowTip] = useState(false);
  const significance = getSignificance(action);

  return (
    <div className={`rounded-lg border transition-all duration-200 ${
      checked ? 'border-green-500/25 bg-green-500/5' : 'border-slate-700 bg-slate-800/40 hover:border-slate-600'
    }`}>
      <div className="flex items-start gap-3 px-4 py-3">
        <button onClick={() => onToggle(index)} className="shrink-0 mt-0.5 hover:scale-110 transition-transform">
          {checked
            ? <CheckCircle2 className="w-4 h-4 text-green-400" />
            : <Circle className="w-4 h-4 text-slate-500" />}
        </button>
        <p className={`flex-1 text-sm leading-snug ${checked ? 'text-slate-500 line-through' : 'text-slate-300'}`}>
          {action}
        </p>
        <button
          onMouseEnter={() => setShowTip(true)}
          onMouseLeave={() => setShowTip(false)}
          onClick={() => setShowTip(v => !v)}
          className="shrink-0 text-slate-600 hover:text-teal-400 transition-colors"
        >
          <Info className="w-3.5 h-3.5" />
        </button>
      </div>
      {showTip && (
        <div className="px-4 pb-3">
          <p className="text-xs text-teal-300 bg-teal-500/10 border border-teal-500/20 rounded-lg px-3 py-2 leading-relaxed">
            {significance}
          </p>
        </div>
      )}
    </div>
  );
}

export default function CriticalActionsChecklist({ correctActions, missedActions, storageKey }) {
  const allItems = [
    ...(correctActions || []).map(a => ({ action: a, completed: true })),
    ...(missedActions || []).map(a => ({ action: a, completed: false })),
  ];

  const [checked, setChecked] = useState(() => {
    try {
      const saved = localStorage.getItem(storageKey + '_actions');
      return saved ? JSON.parse(saved) : {};
    } catch { return {}; }
  });

  const toggle = (index) => {
    setChecked(prev => {
      const next = { ...prev, [index]: !prev[index] };
      try { localStorage.setItem(storageKey + '_actions', JSON.stringify(next)); } catch {}
      return next;
    });
  };

  const total = allItems.length;
  const done = Object.values(checked).filter(Boolean).length;
  const pct = total > 0 ? Math.round((done / total) * 100) : 0;

  if (total === 0) return null;

  const completedItems = allItems.filter(i => i.completed);
  const missedItems = allItems.filter(i => !i.completed);

  return (
    <div className="space-y-4">
      {/* Progress bar */}
      <div className="flex items-center justify-between mb-1">
        <span className="text-xs text-slate-400">{done} of {total} actions reviewed</span>
        <span className="text-xs font-semibold text-teal-400">{pct}%</span>
      </div>
      <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
        <motion.div
          className="h-full bg-gradient-to-r from-teal-500 to-cyan-400 rounded-full"
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.4 }}
        />
      </div>

      {/* Completed actions */}
      {completedItems.length > 0 && (
        <div>
          <p className="text-xs font-semibold text-green-400 uppercase tracking-wider mb-2">
            ✓ Completed ({completedItems.length})
          </p>
          <div className="space-y-1.5">
            {completedItems.map((item, i) => (
              <ActionItem key={i} action={item.action} checked={!!checked[i]} onToggle={toggle} index={i} />
            ))}
          </div>
        </div>
      )}

      {/* Missed actions */}
      {missedItems.length > 0 && (
        <div>
          <p className="text-xs font-semibold text-amber-400 uppercase tracking-wider mb-2 mt-4">
            ✗ Missed ({missedItems.length})
          </p>
          <div className="space-y-1.5">
            {missedItems.map((item, i) => {
              const globalIdx = completedItems.length + i;
              return (
                <ActionItem key={globalIdx} action={item.action} checked={!!checked[globalIdx]} onToggle={toggle} index={globalIdx} />
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}