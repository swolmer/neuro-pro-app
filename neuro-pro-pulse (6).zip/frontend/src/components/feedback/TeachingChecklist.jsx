import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// Extract teaching points from the AI debrief markdown text
export function extractTeachingPoints(debriefText) {
  if (!debriefText) return [];
  const lines = debriefText.split('\n');
  const points = [];
  let inTeachingSection = false;
  let currentItem = null;

  for (const line of lines) {
    const trimmed = line.trim();

    // Detect "Teaching Points" section heading
    if (/teaching point/i.test(trimmed)) {
      inTeachingSection = true;
      continue;
    }

    // Stop at next major heading after teaching points
    if (inTeachingSection && /^#+\s/.test(trimmed) && !/teaching point/i.test(trimmed)) {
      if (currentItem) { points.push(currentItem); currentItem = null; }
      inTeachingSection = false;
      continue;
    }

    if (!inTeachingSection) continue;

    // List item starts a new point
    if (/^[-*\d+\.]\s+/.test(trimmed) || /^\d+\.\s+/.test(trimmed)) {
      if (currentItem) points.push(currentItem);
      const text = trimmed.replace(/^[-*\d+\.]+\s+/, '').replace(/\*\*/g, '');
      currentItem = { title: text, detail: '' };
    } else if (currentItem && trimmed.length > 0) {
      currentItem.detail += (currentItem.detail ? ' ' : '') + trimmed.replace(/\*\*/g, '');
    }
  }

  if (currentItem) points.push(currentItem);

  // Fallback: scrape all bold+colon lines as teaching points if section not found
  if (points.length === 0) {
    const boldLines = debriefText.match(/\*\*([^*]+)\*\*/g) || [];
    boldLines.slice(0, 8).forEach(m => {
      points.push({ title: m.replace(/\*\*/g, ''), detail: '' });
    });
  }

  return points;
}

function TeachingPointCard({ point }) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="border border-slate-700 bg-slate-800/50 rounded-xl overflow-hidden">
      <div className="flex items-start gap-3 p-4">
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium leading-snug text-slate-200">
            {point.title}
          </p>

          {point.detail && (
            <>
              <AnimatePresence>
                {expanded && (
                  <motion.p
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="text-xs text-slate-400 mt-2 leading-relaxed"
                  >
                    {point.detail}
                  </motion.p>
                )}
              </AnimatePresence>
              <button
                onClick={() => setExpanded(v => !v)}
                className="mt-1.5 text-[10px] text-teal-500 hover:text-teal-400 flex items-center gap-1"
              >
                {expanded ? 'Hide detail' : 'Show detail'}
                <ChevronDown className={`w-3 h-3 transition-transform ${expanded ? 'rotate-180' : ''}`} />
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

export default function TeachingChecklist({ points }) {
  if (!points || points.length === 0) return null;

  return (
    <div className="space-y-2">
      {points.map((point, i) => (
        <TeachingPointCard key={i} point={point} />
      ))}
    </div>
  );
}