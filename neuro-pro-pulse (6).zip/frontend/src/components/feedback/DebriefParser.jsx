/**
 * Parses the AI debrief markdown into structured sections with checkable items.
 * Preserves all clinical text exactly as written.
 */

export function parseDebriefIntoSections(debriefText) {
  if (!debriefText) return [];

  const lines = debriefText.split('\n');
  const sections = [];
  let currentSection = null;
  let currentSubItems = [];
  let currentParagraph = [];

  const flushParagraph = () => {
    if (currentParagraph.length > 0 && currentSection) {
      const text = currentParagraph.join(' ').trim();
      if (text) currentSection.items.push({ type: 'paragraph', text });
      currentParagraph = [];
    }
  };

  const flushSubItems = () => {
    if (currentSubItems.length > 0 && currentSection) {
      const last = currentSection.items[currentSection.items.length - 1];
      if (last && last.type === 'checkable') {
        last.subItems = [...currentSubItems];
      }
      currentSubItems = [];
    }
  };

  for (const rawLine of lines) {
    const line = rawLine.trimEnd();
    const trimmed = line.trim();

    // H1/H2/H3 headings → new section
    if (/^#{1,3}\s+/.test(trimmed)) {
      flushParagraph();
      flushSubItems();
      if (currentSection) sections.push(currentSection);
      const title = trimmed.replace(/^#+\s+/, '').replace(/\*\*/g, '');
      currentSection = { title, items: [] };
      continue;
    }

    if (!currentSection) {
      currentSection = { title: 'Overview', items: [] };
    }

    // Bold line (standalone) → checkable item
    if (/^\*\*[^*]+\*\*[:\s]/.test(trimmed) || /^\*\*[^*]+\*\*$/.test(trimmed)) {
      flushParagraph();
      flushSubItems();
      const text = trimmed.replace(/\*\*/g, '');
      currentSection.items.push({ type: 'checkable', text, subItems: [] });
      continue;
    }

    // Numbered list item
    if (/^\d+\.\s+/.test(trimmed)) {
      flushParagraph();
      flushSubItems();
      const text = trimmed.replace(/^\d+\.\s+/, '').replace(/\*\*/g, '');
      currentSection.items.push({ type: 'checkable', text, subItems: [] });
      continue;
    }

    // Bullet list item (top-level)
    if (/^[-*]\s+/.test(trimmed) && !trimmed.startsWith('  ')) {
      flushParagraph();
      const text = trimmed.replace(/^[-*]\s+/, '').replace(/\*\*/g, '');
      // If it looks like a sub-item candidate (starts with lowercase or dash), could be sub
      currentSection.items.push({ type: 'checkable', text, subItems: [] });
      continue;
    }

    // Indented sub-bullet
    if (/^\s{2,}[-*]\s+/.test(line)) {
      const text = trimmed.replace(/^[-*]\s+/, '').replace(/\*\*/g, '');
      const last = currentSection.items[currentSection.items.length - 1];
      if (last && (last.type === 'checkable' || last.type === 'subgroup')) {
        if (!last.subItems) last.subItems = [];
        last.subItems.push({ text });
      }
      continue;
    }

    // Blockquote → paragraph item with special styling
    if (/^>/.test(trimmed)) {
      flushParagraph();
      const text = trimmed.replace(/^>\s*/, '');
      currentSection.items.push({ type: 'quote', text: text.replace(/\*\*/g, '') });
      continue;
    }

    // Table row — collect into table
    if (/^\|/.test(trimmed)) {
      flushParagraph();
      // Skip separator rows
      if (/^\|[-:\s|]+\|$/.test(trimmed)) continue;
      const cells = trimmed.split('|').map(c => c.trim()).filter(Boolean);
      const last = currentSection.items[currentSection.items.length - 1];
      if (last && last.type === 'table') {
        last.rows.push(cells);
      } else {
        currentSection.items.push({ type: 'table', rows: [cells] });
      }
      continue;
    }

    // Empty line
    if (trimmed === '') {
      flushParagraph();
      continue;
    }

    // Regular text — accumulate paragraph
    currentParagraph.push(trimmed.replace(/\*\*/g, ''));
  }

  flushParagraph();
  flushSubItems();
  if (currentSection && currentSection.items.length > 0) sections.push(currentSection);

  return sections;
}

/**
 * Build a flat list of all checkable item IDs across all sections,
 * for the global progress counter.
 */
export function countCheckableItems(sections) {
  let total = 0;
  for (const section of sections) {
    for (const item of section.items) {
      if (item.type === 'checkable') {
        total++;
        if (item.subItems) total += item.subItems.length;
      }
    }
  }
  return total;
}