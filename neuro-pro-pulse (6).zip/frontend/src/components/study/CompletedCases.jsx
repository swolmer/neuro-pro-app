import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { CheckCircle2, Loader2, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';

export default function CompletedCases() {
  const [completedAttempts, setCompletedAttempts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const loadAttempts = async () => {
      try {
        const user = await base44.auth.me();
        if (!user) return;

        const attempts = await base44.entities.CaseAttempt.filter({
          learner_email: user.email,
          status: 'completed'
        });

        // Fetch case titles
        const attemptsWithCaseData = await Promise.all(
          attempts.map(async (attempt) => {
            const caseData = await base44.entities.Case.filter({ id: attempt.case_id });
            return {
              ...attempt,
              caseTitle: caseData?.[0]?.title || 'Unknown Case'
            };
          })
        );

        setCompletedAttempts(attemptsWithCaseData.sort((a, b) => 
          new Date(b.completed_at) - new Date(a.completed_at)
        ));
      } catch (err) {
        setError(err.message);
      } finally {
        setIsLoading(false);
      }
    };

    loadAttempts();
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-6 h-6 animate-spin text-teal-400" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center gap-3 py-6 px-4 bg-red-500/10 border border-red-500/20 rounded-lg">
        <AlertTriangle className="w-5 h-5 text-red-400 shrink-0" />
        <p className="text-sm text-red-300">Failed to load completed cases.</p>
      </div>
    );
  }

  if (completedAttempts.length === 0) {
    return (
      <div className="py-12 text-center">
        <p className="text-slate-400 text-sm">No completed cases yet.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider mb-4">
        Completed Cases
      </h3>
      <div className="grid gap-3">
        {completedAttempts.map((attempt, idx) => (
          <motion.button
            key={attempt.id}
            onClick={() => navigate(`/CaseCompleteFeedback?attemptId=${attempt.id}`)}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.05 }}
            className="w-full text-left bg-slate-900 border border-slate-800 hover:border-teal-500/40 hover:bg-teal-500/5 rounded-lg p-4 transition-all group cursor-pointer"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3 flex-1 min-w-0">
                <div className="w-8 h-8 rounded-lg bg-teal-500/10 flex items-center justify-center shrink-0 mt-0.5">
                  <CheckCircle2 className="w-4 h-4 text-teal-400" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-white group-hover:text-teal-300 transition-colors truncate">
                    {attempt.caseTitle}
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    {new Date(attempt.completed_at).toLocaleDateString()}
                  </p>
                </div>
              </div>
              <div className="text-right shrink-0">
                <div className="text-lg font-bold text-teal-400">
                  {Math.round(attempt.score || 0)}%
                </div>
                <p className="text-xs text-slate-500">Score</p>
              </div>
            </div>
          </motion.button>
        ))}
      </div>
    </div>
  );
}