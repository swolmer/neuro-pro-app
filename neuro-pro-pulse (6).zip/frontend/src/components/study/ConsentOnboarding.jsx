import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Brain, ClipboardList, ShieldCheck } from 'lucide-react';

const STEPS = ['consent', 'profile'];

export default function ConsentOnboarding({ user, onComplete }) {
  const [step, setStep] = useState('consent');
  const [consented, setConsented] = useState(false);
  const [saving, setSaving] = useState(false);
  const [profile, setProfile] = useState({
    training_level: '',
    institution: '',
    specialty: '',
    years_experience: '',
    prior_brain_death_exams: '',
  });

  const handleConsent = () => {
    if (consented) setStep('profile');
  };

  const handleSkip = async () => {
    // Create a minimal profile so the onboarding doesn't re-appear
    await base44.entities.ParticipantProfile.create({
      user_email: user.email,
      consent_given: false,
      enrolled_in_study: false,
      consent_date: new Date().toISOString(),
    });
    onComplete();
  };

  const handleSaveProfile = async () => {
    setSaving(true);
    // Generate a de-identified participant ID
    const participantId = 'NP_' + Math.random().toString(36).substr(2, 6).toUpperCase();

    await base44.entities.ParticipantProfile.create({
      user_email: user.email,
      participant_id: participantId,
      training_level: profile.training_level,
      institution: profile.institution,
      specialty: profile.specialty,
      years_experience: Number(profile.years_experience) || 0,
      prior_brain_death_exams: profile.prior_brain_death_exams,
      consent_given: true,
      consent_date: new Date().toISOString(),
      enrolled_in_study: true,
    });

    await base44.entities.Survey.create({
      user_email: user.email,
      participant_id: participantId,
      survey_type: 'onboarding',
      responses: profile,
      completed_at: new Date().toISOString(),
    });

    await base44.entities.EventLog.create({
      user_email: user.email,
      participant_id: participantId,
      event_type: 'case_started',
      event_data: { event: 'study_enrolled' },
      timestamp: new Date().toISOString(),
    });

    setSaving(false);
    onComplete();
  };

  if (step === 'consent') {
    return (
      <div className="fixed inset-0 bg-slate-950 z-50 flex flex-col items-center justify-start p-4 overflow-y-auto">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-8 my-auto relative z-10">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-xl bg-teal-500/10 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-6 h-6 text-teal-400" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-white">Research Participation</h2>
              <p className="text-xs text-slate-400">NeuroSim Educational Study</p>
            </div>
          </div>

          <div className="bg-slate-800/50 rounded-xl p-5 mb-6 space-y-3 text-sm text-slate-300 leading-relaxed max-h-60 overflow-y-auto">
            <p><strong className="text-white">Purpose:</strong> This platform is part of an educational research study evaluating AI-assisted learning for neuroprognostication and brain death determination.</p>
            <p><strong className="text-white">Data collected:</strong> Your case performance, actions taken, time spent, and survey responses will be recorded for research analysis.</p>
            <p><strong className="text-white">Anonymity:</strong> You will be assigned a de-identified participant ID. Your name will not appear in any publications.</p>
            <p><strong className="text-white">Voluntary:</strong> Participation is voluntary. You may withdraw at any time without consequence to your training.</p>
            <p><strong className="text-white">Use of data:</strong> Data may be used in peer-reviewed publications and educational research.</p>
          </div>

          <label htmlFor="consent" className="flex items-start gap-3 mb-6 cursor-pointer select-none">
            <Checkbox
              id="consent"
              checked={consented}
              onCheckedChange={setConsented}
              className="mt-0.5 shrink-0"
            />
            <span className="text-sm text-slate-300 leading-relaxed">
              I have read and understood the above. I voluntarily consent to participate in this research study and agree to the collection of my de-identified performance data.
            </span>
          </label>

          <Button
            onClick={handleConsent}
            disabled={!consented}
            className="w-full bg-teal-600 hover:bg-teal-700 mb-3"
          >
            I Consent — Continue
          </Button>
          <Button
            variant="ghost"
            onClick={handleSkip}
            className="w-full text-slate-500 hover:text-slate-300 text-sm"
          >
            Skip — continue without joining the study
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-slate-950 z-50 flex flex-col items-center justify-start p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-8 my-auto relative z-10">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-xl bg-teal-500/10 flex items-center justify-center">
            <ClipboardList className="w-6 h-6 text-teal-400" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-white">Participant Profile</h2>
            <p className="text-xs text-slate-400">This information is de-identified for research</p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <Label className="text-slate-400 text-xs mb-1.5 block">Training Level *</Label>
            <Select value={profile.training_level} onValueChange={v => setProfile(p => ({ ...p, training_level: v }))}>
              <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                <SelectValue placeholder="Select your level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="medical_student">Medical Student</SelectItem>
                <SelectItem value="resident">Resident</SelectItem>
                <SelectItem value="fellow">Fellow</SelectItem>
                <SelectItem value="attending">Attending Physician</SelectItem>
                <SelectItem value="nurse">Nurse / NP / PA</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-slate-400 text-xs mb-1.5 block">Institution</Label>
            <Input
              value={profile.institution}
              onChange={e => setProfile(p => ({ ...p, institution: e.target.value }))}
              placeholder="e.g. Johns Hopkins Hospital"
              className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
            />
          </div>

          <div>
            <Label className="text-slate-400 text-xs mb-1.5 block">Specialty</Label>
            <Input
              value={profile.specialty}
              onChange={e => setProfile(p => ({ ...p, specialty: e.target.value }))}
              placeholder="e.g. Neurology, Critical Care"
              className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
            />
          </div>

          <div>
            <Label className="text-slate-400 text-xs mb-1.5 block">Years of Clinical Experience</Label>
            <Input
              type="number"
              value={profile.years_experience}
              onChange={e => setProfile(p => ({ ...p, years_experience: e.target.value }))}
              placeholder="0"
              className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
            />
          </div>

          <div>
            <Label className="text-slate-400 text-xs mb-1.5 block">Prior Experience with Brain Death Exams *</Label>
            <Select value={profile.prior_brain_death_exams} onValueChange={v => setProfile(p => ({ ...p, prior_brain_death_exams: v }))}>
              <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                <SelectValue placeholder="Select experience level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                <SelectItem value="observed_only">Observed only</SelectItem>
                <SelectItem value="1_to_5">Performed 1–5 exams</SelectItem>
                <SelectItem value="more_than_5">Performed more than 5 exams</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Button
          onClick={handleSaveProfile}
          disabled={saving || !profile.training_level || !profile.prior_brain_death_exams}
          className="w-full bg-teal-600 hover:bg-teal-700 mt-6"
        >
          {saving ? 'Saving...' : 'Begin Training'}
        </Button>
      </div>
    </div>
  );
}