import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';

// Rating scale component
function RatingScale({ label, value, onChange, min = 1, max = 5 }) {
  return (
    <div className="space-y-2">
      <label className="text-sm font-semibold text-slate-700">{label}</label>
      <div className="flex items-center gap-2">
        <div className="flex gap-1">
          {Array.from({ length: max - min + 1 }, (_, i) => min + i).map(num => (
            <button
              key={num}
              onClick={() => onChange(num)}
              className={`w-8 h-8 rounded border-2 text-sm font-semibold transition ${
                value === num
                  ? 'bg-teal-500 border-teal-600 text-white'
                  : 'bg-white border-slate-300 text-slate-600 hover:border-teal-400'
              }`}
            >
              {num}
            </button>
          ))}
        </div>
        <span className="text-xs text-slate-500">
          {value === 1 ? 'Not confident' : value === 5 ? 'Very confident' : ''}
        </span>
      </div>
    </div>
  );
}

export default function PostCaseSurvey({ user, caseData, attemptId, participantId, onComplete }) {
  const [responses, setResponses] = useState({
    confidence_pre: null,
    confidence_post: null,
    perceived_difficulty: null,
    perceived_usefulness: null,
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async () => {
    // Validate all fields are answered
    if (Object.values(responses).some(v => v === null)) {
      alert('Please answer all questions before submitting.');
      return;
    }

    setIsSubmitting(true);
    try {
      await base44.entities.Survey.create({
        user_email: user?.email,
        participant_id: participantId,
        attempt_id: attemptId,
        case_id: caseData?.id,
        survey_type: 'post_case',
        responses,
        confidence_pre: responses.confidence_pre,
        confidence_post: responses.confidence_post,
        perceived_difficulty: responses.perceived_difficulty,
        perceived_usefulness: responses.perceived_usefulness,
        completed_at: new Date().toISOString(),
      });

      // Log survey completion event
      await base44.entities.EventLog.create({
        user_email: user?.email,
        participant_id: participantId,
        attempt_id: attemptId,
        case_id: caseData?.id,
        event_type: 'survey_completed',
        event_data: { survey_type: 'post_case', responses },
        timestamp: new Date().toISOString(),
      }).catch(() => {});

      onComplete();
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-lg max-w-2xl w-full p-6 sm:p-8">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-slate-900">Case Feedback Survey</h1>
          <p className="text-sm text-slate-600 mt-2">
            Please help us improve by answering a few quick questions about this case.
          </p>
        </div>

        <div className="space-y-6 mb-8">
          <RatingScale
            label="How confident were you BEFORE this case? (1 = Not at all, 5 = Very confident)"
            value={responses.confidence_pre}
            onChange={value => setResponses({ ...responses, confidence_pre: value })}
          />

          <RatingScale
            label="How confident are you NOW after this case? (1 = Not at all, 5 = Very confident)"
            value={responses.confidence_post}
            onChange={value => setResponses({ ...responses, confidence_post: value })}
          />

          <RatingScale
            label="How difficult did you find this case? (1 = Very easy, 5 = Very difficult)"
            value={responses.perceived_difficulty}
            onChange={value => setResponses({ ...responses, perceived_difficulty: value })}
          />

          <RatingScale
            label="How useful was this case for your learning? (1 = Not useful, 5 = Very useful)"
            value={responses.perceived_usefulness}
            onChange={value => setResponses({ ...responses, perceived_usefulness: value })}
          />
        </div>

        <Button
          onClick={handleSubmit}
          disabled={isSubmitting || Object.values(responses).some(v => v === null)}
          className="w-full bg-teal-600 hover:bg-teal-700 disabled:opacity-50 disabled:cursor-not-allowed text-white py-3 rounded-lg font-semibold flex items-center justify-center gap-2"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Submitting...
            </>
          ) : (
            'Submit Survey'
          )}
        </Button>
      </div>
    </div>
  );
}