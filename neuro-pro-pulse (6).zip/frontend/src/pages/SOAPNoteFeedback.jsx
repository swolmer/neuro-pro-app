import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Link } from 'react-router-dom';
import { CheckCircle2, AlertCircle, Star, ArrowRight, Lightbulb } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';

export default function SOAPNoteFeedback() {
  const urlParams = new URLSearchParams(window.location.search);
  const attemptId = urlParams.get('attemptId');
  const feedbackStr = urlParams.get('feedback');
  
  let feedback = null;
  try {
    feedback = feedbackStr ? JSON.parse(decodeURIComponent(feedbackStr)) : null;
  } catch (e) {
    console.warn('Failed to parse feedback from URL:', e);
    feedback = null;
  }

  const { data: attempt } = useQuery({
    queryKey: ['attempt', attemptId],
    queryFn: async () => {
      const attempts = await base44.entities.CaseAttempt.filter({ id: attemptId });
      return attempts[0];
    },
    enabled: !!attemptId,
  });

  const qualityColors = {
    5: 'bg-teal-500/10 border-teal-500/30 text-teal-600',
    4: 'bg-cyan-500/10 border-cyan-500/30 text-cyan-600',
    3: 'bg-amber-500/10 border-amber-500/30 text-amber-600',
    2: 'bg-orange-500/10 border-orange-500/30 text-orange-600',
    1: 'bg-red-500/10 border-red-500/30 text-red-600',
  };

  const qualityLabels = {
    5: 'Excellent',
    4: 'Good',
    3: 'Adequate',
    2: 'Needs Improvement',
    1: 'Insufficient',
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 px-6 py-6 sticky top-0 z-20">
        <div className="max-w-6xl mx-auto">
          <p className="text-sm text-slate-600 mb-2">SOAP Note Review</p>
          <h1 className="text-3xl font-bold text-slate-900">Clinical Documentation Feedback</h1>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-10">
        {/* Score Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className={`bg-white border-2 rounded-2xl p-8 mb-8 shadow-sm ${qualityColors[feedback?.quality_score || 3]}`}
        >
          <div className="flex items-center gap-6">
            <div className="flex-shrink-0">
              {feedback?.quality_score >= 4 ? (
                <CheckCircle2 className="w-16 h-16 text-teal-600" />
              ) : feedback?.quality_score >= 3 ? (
                <Star className="w-16 h-16 text-amber-600" />
              ) : (
                <AlertCircle className="w-16 h-16 text-red-600" />
              )}
            </div>
            <div className="flex-1">
              <p className="text-sm font-semibold text-slate-600 uppercase tracking-wide mb-1">Documentation Quality</p>
              <h2 className="text-3xl font-black text-slate-900 mb-2">{qualityLabels[feedback?.quality_score || 3]}</h2>
              <p className="text-slate-700 leading-relaxed">{feedback?.overall_feedback}</p>
            </div>
          </div>
        </motion.div>

        {/* Section-by-Section Feedback */}
        <div className="space-y-6 mt-8">
          {feedback?.section_feedback && Object.entries(feedback.section_feedback).map(([section, details], idx) => (
            <motion.div
              key={section}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.1 + idx * 0.08 }}
              className="bg-white border border-slate-200 rounded-2xl p-8 shadow-sm"
            >
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-xl font-bold text-slate-900 capitalize">{section}</h3>
                  <p className="text-sm text-slate-600 mt-1">{details.quality || 'Good documentation'}</p>
                </div>
                <div className={`px-4 py-2 rounded-lg text-sm font-semibold ${
                  details.quality?.includes('Excellent') ? 'bg-teal-100 text-teal-700' :
                  details.quality?.includes('Good') ? 'bg-cyan-100 text-cyan-700' :
                  details.quality?.includes('Adequate') ? 'bg-amber-100 text-amber-700' :
                  'bg-red-100 text-red-700'
                }`}>
                  {details.quality || 'Complete'}
                </div>
              </div>
              
              <div className="space-y-4">
                {details.strengths && details.strengths.length > 0 && (
                  <div>
                    <p className="text-xs font-semibold text-teal-700 uppercase tracking-wide mb-2">Strengths</p>
                    <ul className="space-y-2">
                      {details.strengths.map((s, i) => (
                        <li key={i} className="flex gap-2 text-sm text-slate-700">
                          <span className="text-teal-600 shrink-0">✓</span>
                          <span>{s}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                
                {details.areas_for_improvement && details.areas_for_improvement.length > 0 && (
                  <div>
                    <p className="text-xs font-semibold text-orange-700 uppercase tracking-wide mb-2">Areas for Improvement</p>
                    <ul className="space-y-2">
                      {details.areas_for_improvement.map((a, i) => (
                        <li key={i} className="flex gap-2 text-sm text-slate-700">
                          <span className="text-orange-600 shrink-0">•</span>
                          <span>{a}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                
                {details.commentary && (
                  <div className="mt-4 p-4 bg-slate-50 rounded-lg border border-slate-200">
                    <p className="text-xs font-semibold text-slate-600 uppercase tracking-wide mb-2">Educator Commentary</p>
                    <p className="text-sm text-slate-700 leading-relaxed">{details.commentary}</p>
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Strengths & Critical Omissions Summary */}
        <div className="grid md:grid-cols-2 gap-8 mt-8">
          {/* Overall Strengths */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.5 }}
            className="bg-white border border-teal-200 rounded-2xl p-8 shadow-sm"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-teal-100 rounded-lg flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6 text-teal-600" />
              </div>
              <h3 className="text-lg font-bold text-slate-900">Overall Strengths</h3>
            </div>
            <div className="space-y-3">
              {(feedback?.strengths || []).map((strength, i) => (
                <div key={i} className="flex gap-3">
                  <div className="w-1.5 h-1.5 bg-teal-500 rounded-full mt-2 shrink-0" />
                  <p className="text-sm text-slate-700">{strength}</p>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Critical Omissions */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.6 }}
            className="bg-white border border-red-200 rounded-2xl p-8 shadow-sm"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                <AlertCircle className="w-6 h-6 text-red-600" />
              </div>
              <h3 className="text-lg font-bold text-slate-900">Critical Omissions</h3>
            </div>
            <div className="space-y-3">
              {(feedback?.critical_omissions || []).map((omission, i) => (
                <div key={i} className="flex gap-3">
                  <div className="w-1.5 h-1.5 bg-red-500 rounded-full mt-2 shrink-0" />
                  <p className="text-sm text-slate-700">{omission}</p>
                </div>
              ))}
              {(!feedback?.critical_omissions || feedback.critical_omissions.length === 0) && (
                <p className="text-sm text-slate-500 italic">No critical omissions identified.</p>
              )}
            </div>
          </motion.div>
        </div>

        {/* Sample Note */}
        {feedback?.sample_note && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.3 }}
            className="mt-8 bg-white border-2 border-blue-200 rounded-2xl overflow-hidden shadow-sm"
          >
            <div className="bg-blue-50 px-8 py-6 border-b border-blue-200">
              <div className="flex items-center gap-3">
                <Lightbulb className="w-5 h-5 text-blue-600" />
                <h3 className="text-lg font-bold text-slate-900">Expert Example Note</h3>
              </div>
              <p className="text-sm text-slate-600 mt-2">Reference this for structure and completeness</p>
            </div>

            <div className="p-8 space-y-8 font-mono text-sm">
              {/* Sample Subjective */}
              <div className="border-l-4 border-purple-400 pl-6">
                <div className="font-bold text-purple-700 mb-3 uppercase tracking-wider">Subjective</div>
                <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">
                  {feedback.sample_note.subjective}
                </p>
              </div>

              {/* Sample Objective */}
              <div className="border-l-4 border-green-400 pl-6">
                <div className="font-bold text-green-700 mb-3 uppercase tracking-wider">Objective</div>
                <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">
                  {feedback.sample_note.objective}
                </p>
              </div>

              {/* Sample Assessment */}
              <div className="border-l-4 border-blue-400 pl-6">
                <div className="font-bold text-blue-700 mb-3 uppercase tracking-wider">Assessment</div>
                <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">
                  {feedback.sample_note.assessment}
                </p>
              </div>

              {/* Sample Plan */}
              <div className="border-l-4 border-amber-400 pl-6">
                <div className="font-bold text-amber-700 mb-3 uppercase tracking-wider">Plan</div>
                <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">
                  {feedback.sample_note.plan}
                </p>
              </div>
            </div>
          </motion.div>
        )}

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.4 }}
          className="mt-10 bg-gradient-to-r from-teal-500/10 to-cyan-500/10 border border-teal-200/50 rounded-2xl p-8 text-center"
        >
          <p className="text-slate-700 text-sm mb-6">Review your overall case performance and composite scores</p>
          <Link to={`/CaseCompleteFeedback?attemptId=${attemptId}`}>
            <Button className="bg-teal-600 hover:bg-teal-700 text-white">
              View Overall Results
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </motion.div>
      </div>
    </div>
  );
}