import React, { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { ChevronDown, Lightbulb, BookOpen } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import LearningCheckpointChatbot from '@/components/case/LearningCheckpointChatbot';

const STAGE_TEACHINGS = {
  1: {
    title: 'Stage 1: History & Timeline',
    items: [
      {
        action: 'Confirm timing: ≥72 hours post-ROSC',
        reason: 'Per NCS 2023, prognostication before 72h is unreliable. Early prediction risks premature withdrawal of care and misses late recovery potential.',
      },
      {
        action: 'Rule out active sedation',
        reason: 'Sedation profoundly suppresses neurologic exam and EEG findings. You cannot interpret pupil responses, motor exam, or EEG patterns if the patient is actively sedated.',
      },
      {
        action: 'Confirm core temperature ≥36°C (normothermia)',
        reason: 'Hypothermia (<35°C) depresses neurologic function independently. NCS 2023 requires normothermia or ≥72h post-rewarming before prognostication.',
      },
      {
        action: 'Document metabolic panel (glucose, electrolytes, Cr, bilirubin)',
        reason: 'Severe metabolic derangement (glucose >400, severe hyperkalemia, uremia) can mimic poor neurologic prognosis. These are reversible confounders.',
      },
      {
        action: 'Establish baseline neurologic function',
        reason: 'You assess *change from baseline*, not absolute function. Prior dementia, prior stroke, or baseline disability changes interpretation of current exam findings.',
      },
    ],
  },
  2: {
    title: 'Stage 2: Physical Exam',
    items: [
      {
        action: 'Perform bilateral pupil assessment in dim light',
        reason: 'Bilateral absent pupils (absent light reflex) at ≥72h with confounders excluded is ONE of the most reliable predictors of poor outcome (FPR <5% per NCS 2023).',
      },
      {
        action: 'Document motor response to command AND pain separately',
        reason: 'Motor response alone has high false positive rate (FPR ~30%). You must combine with EEG, imaging, and SSEP findings for defensible prognostication.',
      },
      {
        action: 'Test corneal, gag, and cough reflexes',
        reason: 'While not individually predictive, absent brainstem reflexes combined with poor exam findings strengthen overall concordance and support poor prognosis determination.',
      },
      {
        action: 'Note myoclonic activity (generalized vs focal, timing)',
        reason: 'Myoclonus after 48h or generalized myoclonus with burst-suppression EEG carries prognostic weight. Early myoclonus (<48h) has less predictive value.',
      },
    ],
  },
  3: {
    title: 'Stage 3: Ancillary Testing',
    items: [
      {
        action: 'Order SSEP if available (bilateral N20 assessment)',
        reason: 'Bilateral absent N20 cortical responses is the MOST reliable single predictor (FPR <3%). This test should be prioritized when resources allow.',
      },
      {
        action: 'Obtain EEG and assess for malignant patterns',
        reason: 'Suppressed background (<10μV), burst-suppression, absent reactivity, and no sleep-wake cycling are moderately reliable. BUT sedation must be ruled out first.',
      },
      {
        action: 'Perform CT brain ≥48h and assess for diffuse signs',
        reason: 'Diffuse loss of gray-white differentiation and sulcal effacement are moderately reliable. Early CT (<48h) may show less ischemic change and overestimate recovery potential.',
      },
      {
        action: 'Consider MRI DWI if not contraindicated (2-7 days post-ROSC)',
        reason: 'Diffuse restricted diffusion on DWI is moderately reliable. Timing matters—DWI changes evolve over days, so later imaging (day 3+) shows more mature infarction.',
      },
    ],
  },
  4: {
    title: 'Stage 4: Prognosis & Integration',
    items: [
      {
        action: 'Integrate findings: clinical exam + EEG + imaging + SSEP',
        reason: 'NCS 2023 is explicit: NO single predictor is sufficient. Multimodal concordance (e.g., absent pupils + malignant EEG + diffuse DWI) is far more reliable than isolated findings.',
      },
      {
        action: 'Assess concordance—do findings agree across modalities?',
        reason: 'Concordant poor findings = higher confidence. Discordant findings (e.g., absent pupils but reactive EEG) = greater uncertainty and warrant extended observation.',
      },
      {
        action: 'Communicate explicit uncertainty in prognosis statement',
        reason: 'Even with multiple poor prognostic indicators, up to 25% of patients may recover meaningfully. Families deserve honesty: "likely but not certain poor outcome."',
      },
      {
        action: 'Recommend extended observation (≥7-14 days) if evidence incomplete',
        reason: 'Late recovery is documented. If multimodal assessment is incomplete or discordant, NCS 2023 supports extended observation before family discussions about WLST.',
      },
      {
        action: 'Select CRASH-basic or CRASH-CT as appropriate moderately reliable model',
        reason: 'CRASH (Corticosteroid Randomisation After Significant Head injury) is a validated prognostication tool for TBI patients. Choose CRASH-basic for early assessment or CRASH-CT when CT imaging is available. It is moderately reliable per NCS 2024 when used as part of multimodal assessment.',
      },
      {
        action: 'Select IMPACT-core or IMPACT-extended as appropriate moderately reliable model',
        reason: 'IMPACT (International Mission for Prognosis and Analysis of Clinical Trials) is a moderately reliable prognostication calculator for TBI. IMPACT-core uses basic variables; IMPACT-extended includes CT and biomarker data. Both must be applied with correct patient inputs.',
      },
      {
        action: 'Explicitly state Marshall/Rotterdam/Helsinki CT scores are NOT reliable per NCS 2024',
        reason: 'NCS 2024 explicitly recommends AGAINST using Marshall, Rotterdam, or Helsinki CT scores as standalone prognostic tools. These scoring systems have poor predictive value and are not part of the current evidence-based framework. Always use CRASH-CT or IMPACT-extended with imaging data instead.',
      },
      {
        action: 'Apply CRASH calculator with correct inputs: age 44, GCS 6 at admission, pupils reactive, no major extracranial injury',
        reason: 'Accurate prognostication requires precise input variables. For this case: age 44, motor GCS 6 (or component GCS 4 if specified), pupillary status (reactive), and absence of extracranial injuries. Incorrect inputs lead to unreliable predictions.',
      },
      {
        action: 'Apply IMPACT-core inputs: age 44, motor GCS 4 (admission), pupils bilaterally reactive',
        reason: 'IMPACT-core requires: age, motor GCS score at admission, and pupillary status. For this patient: age 44, motor GCS 4, bilateral pupil reactivity. These variables feed into the IMPACT algorithm to estimate probability of unfavorable outcome.',
      },
      ],
      },
      };

export default function LearningCheckpoint() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const attemptId = searchParams.get('attemptId');
  const stageNum = parseInt(searchParams.get('stageNum')) || 1;
  const caseId = searchParams.get('caseId');
  const nextPath = searchParams.get('nextPath');

  const stageConfig = STAGE_TEACHINGS[stageNum];
  const [selectedItemIndex, setSelectedItemIndex] = useState(null);
  const [showChatbot, setShowChatbot] = useState(false);

  if (!stageConfig) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <p className="text-slate-400">Invalid stage.</p>
      </div>
    );
  }

  const handleNavigateNext = () => {
    if (nextPath) {
      const params = new URLSearchParams();
      if (attemptId) params.append('attemptId', attemptId);
      navigate(`${nextPath}?${params.toString()}`);
    } else {
      // Default: go to next stage in CasePlayer
      const nextStageNum = stageNum + 1;
      const params = new URLSearchParams();
      if (caseId) params.append('caseId', caseId);
      params.append('stage', nextStageNum);
      navigate(`/CasePlayer?${params.toString()}`);
    }
  };

  const handleChatbotDone = () => {
    // Store case context for recovery
    if (caseId && stageNum) {
      sessionStorage.setItem('returnToCaseStage', String(stageNum + 1));
    }
    window.history.back();
  };

  // Combine teaching points and chatbot when showChatbot is true
  if (showChatbot) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-950 to-slate-900 flex flex-col">
        {/* Header */}
        <div className="border-b border-slate-800 bg-slate-950/80 backdrop-blur px-4 py-6 sm:px-6 shrink-0">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 rounded-lg bg-amber-500/10">
                <Lightbulb className="w-5 h-5 text-amber-400" />
              </div>
              <h1 className="text-2xl sm:text-3xl font-bold text-white">{stageConfig.title}</h1>
            </div>
            <p className="text-slate-400">Ask questions about the teaching points below.</p>
          </div>
        </div>

        {/* Teaching points - scrollable section */}
        <div className="flex-1 overflow-y-auto p-4 py-8 sm:p-6 shrink-0">
          <div className="max-w-2xl mx-auto space-y-3">
            {stageConfig.items.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="px-4 sm:px-6 py-4 rounded-lg bg-slate-900 border border-slate-800"
              >
                <p className="text-sm sm:text-base font-semibold text-white leading-snug">{item.action}</p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Chatbot - fixed at bottom */}
        <div className="border-t border-slate-800 bg-slate-950/80 backdrop-blur shrink-0">
          <LearningCheckpointChatbot
            stageNum={stageNum}
            stageConfig={stageConfig}
            onDone={handleChatbotDone}
            caseId={caseId}
            attemptId={attemptId}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 to-slate-900 flex flex-col">
      {/* Header */}
      <div className="border-b border-slate-800 bg-slate-950/80 backdrop-blur px-4 py-6 sm:px-6 sticky top-0 z-20">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-2 rounded-lg bg-amber-500/10">
              <Lightbulb className="w-5 h-5 text-amber-400" />
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white">{stageConfig.title}</h1>
          </div>
          <p className="text-slate-400">Let's walk through what you missed and why each action matters.</p>
        </div>
      </div>

      {/* Main content with side panel */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left: List of items */}
        <div className="flex-1 p-4 py-8 sm:p-6 overflow-y-auto">
          <div className="max-w-2xl mx-auto space-y-3">
            {stageConfig.items.map((item, index) => (
              <motion.button
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                onClick={() => setSelectedItemIndex(index)}
                className={`w-full text-left px-4 sm:px-6 py-4 rounded-lg border-2 transition-all ${
                  selectedItemIndex === index
                    ? 'bg-teal-600/10 border-teal-500/50'
                    : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                }`}
              >
                <p className="text-sm sm:text-base font-semibold text-white leading-snug">{item.action}</p>
              </motion.button>
            ))}
          </div>
        </div>

        {/* Right: Side panel with teaching content */}
        <AnimatePresence>
          {selectedItemIndex !== null && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.2 }}
              className="hidden lg:flex flex-col w-80 bg-slate-900 border-l border-slate-800 overflow-hidden"
            >
              <div className="p-6 flex-1 overflow-y-auto flex flex-col">
                <div className="flex items-center gap-2 mb-4">
                  <BookOpen className="w-5 h-5 text-teal-400" />
                  <h3 className="font-semibold text-white text-sm">Why This Matters</h3>
                </div>
                <p className="text-sm text-slate-300 leading-relaxed">
                  {stageConfig.items[selectedItemIndex].reason}
                </p>
              </div>
              <button
                onClick={() => setSelectedItemIndex(null)}
                className="p-3 border-t border-slate-800 text-xs text-slate-500 hover:text-slate-300 transition"
              >
                Close
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Mobile: Overlay panel */}
        <AnimatePresence>
          {selectedItemIndex !== null && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedItemIndex(null)}
              className="lg:hidden fixed inset-0 bg-black/50 z-40"
            />
          )}
        </AnimatePresence>
        <AnimatePresence>
          {selectedItemIndex !== null && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="lg:hidden fixed bottom-0 left-0 right-0 bg-slate-900 border-t border-slate-800 p-6 z-50 max-h-[50vh] overflow-y-auto"
            >
              <div className="flex items-center gap-2 mb-4">
                <BookOpen className="w-5 h-5 text-teal-400" />
                <h3 className="font-semibold text-white text-sm">Why This Matters</h3>
              </div>
              <p className="text-sm text-slate-300 leading-relaxed mb-4">
                {stageConfig.items[selectedItemIndex].reason}
              </p>
              <button
                onClick={() => setSelectedItemIndex(null)}
                className="w-full px-4 py-2 text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 rounded transition"
              >
                Close
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Footer actions */}
      <div className="border-t border-slate-800 bg-slate-950/80 backdrop-blur px-4 py-4 sm:px-6">
        <div className="max-w-4xl mx-auto flex gap-3">
          <Button
            onClick={() => setShowChatbot(true)}
            className="flex-1 bg-teal-600 hover:bg-teal-700 text-white font-semibold"
          >
            Any Questions?
          </Button>
          <Button
            onClick={handleNavigateNext}
            variant="outline"
            className="border-slate-700 text-slate-300 hover:bg-slate-800"
          >
            Skip Learning
          </Button>
        </div>
      </div>
    </div>
  );
}