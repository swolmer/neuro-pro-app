import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { useAuth } from '@/lib/AuthContext';
import { ArrowLeft, ArrowRight, CheckCircle2, Target } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

export default function ModuleView() {
  const urlParams = new URLSearchParams(window.location.search);
  const moduleId = urlParams.get('id');
  const { user } = useAuth();

  const { data: modules = [] } = useQuery({
    queryKey: ['modules'],
    queryFn: () => base44.entities.Module.list('order'),
  });

  const module = modules.find(m => m.id === moduleId);

  const { data: cases = [] } = useQuery({
    queryKey: ['mcasesodule-', moduleId],
    queryFn: () => base44.entities.Case.filter({ module_id: moduleId }, 'order'),
    enabled: !!moduleId,
  });

  const { data: attempts = [] } = useQuery({
    queryKey: ['my-attempts'],
    queryFn: () => base44.entities.CaseAttempt.filter({ learner_email: user?.email }),
  });

  const completedAttempts = attempts.filter(a => a.status === 'completed');

  if (!module) {
    return (
      <div className="p-10 text-center text-slate-400">
        <p>Module not found.</p>
        <Link to="/Courses" className="text-teal-400 hover:underline mt-2 inline-block">Back to Courses</Link>
      </div>
    );
  }

  return (
    <div className="p-6 lg:p-10 max-w-4xl mx-auto">
      <Link to="/Courses" className="inline-flex items-center gap-2 text-sm text-slate-400 hover:text-white mb-6 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to Courses
      </Link>

      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white mb-2">{module.title}</h1>
        <p className="text-slate-400">{module.description}</p>
      </div>

      {/* Learning objectives */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 mb-6">
        <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-4">Module Overview</h3>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-slate-500">Cases</span>
            <p className="text-white font-medium">{cases.length}</p>
          </div>
          <div>
            <span className="text-slate-500">Est. Time</span>
            <p className="text-white font-medium">{module.estimated_minutes || 30} minutes</p>
          </div>
        </div>
      </div>

      {/* Cases list */}
      <div className="space-y-3">
        {cases.map((caseItem, i) => {
          const isCompleted = completedAttempts.some(a => a.case_id === caseItem.id);
          const bestScore = Math.max(0, ...completedAttempts.filter(a => a.case_id === caseItem.id).map(a => a.score || 0));

          return (
            <Link
              key={caseItem.id}
              to={`/CasePlayer?caseId=${caseItem.id}`}
              className="block bg-slate-900 border border-slate-800 rounded-2xl p-5 hover:border-teal-500/30 transition-all group"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-4">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-sm font-bold ${
                    isCompleted ? 'bg-teal-500/20 text-teal-400' : 'bg-slate-800 text-slate-400'
                  }`}>
                    {isCompleted ? <CheckCircle2 className="w-5 h-5" /> : i + 1}
                  </div>
                  <div>
                    <h3 className="font-medium text-white group-hover:text-teal-400 transition-colors">{caseItem.title}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="outline" className={`text-xs ${
                        caseItem.difficulty === 'baseline' ? 'text-sky-400 border-sky-700' :
                        caseItem.difficulty === 'guided' ? 'text-amber-400 border-amber-700' :
                        'text-purple-400 border-purple-700'
                      }`}>{caseItem.difficulty ? caseItem.difficulty.charAt(0).toUpperCase() + caseItem.difficulty.slice(1) : 'Baseline'}</Badge>
                      <span className="text-xs text-slate-500">{caseItem.stages?.length || 0} stages</span>
                    </div>
                    {caseItem.learning_objectives && (
                      <div className="mt-3 space-y-1">
                        {caseItem.learning_objectives.slice(0, 3).map((obj, j) => (
                          <div key={j} className="flex items-start gap-2 text-xs text-slate-400">
                            <Target className="w-3 h-3 mt-0.5 text-teal-500 shrink-0" />
                            {obj}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  {isCompleted && (
                    <span className={`font-mono font-medium ${
                      bestScore >= 80 ? 'text-teal-400' : bestScore >= 60 ? 'text-amber-400' : 'text-red-400'
                    }`}>{bestScore}%</span>
                  )}
                  <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-teal-400 transition-colors" />
                </div>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}