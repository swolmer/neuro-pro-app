import React, { useState, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { Save, Send, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';

// Patient info helper — pulls from caseData when available, falls back to
// the canonical NeuroSim cardiac-arrest patient set so SOAP notes never show
// stale TBI-fixture names.
function getPatientInfo(caseId = '', caseData = null) {
  // Prefer patient_name from caseData (Action item 10 — SOAP integrity)
  if (caseData?.patient_name) {
    return {
      name: caseData.patient_name,
      mrn: (caseData.case_id || '').replace(/[^A-Z0-9]/g, '').slice(-8) || '0000-0000',
      dob: '—',
      age: caseData.patient_age ? String(caseData.patient_age) : '—',
      sex: caseData.patient_sex || '—',
    };
  }
  const id = (caseId || '').toUpperCase();
  const caseNum = id.match(/(\d{3})$/)?.[1];
  switch (caseNum) {
    case '001':
      return { name: 'Marsha Johnson', mrn: 'CABASELINE001', dob: '—', age: '54', sex: 'Female' };
    case '002':
      return { name: 'Carlos Mendoza', mrn: 'CATEACH002', dob: '—', age: '67', sex: 'Male' };
    case '003':
      return { name: 'Eleanor Thompson', mrn: 'CAEVAL003', dob: '—', age: '71', sex: 'Female' };
    default:
      return { name: 'Unknown Patient', mrn: '—', dob: '—', age: '—', sex: '—' };
  }
}

export default function SOAPNotePage() {
  const navigate = useNavigate();
  const urlParams = new URLSearchParams(window.location.search);
  const attemptId = urlParams.get('attemptId');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [savedAt, setSavedAt] = useState(null);

  // SOAP sections
  const [soapNote, setSoapNote] = useState({
    subjective: '',
    objective: '',
    assessment: '',
    plan: '',
  });

  const { data: attempt } = useQuery({
    queryKey: ['attempt', attemptId],
    queryFn: async () => { const r = await base44.entities.CaseAttempt.filter({ id: attemptId }); return r[0]; },
    enabled: !!attemptId,
  });

  const { data: caseData } = useQuery({
    queryKey: ['case', attempt?.case_id],
    queryFn: async () => { if (!attempt?.case_id) return null; const r = await base44.entities.Case.filter({ id: attempt.case_id }); return r[0]; },
    enabled: !!attempt?.case_id,
  });

  const patient = getPatientInfo(caseData?.case_id);

  // Get case-specific vitals and labs
  function getCaseVitalsAndLabs(caseId = '') {
    const id = (caseId || '').toUpperCase();
    const caseNum = id.match(/(\d{3})$/)?.[1];

    switch (caseNum) {
      case '001':
      case '002':
      case '003':
        // All TBI cases: severe traumatic brain injury presentation
        return {
          vitals: [
            { label: 'HR', value: '94 bpm' },
            { label: 'BP', value: '158/92 mmHg' },
            { label: 'RR', value: '18/min (on vent)' },
            { label: 'O₂ Sat', value: '99% (FiO₂ 50%)' },
            { label: 'Temp', value: '37.2°C' },
          ],
          labs: [
            { label: 'Glucose', value: '156 mg/dL ↑' },
            { label: 'Na⁺', value: '140 mEq/L' },
            { label: 'Creatinine', value: '1.4 mg/dL ↑' },
            { label: 'Bilirubin', value: '0.9 mg/dL' },
          ],
          tests: [
            { label: 'EEG', value: 'Suppressed background, burst-suppression' },
            { label: 'SSEP', value: 'Bilateral N20 absent' },
            { label: 'CT Brain', value: 'DAI, bilateral contusions, traumatic SAH, midline shift 5mm' },
          ],
        };
      default:
        return {
          vitals: [
            { label: 'HR', value: '84 bpm' },
            { label: 'BP', value: '128/76 mmHg' },
            { label: 'RR', value: '16/min' },
            { label: 'O₂ Sat', value: '98% (RA)' },
            { label: 'Temp', value: '36.8°C' },
          ],
          labs: [
            { label: 'Glucose', value: '128 mg/dL' },
            { label: 'Na⁺', value: '138 mEq/L' },
            { label: 'Creatinine', value: '1.1 mg/dL' },
            { label: 'Bilirubin', value: '0.8 mg/dL' },
          ],
          tests: [
            { label: 'EEG', value: 'Suppressed background' },
            { label: 'SSEP', value: 'Bilateral N20 absent' },
            { label: 'CT Brain', value: 'Gray-white loss' },
          ],
        };
    }
  }

  const caseData_vitals = getCaseVitalsAndLabs(caseData?.case_id);

  const handleSave = async () => {
    if (!attemptId) return;
    setIsSaving(true);
    const fullNote = `SUBJECTIVE\n${soapNote.subjective}\n\nOBJECTIVE\n${soapNote.objective}\n\nASSESSMENT\n${soapNote.assessment}\n\nPLAN\n${soapNote.plan}`;
    await base44.entities.CaseAttempt.update(attemptId, { soap_note: fullNote });
    setSavedAt(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    setIsSaving(false);
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      const fullNote = `SUBJECTIVE\n${soapNote.subjective}\n\nOBJECTIVE\n${soapNote.objective}\n\nASSESSMENT\n${soapNote.assessment}\n\nPLAN\n${soapNote.plan}`;
      await base44.entities.CaseAttempt.update(attemptId, { soap_note: fullNote });
      const feedback = await base44.integrations.Core.InvokeLLM({
        prompt: `Expert clinical educator reviewing SOAP note for neuroprognostication case.\n\nCASE: ${caseData?.title}\nDIAGNOSIS: ${caseData?.diagnosis}\n\nNOTE:\n${fullNote}\n\nReturn JSON: {"quality_score":1-5,"strengths":["..."],"critical_omissions":["..."],"overall_feedback":"..."}`,
        model: 'claude_sonnet_4_6',
        response_json_schema: { type: 'object', properties: { quality_score: { type: 'number' }, strengths: { type: 'array', items: { type: 'string' } }, critical_omissions: { type: 'array', items: { type: 'string' } }, overall_feedback: { type: 'string' } } }
      });
      navigate(`/SOAPNoteFeedback?attemptId=${attemptId}&feedback=${encodeURIComponent(JSON.stringify(feedback))}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 px-4 py-4 sm:px-6 sticky top-0 z-20 shadow-sm">
        <div className="max-w-5xl mx-auto">
          <div className="flex items-start justify-between gap-4 mb-3">
            <div>
              <p className="text-xs text-slate-600 font-semibold uppercase tracking-wide">Neurology Consultation Note</p>
              <p className="text-lg font-bold text-slate-900 mt-1">{patient.name} · MRN {patient.mrn}</p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              {savedAt && <span className="text-xs text-green-700 font-medium">Saved {savedAt}</span>}
              <button
                onClick={handleSave}
                disabled={isSaving || !attemptId}
                className="px-3 py-1.5 rounded border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-sm disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer transition"
              >
                {isSaving ? '...' : 'Save'}
              </button>
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div><span className="text-slate-600">DOB:</span> <span className="font-semibold text-slate-900">{patient.dob}</span></div>
            <div><span className="text-slate-600">Age:</span> <span className="font-semibold text-slate-900">{patient.age}y {patient.sex}</span></div>
            <div><span className="text-slate-600">Attending:</span> <span className="font-semibold text-slate-900">___</span></div>
            <div><span className="text-slate-600">Date:</span> <span className="font-semibold text-slate-900">{new Date().toLocaleDateString()}</span></div>
          </div>
        </div>
      </div>

      {/* Main note area with sidebar */}
      <div className="p-4 sm:p-6 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left sidebar - Clinical data */}
          <div className="lg:col-span-1 space-y-4">
            {/* Vitals panel */}
            <div className="bg-white rounded-lg border border-slate-200 shadow-sm p-4">
              <p className="text-xs font-semibold text-slate-700 uppercase tracking-wide mb-3">Vitals</p>
              <div className="space-y-2 text-sm">
                {caseData_vitals.vitals.map((v, i) => (
                  <div key={i} className="flex justify-between"><span className="text-slate-600">{v.label}</span><span className="font-semibold text-slate-900">{v.value}</span></div>
                ))}
              </div>
            </div>

            {/* Labs panel */}
            <div className="bg-white rounded-lg border border-slate-200 shadow-sm p-4">
              <p className="text-xs font-semibold text-slate-700 uppercase tracking-wide mb-3">Labs</p>
              <div className="space-y-2 text-sm">
                {caseData_vitals.labs.map((l, i) => (
                  <div key={i} className="flex justify-between"><span className="text-slate-600">{l.label}</span><span className="font-semibold text-slate-900">{l.value}</span></div>
                ))}
              </div>
            </div>

            {/* Test Results panel */}
            <div className="bg-white rounded-lg border border-slate-200 shadow-sm p-4">
              <p className="text-xs font-semibold text-slate-700 uppercase tracking-wide mb-3">Test Results</p>
              <div className="space-y-2 text-sm">
                {caseData_vitals.tests.map((t, i) => (
                  <div key={i}><p className="text-slate-600">{t.label}</p><p className="font-semibold text-slate-900 text-xs">{t.value}</p></div>
                ))}
              </div>
            </div>
          </div>

          {/* Right side - SOAP sections */}
          <div className="lg:col-span-2 bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 space-y-4">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 uppercase tracking-wide">Subjective</label>
              <Textarea
                value={soapNote.subjective}
                onChange={(e) => setSoapNote({ ...soapNote, subjective: e.target.value })}
                placeholder="Chief complaint, HPI, ROS, PMH, PSH, medications, allergies, FHx, SHx..."
                className="w-full border-slate-300 focus:ring-1 focus:ring-teal-500 font-mono text-sm resize-none"
                rows={6}
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 uppercase tracking-wide">Objective</label>
              <Textarea
                value={soapNote.objective}
                onChange={(e) => setSoapNote({ ...soapNote, objective: e.target.value })}
                placeholder="Vitals, general exam, systems, labs, imaging, EEG, SSEP..."
                className="w-full border-slate-300 focus:ring-1 focus:ring-teal-500 font-mono text-sm resize-none"
                rows={6}
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 uppercase tracking-wide">Assessment</label>
              <Textarea
                value={soapNote.assessment}
                onChange={(e) => setSoapNote({ ...soapNote, assessment: e.target.value })}
                placeholder="Primary diagnosis and clinical reasoning..."
                className="w-full border-slate-300 focus:ring-1 focus:ring-teal-500 font-mono text-sm resize-none"
                rows={4}
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 uppercase tracking-wide">Plan</label>
              <Textarea
                value={soapNote.plan}
                onChange={(e) => setSoapNote({ ...soapNote, plan: e.target.value })}
                placeholder="Clinical management and follow-up..."
                className="w-full border-slate-300 focus:ring-1 focus:ring-teal-500 font-mono text-sm resize-none"
                rows={4}
              />
            </div>

            {/* Footer */}
            <div className="border-t border-slate-200 bg-slate-50 px-6 py-4 flex gap-3 justify-between">
              <div className="text-xs text-slate-600">
                {(soapNote.subjective + soapNote.objective + soapNote.assessment + soapNote.plan).split('\n').length - 1} lines
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={handleSave}
                  disabled={isSaving || !attemptId}
                  variant="outline"
                  className="border-slate-300 text-slate-700 hover:bg-white"
                  size="sm"
                >
                  {isSaving ? <Loader2 className="w-3.5 h-3.5 animate-spin mr-1.5" /> : <Save className="w-3.5 h-3.5 mr-1.5" />}
                  Save Draft
                </Button>
                <Button
                  onClick={handleSubmit}
                  disabled={isSubmitting || !attemptId}
                  className="bg-slate-900 hover:bg-slate-800 text-white"
                  size="sm"
                >
                  {isSubmitting ? <Loader2 className="w-3.5 h-3.5 animate-spin mr-1.5" /> : <Send className="w-3.5 h-3.5 mr-1.5" />}
                  Submit for Feedback
                </Button>
              </div>
            </div>
            </div>
            </div>
            </div>
            </div>
            </div>
            );
            }