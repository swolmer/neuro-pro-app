import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Brain, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Welcome() {
  const [tab, setTab] = useState('Overview');

  return (
    <div className="w-full min-h-screen bg-slate-950 text-white">

      {/* HERO */}
      <div className="w-full border-b border-slate-800 px-4 py-10">
        <div className="w-full max-w-6xl mx-auto grid lg:grid-cols-2 gap-10 items-center">

          {/* LEFT SIDE */}
          <div>

            <div className="flex items-center gap-3 mb-5">
              <div className="w-12 h-12 bg-gradient-to-br from-teal-400 to-cyan-500 rounded-2xl flex items-center justify-center shadow-lg shadow-teal-500/20">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="font-semibold text-sm tracking-tight">NeuroSim</p>
                <p className="text-xs text-slate-400">Virtual Neuro-ICU · NCS 2023/2024</p>
              </div>
            </div>

            <h1 className="text-3xl sm:text-4xl font-bold mb-4 leading-tight">
              Designing a Virtual Neuro-ICU
            </h1>
            <p className="text-teal-400 text-sm font-medium mb-3">
              An LLM-Driven Simulation for Neuroprognostication Guideline Education
            </p>

            <p className="text-slate-400 text-base mb-4 max-w-lg">
              An adaptive, guideline-adherent training platform for post–cardiac arrest neuroprognostication, aligned with NCS 2023/2024 standards.
            </p>

            <p className="text-xs text-slate-500 mb-6 max-w-lg">
              Authors: Sophie Wolmer, MPhil; Casey Albin, MD; Rameez Merchant, MD; Justin Falk, MD
            </p>

            <Link to="/Courses">
              <Button className="bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-600 hover:to-cyan-600 px-6 py-3 text-base shadow-lg shadow-teal-500/20">
                Start Learning
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>

          </div>

          {/* RIGHT SIDE (visual card) */}
          <div className="hidden lg:block">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
              <p className="text-sm text-slate-400 mb-4">Three-Stage Clinical Reasoning Workflow</p>
              <ul className="space-y-3 text-sm">
                <li className="text-slate-200">1. History &amp; Physical Examination</li>
                <li className="text-slate-200">2. Ancillary Test Ordering</li>
                <li className="text-slate-200">3. Multimodal Prognostic Determination</li>
              </ul>
              <div className="mt-5 pt-5 border-t border-slate-800 text-xs text-slate-500">
                Three cases: baseline · teaching · post-teaching evaluation
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* TABS */}
      <div className="w-full border-b border-slate-800 bg-slate-900/80 backdrop-blur">
        <div className="w-full max-w-6xl mx-auto flex overflow-x-auto px-2">
          {['Overview','How It Works','Evidence'].map(t => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`px-5 py-3 text-sm whitespace-nowrap transition ${
                tab === t
                  ? 'text-teal-400 border-b-2 border-teal-400'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* CONTENT */}
      <div className="w-full px-4 py-10">
        <div className="w-full max-w-6xl mx-auto">

          {/* OVERVIEW */}
          {tab === 'Overview' && (
            <div className="grid md:grid-cols-2 gap-6">
              <Card title="Why This Matters">
                Post–cardiac arrest neuroprognostication is one of the highest-stakes decisions in critical care. Premature or pessimistic prognoses contribute to withdrawal of life-sustaining therapy in patients who may have achieved meaningful recovery.
              </Card>

              <Card title="What This Platform Does">
                A virtual Neuro-ICU that delivers adaptive, guideline-adherent training. Free-text natural-language interaction with a virtual ICU team, real ancillary results, and structured prognostic synthesis — aligned with NCS 2023/2024.
              </Card>
            </div>
          )}

          {/* HOW IT WORKS */}
          {tab === 'How It Works' && (
            <div className="grid md:grid-cols-3 gap-5">
              <Card title="Stage 1 — History &amp; Physical Examination">
                Gather patient information through free-text natural-language interaction with the virtual ICU team. Perform a structured neurologic exam.
              </Card>
              <Card title="Stage 2 — Ancillary Test Ordering">
                Actively order and interpret EEG, SSEPs, CT, and MRI. Receive real-time results and appropriate imaging.
              </Card>
              <Card title="Stage 3 — Multimodal Prognostic Determination">
                Synthesize all available data to formulate and communicate a structured prognosis with appropriate uncertainty.
              </Card>
              <Card title="Case 1 — Baseline">
                Probes the learner&apos;s pre-teaching reasoning under prognostic pressure. No structured guidance.
              </Card>
              <Card title="Case 2 — Teaching">
                Day-1 consult → Day-4 synthesis. Reinforces the ≥72 h rule, correct study timing, and structured family communication.
              </Card>
              <Card title="Case 3 — Post-Teaching Evaluation">
                Tests application of the framework to a new scenario. Scored against the learner&apos;s Case 1 baseline.
              </Card>
            </div>
          )}

          {/* EVIDENCE */}
          {tab === 'Evidence' && (
            <div className="space-y-5">
              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5">
                <p className="font-semibold mb-2">Primary guideline</p>
                <p className="text-sm text-slate-300">
                  Rajajee V, Muehlschlegel S, Wartenberg KE, et al. <span className="italic">Guidelines for Neuroprognostication in Comatose Adult Survivors of Cardiac Arrest.</span> Neurocrit Care. 2023;38:533–563. doi:10.1007/s12028-023-01688-3
                </p>
                <p className="text-xs text-slate-500 mt-2">
                  Every case in this simulator — its critical actions, predictor framing, timing, and counseling language — is trained on this NCS 2023 guideline.
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-5">
                <Card title="Reliable predictors of poor outcome (FPR ≤3%)">
                  Bilateral absence of pupillary light response ≥72 h post-ROSC (pupillometry preferred); bilateral absence of N20 SSEP ≥48 h post-ROSC (with preserved Erb&apos;s point response).
                </Card>
                <Card title="Moderately reliable predictors (FPR ≤5%)">
                  Diffuse DWI restriction on MRI 2–7 days; suppressed/burst-suppression EEG ≥72 h off sedation; diffuse loss of gray-white differentiation on CT ≥48 h.
                </Card>
                <Card title="Not reliable in isolation">
                  Age, initial rhythm, time-to-ROSC, corneal reflex alone, motor response alone, myoclonus &lt;48 h without EEG, NSE alone, OHCA/CAHP/GOFAR prediction models.
                </Card>
                <Card title="Good Practice Statements">
                  Defer ≥72 h from ROSC / rewarming; assess off sedation and confounders; distinguish overall from neurological prognosis; multimodal — never single-variable; counsel uncertainty and recovery timeline; offer extended observation for indeterminate cases.
                </Card>
              </div>

              <div className="grid md:grid-cols-2 gap-5">
                <Card title="Self-fulfilling prophecy">A core teaching point: avoid premature withdrawal of life-sustaining therapy when reassuring predictors are present or confounders are unresolved.</Card>
                <Card title="Counseling language by reliability tier">Reliable → &quot;very likely poor outcome.&quot; Multiple moderately reliable → &quot;likely poor&quot; with &quot;substantial uncertainty.&quot; No reliable predictors → counsel uncertainty; recovery may take days to several months.</Card>
              </div>
            </div>
          )}

        </div>
      </div>

    </div>
  );
}

function Card({ title, children }) {
  return (
    <div className="bg-slate-900/80 backdrop-blur border border-slate-800 rounded-xl p-5 shadow-sm hover:border-slate-700 transition">
      <p className="font-semibold mb-2">{title}</p>
      <p className="text-sm text-slate-400">{children}</p>
    </div>
  );
}
