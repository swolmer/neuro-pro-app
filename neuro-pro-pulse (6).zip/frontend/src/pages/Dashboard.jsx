import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/lib/AuthContext';
import { Link } from 'react-router-dom';
import { BookOpen, Trophy, Clock, Target, ArrowRight, Brain } from 'lucide-react';
import StatCard from '../components/dashboard/StatCard';
import ProgressRing from '../components/dashboard/ProgressRing';
import { Skeleton } from '@/components/ui/skeleton';

export default function Dashboard() {
  const { user } = useAuth();



  const { data: attempts = [], isLoading: attemptsLoading } = useQuery({
    queryKey: ['my-attempts'],
    queryFn: () => base44.entities.CaseAttempt.filter({ learner_email: user?.email }),
  });

  const { data: cases = [] } = useQuery({
    queryKey: ['cases'],
    queryFn: () => base44.entities.Case.list(),
  });

  const completedAttempts = attempts.filter(a => a.status === 'completed');
  
  // Active cases for this learner: cardiac arrest cases only.
  const activeCases = cases.filter(c => c.case_id?.toUpperCase().startsWith('CA-'));
  
  const avgScore = completedAttempts.length > 0 
    ? Math.round(completedAttempts.reduce((sum, a) => sum + (a.score || 0), 0) / completedAttempts.length)
    : 0;
  const totalCases = activeCases.length;
  const completedCases = new Set(completedAttempts.map(a => a.case_id)).size;
  const overallProgress = totalCases > 0 ? (completedCases / totalCases) * 100 : 0;
  
  // Check if all 3 cases completed for progress overview
  const allCasesCompleted = completedCases >= 3;



  return (
    <div className="p-6 lg:p-10 max-w-7xl mx-auto">
      {/* Welcome header */}
      <div className="mb-10">
        <h1 className="text-3xl font-bold text-white mb-2">
          Welcome back, {user?.full_name?.split(' ')[0] || 'Learner'}
        </h1>
        <p className="text-slate-400">Continue your neuroprognostication training journey.</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
        <StatCard label="Cases Completed" value={completedCases} icon={BookOpen} color="teal" />
        <StatCard label="Average Score" value={`${avgScore}%`} icon={Trophy} color="cyan" />
        <StatCard label="Total Attempts" value={attempts.length} icon={Target} color="violet" />
        <StatCard label="Cases Available" value={cases.length} icon={Brain} color="amber" />
      </div>

      {/* Progress & modules */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-sm">
        <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-6">Course Progress</h3>
        <div className="flex flex-col items-center">
          <ProgressRing progress={overallProgress} size={120} strokeWidth={8} />
          <p className="text-sm text-slate-400 mt-4">{completedCases} of {totalCases} cases completed</p>
        </div>
        
        {/* Recent scores */}
        {completedAttempts.length > 0 && (
          <div className="mt-6 pt-6 border-t border-slate-800">
            <h4 className="text-xs font-semibold text-slate-400 uppercase mb-3">Recent Scores</h4>
            <div className="space-y-2">
              {completedAttempts.slice(-3).reverse().map((attempt, i) => {
                const caseInfo = cases.find(c => c.id === attempt.case_id);
                return (
                  <div key={i} className="flex items-center justify-between text-sm">
                    <span className="text-slate-300 truncate">{caseInfo?.title || 'Case'}</span>
                    <span className={`font-mono font-medium ${
                      (attempt.score || 0) >= 80 ? 'text-teal-400' : (attempt.score || 0) >= 60 ? 'text-amber-400' : 'text-red-400'
                    }`}>{attempt.score || 0}%</span>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Placeholder to maintain flow */}
      <div className="hidden lg:block"></div>
      <div className="lg:col-span-2 hidden">
        <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-4">Full Clinical Cases</h3>
      </div>

      {/* Progress Overview */}
      <div className="mt-10 bg-slate-900 border border-slate-800 rounded-2xl p-6">
        <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-4">Overall Progress Review</h3>
        
        {allCasesCompleted ? (
          <div>
            <p className="text-slate-300 mb-4">Your growth across all three cases:</p>
            <Link
              to="/ProgressAssessment"
              className="inline-flex items-center gap-2 px-6 py-3 bg-teal-600 hover:bg-teal-700 text-white font-semibold rounded-xl transition-all group"
            >
              View Detailed Progress Assessment
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        ) : (
          <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4">
            <p className="text-slate-400 text-sm">
              📊 <span className="font-semibold">Progress overview available after you complete all 3 cases.</span>
            </p>
            <p className="text-xs text-slate-500 mt-2">
              You've completed {completedCases} of 3 cases. Keep going!
            </p>
          </div>
        )}
      </div>
    </div>
  );
}