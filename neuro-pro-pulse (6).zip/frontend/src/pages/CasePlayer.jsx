import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/lib/AuthContext';
import { useNavigate } from 'react-router-dom';
import PatientPanel from '@/components/case/PatientPanel';
import ChatPanel from '@/components/case/ChatPanel.jsx';
import StageProgress from '../components/case/StageProgress';
import PostCaseSurvey from '../components/study/PostCaseSurvey';
import ProgramTour from '@/components/onboarding/ProgramTour';
import NextStepsSidebar from '@/components/case/NextStepsSidebar';
import ReflectionCheckpoint from '@/components/case/ReflectionCheckpoint';
import SynthesisGuidance from '@/components/case/SynthesisGuidance';
import ClinicalJustification from '@/components/case/ClinicalJustification';
import CommunicationGuidance from '@/components/case/CommunicationGuidance';
import SOAPNoteModal from '@/components/case/SOAPNoteModal';
import MissedItemsCheckpoint from '@/components/case/MissedItemsCheckpoint';
import EpicCaseCompletionModal from '@/components/case/EpicCaseCompletionModal';
import PreBriefScreen from '@/components/case/PreBriefScreen';
import ConsentCheckIn from '@/components/case/ConsentCheckIn';
import GuidelinesTeaching from '@/components/case/GuidelinesTeaching';
import AncillaryTestOrdering from '@/components/case/AncillaryTestOrdering';
import PrognosisSelector from '@/components/case/PrognosisSelector';
import AncillaryTestingFeedback from '@/components/case/AncillaryTestingFeedback';
import PrognosisFeedback from '@/components/case/PrognosisFeedback';
import PrognosticCategoryTeaching from '@/components/case/PrognosticCategoryTeaching';
import { Loader2, AlertTriangle, Lightbulb, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function CasePlayer() {
  const urlParams = new URLSearchParams(window.location.search);
  const caseId = urlParams.get('caseId');
  const isFacilitator = urlParams.get('facilitator') === 'true';
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const demoEmail = 'demo@caseplayer.local';
  const user = { email: demoEmail, full_name: 'Demo Learner' };

  const [currentStage, setCurrentStage] = useState(1);
  const [messages, setMessages] = useState([]);
  const [actionsPerformed, setActionsPerformed] = useState([]);
  const [cognitiveErrors, setCognitiveErrors] = useState([]);
  const [hypothesisTimestamps, setHypothesisTimestamps] = useState([]);
  const [attemptId, setAttemptId] = useState(null);
  const [participantId, setParticipantId] = useState('');
  const startTimeRef = useRef(Date.now());
  const [showSurvey, setShowSurvey] = useState(false);
  const [completedAttemptId, setCompletedAttemptId] = useState(null);
  const actionIndexRef = useRef(0);
  const [showPreBrief, setShowPreBrief] = useState(true);
  const [showConsent, setShowConsent] = useState(false);
  const [learnerName, setLearnerName] = useState('');
  const [showTour, setShowTour] = useState(false);
  const [tourCompleted, setTourCompleted] = useState(false);
  const initializeRef = useRef(false);
  const [showMissedItemsCheckpoint, setShowMissedItemsCheckpoint] = useState(false);
  const [showCompletionPrompt, setShowCompletionPrompt] = useState(false);
  const [isGeneratingFeedback, setIsGeneratingFeedback] = useState(false);
  const [completionData, setCompletionData] = useState({ feedback: '', scoreBreakdown: {} });
  const [orderedTests, setOrderedTests] = useState([]);
  const [testResults, setTestResults] = useState({});
  const [testRelevance, setTestRelevance] = useState({});
  const [activeSpecialStage, setActiveSpecialStage] = useState(null); // 'ancillary' | 'prognosis' | null
  const [showGuidelinesTeaching, setShowGuidelinesTeaching] = useState(false);
  const [showAncillaryFeedback, setShowAncillaryFeedback] = useState(false);
  const [showPrognosisFeedback, setShowPrognosisFeedback] = useState(false);
  const [showPrognosticTeaching, setShowPrognosticTeaching] = useState(false);

  const handleTourComplete = () => {
    setShowTour(false);
    setTourCompleted(true);
  };

  // Handle returning from LearningCheckpoint with stage from sessionStorage
  useEffect(() => {
    const returnStage = sessionStorage.getItem('returnToCaseStage');
    if (returnStage) {
      const stage = parseInt(returnStage);
      sessionStorage.removeItem('returnToCaseStage');
      
      // Skip PreBrief and Consent if returning to stage 2+
      setShowPreBrief(false);
      setShowConsent(false);
      
      if (stage === 2) {
        setCurrentStage(2);
        setLearnerName(user.full_name || 'Learner');
        const stageMsg = { 
          role: 'assistant', 
          content: `---\n\n**Stage 2: Physical Exam**\n\nYou are now at the bedside. Perform a targeted neurological examination to assess the patient's current clinical status.`, 
          timestamp: new Date().toISOString() 
        };
        setMessages([stageMsg]);
      } else if (stage === 3) {
        setCurrentStage(3);
        setLearnerName(user.full_name || 'Learner');
        setActiveSpecialStage('ancillary');
      }
    }
  }, []);

  const { data: caseData, isLoading: caseLoading } = useQuery({
    queryKey: ['case', caseId],
    queryFn: async () => {
      const cases = await base44.entities.Case.filter({ id: caseId });
      return cases[0];
    },
    enabled: !!caseId,
  });

  // Determine case type and teaching status - explicit case separation
  const getCaseType = () => {
    if (!caseData?.case_id) return null;
    const id = caseData.case_id.toUpperCase();
    const caseNum = id.match(/(\d{3})$/)?.[1];
    if (caseNum === '001') return 'case1';
    if (caseNum === '002') return 'case2';
    if (caseNum === '003') return 'case3';
    return null;
  };
  
  const caseType = getCaseType();
  const isTeachingCase = caseType === 'case2';

  const { data: participantProfile } = useQuery({
    queryKey: ['my-profile-player', user?.email],
    queryFn: async () => {
      const p = await base44.entities.ParticipantProfile.filter({ user_email: user?.email });
      return p[0] || null;
    },
    enabled: !!user?.email,
    onSuccess: (p) => { if (p?.participant_id) setParticipantId(p.participant_id); },
    staleTime: 0,
    cacheTime: 0,
  });

  useEffect(() => {
    if (!caseData || !learnerName || initializeRef.current) return;
    initializeRef.current = true;
    const initAttempt = async () => {
      const newAttempt = await base44.entities.CaseAttempt.create({
        case_id: caseId,
        learner_email: user.email,
        learner_name: learnerName,
        status: 'in_progress',
        current_stage: 1,
        started_at: new Date().toISOString(),
        actions_performed: [],
        conversation_history: [],
        cognitive_errors: [],
        hypothesis_timestamps: [],
      });
      setAttemptId(newAttempt.id);
      const pid = participantProfile?.participant_id || '';
      setParticipantId(pid);
      await base44.entities.EventLog.create({
        user_email: user.email,
        participant_id: pid,
        attempt_id: newAttempt.id,
        case_id: caseId,
        event_type: 'case_started',
        stage_number: 1,
        elapsed_seconds: 0,
        timestamp: new Date().toISOString(),
      });
      const introMsg = {
        role: 'assistant',
        content: `📞 **ICU Consult Request - ${new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}**\n\n${caseData.patient_summary}\n\n---\n\n*The ICU team is at the bedside and ready to assist. Ask them anything; they will only share information you explicitly request.*`,
        timestamp: new Date().toISOString(),
      };
      setMessages([introMsg]);
    };
    initAttempt();
  }, [caseData, learnerName, caseId]);



  const saveProgress = async (updatedMessages, updatedActions, updatedStage, updatedErrors, updatedHypotheses) => {
    if (!attemptId) return;
    await base44.entities.CaseAttempt.update(attemptId, {
      conversation_history: updatedMessages ?? messages,
      actions_performed: updatedActions ?? actionsPerformed,
      current_stage: updatedStage ?? currentStage,
      cognitive_errors: updatedErrors ?? cognitiveErrors,
      hypothesis_timestamps: updatedHypotheses ?? hypothesisTimestamps,
    });
  };

  const handleNewMessage = async (msg) => {
    if (msg.type === 'action_classified') {
      actionIndexRef.current += 1;
      const orderIndex = actionIndexRef.current;
      const elapsed = msg.elapsed_seconds;
      const newAction = {
        stage: msg.stage,
        action: msg.matched_critical_action || msg.action_text,
        action_text: msg.action_text,
        action_type: msg.action_type,
        is_critical: msg.is_critical,
        points: msg.points,
        order_index: orderIndex,
        elapsed_seconds: elapsed,
        timestamp: new Date().toISOString(),
      };
      const newActions = [...actionsPerformed, newAction];
      setActionsPerformed(newActions);
      let newErrors = cognitiveErrors;
      let newHypotheses = hypothesisTimestamps;
      const eventLogs = [];
      if (msg.cognitive_error) {
        const errorEntry = { ...msg.cognitive_error, message_text: msg.action_text, elapsed_seconds: elapsed, timestamp: new Date().toISOString() };
        newErrors = [...cognitiveErrors, errorEntry];
        setCognitiveErrors(newErrors);
        eventLogs.push(base44.entities.EventLog.create({ user_email: user.email, participant_id: participantId, attempt_id: attemptId, case_id: caseId, event_type: 'cognitive_error_detected', action_text: msg.action_text, event_data: errorEntry, stage_number: msg.stage, elapsed_seconds: elapsed, timestamp: new Date().toISOString() }).catch(() => {}));
      }
      if (msg.hypothesis_detected) {
        const hypothesisEntry = { hypothesis: msg.hypothesis_detected.hypothesis, is_correct: msg.hypothesis_detected.is_correct, elapsed_seconds: elapsed, timestamp: new Date().toISOString() };
        newHypotheses = [...hypothesisTimestamps, hypothesisEntry];
        setHypothesisTimestamps(newHypotheses);
        eventLogs.push(base44.entities.EventLog.create({ user_email: user.email, participant_id: participantId, attempt_id: attemptId, case_id: caseId, event_type: 'hypothesis_formed', action_text: msg.hypothesis_detected.hypothesis, event_data: hypothesisEntry, stage_number: msg.stage, elapsed_seconds: elapsed, timestamp: new Date().toISOString() }).catch(() => {}));
      }
      eventLogs.push(base44.entities.EventLog.create({ user_email: user.email, participant_id: participantId, attempt_id: attemptId, case_id: caseId, event_type: 'action_classified', action_text: msg.action_text, action_type: msg.action_type, action_correct: msg.is_critical, stage_number: msg.stage, action_order_index: orderIndex, elapsed_seconds: elapsed, event_data: { points: msg.points, matched: msg.matched_critical_action }, timestamp: new Date().toISOString() }).catch(() => {}));
      await Promise.all(eventLogs);
      saveProgress(null, newActions, null, newErrors, newHypotheses);
      return;
    }

    const newMessages = [...messages, msg];
    setMessages(newMessages);
    if (msg.role === 'assistant') {
      saveProgress(newMessages, null, null, null, null);
    }
  };

  // Fixed 4-stage flow (Debrief & SOAP accessed from feedback page)
  const FIXED_STAGES = [
    { stage_name: 'History' },
    { stage_name: 'Physical Exam' },
    { stage_name: 'Ancillary Testing' },
    { stage_name: 'Prognosis' },
  ];

  const handleAdvanceStage = async () => {
    // From History (1) or Physical Exam (2), show missed items checkpoint
    if (currentStage === 1 || currentStage === 2) {
      setShowMissedItemsCheckpoint(true);
    } else if (currentStage === 3) {
      // From Ancillary (already has confirmation), go straight to prognosis
      setActiveSpecialStage('prognosis');
    }
  };

  const handleOrderTest = (testId, result) => {
    setOrderedTests(prev => prev.includes(testId) ? prev : [...prev, testId]);
    setTestResults(prev => ({ ...prev, [testId]: result }));
    handleNewMessage({
      type: 'action_classified',
      action: `Order ${testId}`,
      action_text: `Order ${testId}`,
      action_type: 'critical',
      points: 2,
      is_critical: true,
      matched_critical_action: `Order ${testId}`,
      stage: currentStage,
      elapsed_seconds: Math.round((Date.now() - startTimeRef.current) / 1000),
    });
  };

  const handleContinueAfterCheckpoint = async () => {
    setShowMissedItemsCheckpoint(false);
    // For teaching case (CA-2), show LearningCheckpoint; for others, advance directly
    if (currentStage === 1 || currentStage === 2) {
      if (isTeachingCase) {
        navigate(`/LearningCheckpoint?attemptId=${attemptId}&stageNum=${currentStage}&caseId=${caseId}`);
      } else {
        // Advance directly to next stage for non-teaching cases
        setCurrentStage(currentStage + 1);
      }
    }
  };

  const handleBackFromCheckpoint = () => setShowMissedItemsCheckpoint(false);



  const handleComplete = async () => {
    if (!attemptId || !caseData) return;
    setIsGeneratingFeedback(true);
    try {
      const timeSpent = Math.round((Date.now() - startTimeRef.current) / 1000);
      const allCriticalActions = caseData.stages?.flatMap(s => s.critical_actions || []) || [];
      const expertPath = allCriticalActions;
      const completedCritical = actionsPerformed.filter(a => a.is_critical || a.action_type === 'critical');
      const matchedCriticals = allCriticalActions.filter(ca => completedCritical.some(a => (a.action || '').toLowerCase().includes(ca.toLowerCase().split(' ').slice(0, 2).join(' ')) || (a.action_text || '').toLowerCase().includes(ca.toLowerCase().split(' ').slice(0, 2).join(' '))));
      const missedActions = allCriticalActions.filter(ca => !matchedCriticals.includes(ca));
      const criticalActionScore = allCriticalActions.length > 0 ? Math.round((matchedCriticals.length / allCriticalActions.length) * 100) : 100;
      const reasoningPathScore = actionsPerformed.reduce((sum, a) => sum + (a.points || 0), 0);
      const learnerCriticalPath = actionsPerformed.filter(a => a.is_critical || a.action_type === 'critical').map(a => a.action || a.action_text);
      let orderMatches = 0;
      learnerCriticalPath.forEach((action, idx) => { const expertIdx = expertPath.findIndex(e => action.toLowerCase().includes(e.toLowerCase().split(' ').slice(0, 2).join(' '))); if (expertIdx !== -1 && expertIdx === idx) orderMatches++; });
      const orderAccuracyScore = expertPath.length > 0 ? Math.round((orderMatches / expertPath.length) * 100) : 50;
      const totalActions = actionsPerformed.length || 1;
      const minExpectedActions = allCriticalActions.length || 1;
      const diagnosticEfficiencyScore = Math.round(Math.min(100, (minExpectedActions / totalActions) * 100));
      const firstCorrectHypothesis = hypothesisTimestamps.find(h => h.is_correct);
      const firstCorrectHypothesisSeconds = firstCorrectHypothesis?.elapsed_seconds ?? null;
      const aiScoringPrompt = `You are a clinical education expert evaluating a medical learner's reasoning during a neuroprognostication simulation.\n\nCASE: ${caseData.title}\nDIAGNOSIS: ${caseData.diagnosis}\nEXPERT PATH: ${expertPath.join(' → ')}\n\nLEARNER'S REASONING PATH (in order):\n${actionsPerformed.map((a, i) => `${i+1}. [${a.action_type || 'neutral'}] ${a.action_text || a.action} (${a.points >= 0 ? '+' : ''}${a.points || 0} pts)`).join('\n')}\n\nScore this learner's reasoning from 1–5 and provide structured feedback.\n\nReturn ONLY valid JSON:\n{\n  "score": <1-5>,\n  "strengths": ["strength 1", "strength 2"],\n  "weaknesses": ["weakness 1"],\n  "overall_feedback": "2-3 sentence narrative assessment"\n}`;
      const aiReasoning = await base44.integrations.Core.InvokeLLM({ prompt: aiScoringPrompt, model: 'claude_sonnet_4_6', response_json_schema: { type: "object", properties: { score: { type: "number" }, strengths: { type: "array", items: { type: "string" } }, weaknesses: { type: "array", items: { type: "string" } }, overall_feedback: { type: "string" } } } });
      const aiReasoningScore = aiReasoning?.score || 3;
      const aiReasoningFeedback = JSON.stringify(aiReasoning);
      const compositeScore = Math.round(0.4 * criticalActionScore + 0.2 * orderAccuracyScore + 0.2 * diagnosticEfficiencyScore + 0.2 * ((aiReasoningScore / 5) * 100));
      const debriefPrompt = `Generate a structured case debrief for a neuroprognostication training case.\n\nCase: ${caseData.title}\nDiagnosis: ${caseData.diagnosis}\nComposite Score: ${compositeScore}%\nCritical Action Score: ${criticalActionScore}% (${matchedCriticals.length}/${allCriticalActions.length})\nOrder Accuracy: ${orderAccuracyScore}%\nDiagnostic Efficiency: ${diagnosticEfficiencyScore}% (${totalActions} total actions)\nAI Reasoning Score: ${aiReasoningScore}/5\nCritical actions performed: ${matchedCriticals.join(', ') || 'None identified'}\nMissed critical actions: ${missedActions.join(', ') || 'None'}\nBest practice: ${caseData.best_practice_summary || ''}\n\nFormat with:\n1. Case Summary with diagnosis\n2. Clinical Reasoning Analysis\n3. Score Breakdown\n4. Teaching Points\n\nCRITICAL MARKDOWN TABLE RULES:\n- NEVER add extra pipes or text after the closing |\n- Each row: | data1 | data2 | data3 | (exactly one | after data3)\n- Separator: |---|---|---| (exactly this format)\n- Do NOT use any emojis\n- Use blockquotes (>) for clinical principles\n- Keep professional and evidence-based`;
      const debrief = await base44.integrations.Core.InvokeLLM({ prompt: debriefPrompt, model: 'claude_sonnet_4_6' });
      await base44.entities.CaseAttempt.update(attemptId, { status: 'completed', score: compositeScore, reasoning_path_score: reasoningPathScore, critical_action_score: criticalActionScore, order_accuracy_score: orderAccuracyScore, diagnostic_efficiency_score: diagnosticEfficiencyScore, ai_reasoning_score: aiReasoningScore, ai_reasoning_feedback: aiReasoningFeedback, composite_reasoning_score: compositeScore, first_correct_hypothesis_seconds: firstCorrectHypothesisSeconds, cognitive_errors: cognitiveErrors, hypothesis_timestamps: hypothesisTimestamps, score_breakdown: { total_critical: allCriticalActions.length, completed_critical: matchedCriticals.length, correct_actions: matchedCriticals, missed_actions: missedActions, reasoning_path_score: reasoningPathScore, order_accuracy_score: orderAccuracyScore, diagnostic_efficiency_score: diagnosticEfficiencyScore, ai_reasoning_score: aiReasoningScore, ai_reasoning_feedback: aiReasoning, composite_score: compositeScore, total_actions_taken: totalActions, cognitive_error_count: cognitiveErrors.length, first_correct_hypothesis_seconds: firstCorrectHypothesisSeconds }, ai_debrief: debrief, time_spent_seconds: timeSpent, completed_at: new Date().toISOString(), conversation_history: messages, actions_performed: actionsPerformed });
      await base44.entities.EventLog.create({ user_email: user.email, participant_id: participantId, attempt_id: attemptId, case_id: caseId, event_type: 'case_completed', event_data: { composite_score: compositeScore, critical_action_score: criticalActionScore }, elapsed_seconds: timeSpent, timestamp: new Date().toISOString() });
      queryClient.invalidateQueries({ queryKey: ['my-attempts'] });
      
      // All cases go through SOAP note before feedback page
      // Case 2 will show teaching module after SOAP (via showPrognosticTeaching)
      navigate(`/SOAPNotePage?attemptId=${attemptId}`);
    } finally {
      setIsGeneratingFeedback(false);
    }
  };



  if (caseLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-slate-950">
        <Loader2 className="w-8 h-8 animate-spin text-teal-400" />
      </div>
    );
  }

  if (!caseData) {
    return (
      <div className="flex flex-col items-center justify-center h-screen bg-slate-950 gap-4">
        <AlertTriangle className="w-10 h-10 text-amber-400" />
        <p className="text-slate-400">Case not found.</p>
        <Button variant="outline" onClick={() => navigate('/Courses')} className="border-slate-700 text-slate-300">Back to Courses</Button>
      </div>
    );
  }

  const isLastStage = false; // chat stages always advance; completion happens after prognosis

  // Per-case subtle background tint
  const caseAccents = [
    { bg: 'rgba(20,184,166,0.04)', border: 'rgba(20,184,166,0.15)', label: 'text-teal-400' },   // teal
    { bg: 'rgba(99,102,241,0.05)', border: 'rgba(99,102,241,0.18)', label: 'text-violet-400' }, // violet
    { bg: 'rgba(234,179,8,0.04)',  border: 'rgba(234,179,8,0.15)',  label: 'text-amber-400' },  // amber
  ];
  const caseIndex = caseData ? (parseInt(caseData.case_id?.replace(/\D/g, '') || '1') - 1) % 3 : 0;
  const accent = caseAccents[caseIndex];

  if (showPreBrief) return <PreBriefScreen onStart={() => { setShowPreBrief(false); setShowConsent(true); }} />;

  if (showConsent) {
    return (
      <ConsentCheckIn
        caseData={caseData}
        onConfirm={async (name) => {
          setLearnerName(name);
          // Record consent in ParticipantProfile if available
          if (participantProfile?.id) {
            try {
              await base44.entities.ParticipantProfile.update(participantProfile.id, {
                learner_name: name,
                consent_given: true,
                consent_date: new Date().toISOString(),
              });
            } catch (e) {
              console.log('Could not update profile:', e);
            }
          }
          setShowConsent(false);
        }}
      />
    );
  }



  if (showAncillaryFeedback) {
    return (
      <div className="min-h-screen">
        <AncillaryTestingFeedback
          orderedTests={orderedTests}
          onContinue={() => {
            setShowAncillaryFeedback(false);
            setActiveSpecialStage('prognosis');
          }}
        />
      </div>
    );
  }

  if (showPrognosisFeedback) {
    return (
      <div className="min-h-screen">
        <PrognosisFeedback
          onContinue={() => {
            setShowPrognosisFeedback(false);
            // Case 2 (teaching case) has extra teaching module before SOAP
            if (caseType === 'case2') {
              setShowPrognosticTeaching(true);
            } else {
              // Cases 1 & 3: proceed directly to SOAP note
              navigate(`/SOAPNotePage?attemptId=${attemptId}`);
            }
          }}
        />
      </div>
    );
  }

  // Case 2 only: shows prognostic category teaching before SOAP
  if (showPrognosticTeaching && caseType === 'case2') {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
        <div className="w-full max-w-4xl">
          <PrognosticCategoryTeaching
            onDone={() => {
              setShowPrognosticTeaching(false);
              navigate(`/SOAPNotePage?attemptId=${attemptId}`);
            }}
          />
        </div>
      </div>
    );
  }



  if (showSurvey) {
    return (
      <PostCaseSurvey
        user={user}
        caseData={caseData}
        attemptId={completedAttemptId}
        participantId={participantProfile?.participant_id || participantId}
        onComplete={() => navigate(`/CaseCompleteFeedback?attemptId=${completedAttemptId}`)}
      />
    );
  }



  const handleHintMobile = () => {
    navigate(`/LearningCheckpoint?attemptId=${attemptId}&stageNum=${currentStage}&caseId=${caseId}`);
  };

  return (
    <div className="case-player-root min-h-screen flex flex-col sm:overflow-hidden sm:h-screen" style={{ backgroundColor: '#020617', backgroundImage: `radial-gradient(ellipse at top left, ${accent.bg} 0%, transparent 60%)` }}>

      {/* Mobile header */}
      <div className="sm:hidden order-first z-20 border-b px-1.5 py-1 bg-slate-950" style={{ borderColor: accent.border }}>
        <div className="flex items-center justify-between gap-1">
          <div className="flex items-center gap-1 px-2 py-0.5 rounded-lg border border-teal-500/30 bg-teal-500/10 text-[10px] font-medium text-teal-400">
            <span>{FIXED_STAGES[(activeSpecialStage === 'prognosis' ? 4 : activeSpecialStage === 'ancillary' ? 3 : currentStage) - 1]?.stage_name}</span>
          </div>
          {/* Case ID badge — upper right on mobile */}
          {caseData && (
            <span className={`text-[10px] font-bold font-mono px-2 py-0.5 rounded-lg border bg-slate-900 ${accent.label}`} style={{ borderColor: accent.border }}>
              {caseData.case_id || caseData.title}
            </span>
          )}
          <div className="flex items-center gap-1">
            {caseData?.purpose === 'teaching' && (
              <button
                onClick={handleHintMobile}
                title="Hint"
                className="p-1.5 rounded-lg text-slate-600 hover:text-amber-400 hover:bg-amber-500/10 transition-all"
              >
                <Lightbulb className="w-3.5 h-3.5" />
              </button>
            )}
            {!activeSpecialStage && (
              <Button
                size="sm"
                onClick={handleAdvanceStage}
                className="bg-teal-600 hover:bg-teal-700 text-xs h-8 px-2 font-semibold gap-1"
              >
                Next <ChevronRight className="w-3.5 h-3.5" />
              </Button>
            )}
          </div>
        </div>
      </div>

      {showTour && <ProgramTour onComplete={handleTourComplete} />}
      {showMissedItemsCheckpoint && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-md w-full mx-4">
            <div className="p-4 sm:p-6">
              <MissedItemsCheckpoint
                stage={caseData?.stages?.[currentStage - 1]}
                caseData={caseData}
                actionsPerformed={actionsPerformed}
                onContinue={handleContinueAfterCheckpoint}
                onBack={handleBackFromCheckpoint}
                attemptId={attemptId}
              />
            </div>
          </div>
        </div>
      )}


      {/* Desktop top bar with case ID */}
      <div className="hidden sm:flex items-center justify-between px-4 py-1.5 border-b border-slate-800/60 bg-slate-950/80" style={{ borderBottomColor: accent.border }}>
        <StageProgress
          stages={FIXED_STAGES}
          currentStage={activeSpecialStage === 'prognosis' ? 4 : activeSpecialStage === 'ancillary' ? 3 : currentStage}
        />
        {caseData && (
          <span className={`text-xs font-bold font-mono px-3 py-1 rounded-lg border bg-slate-900 shrink-0 ml-4 ${accent.label}`} style={{ borderColor: accent.border }}>
            {caseData.case_id || caseData.title}
          </span>
        )}
      </div>

      {/* Two-column layout on desktop, stacked on mobile */}
      <div className="flex-1 flex flex-col sm:flex-row overflow-hidden sm:min-w-0">
        {/* Left panel */}
        <div className="w-full sm:w-1/2 border-b sm:border-b-0 sm:border-r border-slate-800 bg-slate-950 overflow-hidden flex flex-col min-h-[300px] sm:min-w-0">

          <div className="hidden sm:block shrink-0 px-2 pt-1.5 pb-0.5 border-b border-slate-800 text-xs text-slate-500">
            {caseData?.stages?.[currentStage - 1]?.stage_name}
          </div>

          <div className="flex-1 overflow-hidden">
            <PatientPanel
              caseData={caseData}
              currentStage={currentStage}
              attempt={{ actionsPerformed }}
              tourCompleted={tourCompleted}
              onNewMessage={handleNewMessage}
              attemptId={attemptId}
              messages={messages}
              caseId={caseId}
            />
          </div>


        </div>

        {/* Right panel */}
        <div className="w-full sm:w-1/2 flex flex-col min-h-[350px] sm:min-h-0 sm:min-w-0 bg-slate-950">
          {activeSpecialStage === 'ancillary' ? (
            <AncillaryTestOrdering
              caseData={caseData}
              orderedTests={orderedTests}
              onOrderTest={handleOrderTest}
              onAllDone={() => setShowAncillaryFeedback(true)}
              onTestRelevanceFeedback={(testId, feedback) => setTestRelevance(prev => ({ ...prev, [testId]: feedback }))}
            />
          ) : activeSpecialStage === 'prognosis' ? (
            <PrognosisSelector
              caseData={caseData}
              orderedTests={orderedTests}
              testResults={testResults}
              actionsPerformed={actionsPerformed}
              onComplete={() => {
                if (isTeachingCase) {
                  setShowPrognosisFeedback(true);
                } else {
                  // Non-teaching cases: skip prognosisFeedback, go straight to SOAP
                  navigate(`/SOAPNotePage?attemptId=${attemptId}`);
                }
              }}
              attemptId={attemptId}
            />
          ) : (
            <ChatPanel
              caseData={caseData}
              currentStage={currentStage}
              messages={messages}
              onNewMessage={handleNewMessage}
              onAdvanceStage={handleAdvanceStage}
              isLastStage={isLastStage}
              onComplete={handleComplete}
              actionsPerformed={actionsPerformed}
              startTime={startTimeRef.current}
              attemptId={attemptId}
            />
          )}
        </div>
      </div>
    </div>
  );
}