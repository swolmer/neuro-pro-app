import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { useAuth } from '@/lib/AuthContext';
import { ArrowRight, BookOpen, CheckCircle2, Clock } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';

export default function Courses() {
  const { user } = useAuth();

  const { data: modules = [], isLoading } = useQuery({
    queryKey: ['modules'],
    queryFn: async () => {
      const all = await base44.entities.Module.list('order');
      return all.filter(m => m.title?.toLowerCase().includes('cardiac arrest'));
    },
  });

  const { data: cases = [] } = useQuery({
    queryKey: ['cases'],
    queryFn: async () => {
      const all = await base44.entities.Case.list('order');
      return all.filter(c => c.case_id?.toUpperCase().startsWith('CA-'));
    },
  });

  const { data: attempts = [] } = useQuery({
    queryKey: ['my-attempts'],
    queryFn: () => base44.entities.CaseAttempt.filter({ learner_email: user?.email }),
  });

  const completedAttempts = attempts.filter(a => a.status === 'completed');

  if (isLoading) {
    return (
      <div className="p-6 lg:p-10 max-w-5xl mx-auto space-y-4">
        {[1,2,3,4,5].map(i => <Skeleton key={i} className="h-32 rounded-2xl bg-slate-800" />)}
      </div>
    );
  }

  return (
    <div className="p-6 lg:p-10 max-w-6xl mx-auto flex flex-col items-center">
      <div className="mb-8 text-center">
        <h1 className="text-2xl font-bold text-white mb-2">Course Modules</h1>
        <p className="text-slate-400 text-sm">Work through each module sequentially to master neuroprognostication.</p>
      </div>

      <div className="space-y-6 w-full max-w-4xl">
        {modules.map((mod, modIndex) => {
          const moduleCases = cases.filter(c => c.module_id === mod.id);
          const moduleCompleted = moduleCases.filter(c => 
            completedAttempts.some(a => a.case_id === c.id)
          ).length;
          const isModuleComplete = moduleCases.length > 0 && moduleCompleted === moduleCases.length;

          return (
            <div key={mod.id} className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
              {/* Module header */}
              <div className="p-6 border-b border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-bold text-lg ${
                    isModuleComplete 
                      ? 'bg-teal-500/20 text-teal-400' 
                      : 'bg-slate-800 text-slate-400'
                  }`}>
                    {isModuleComplete ? <CheckCircle2 className="w-6 h-6" /> : modIndex + 1}
                  </div>
                  <div>
                    <h2 className="text-lg font-semibold text-white">{mod.title}</h2>
                    <p className="text-sm text-slate-400 mt-0.5">{mod.description}</p>
                  </div>
                </div>
                <Badge className={`${isModuleComplete ? 'bg-teal-500/10 text-teal-400 border-teal-500/20' : 'bg-slate-800 text-slate-400 border-slate-700'}`}>
                  {moduleCompleted}/{moduleCases.length} complete
                </Badge>
              </div>

              {/* Cases */}
              <div className="divide-y divide-slate-800">
                {moduleCases.map((caseItem, caseIndex) => {
                  const isCompleted = completedAttempts.some(a => a.case_id === caseItem.id);
                  const bestScore = Math.max(0, ...completedAttempts.filter(a => a.case_id === caseItem.id).map(a => a.score || 0));
                  const inProgress = attempts.some(a => a.case_id === caseItem.id && a.status === 'in_progress');

                  return (
                    <Link
                      key={caseItem.id}
                      to={`/CasePlayer?caseId=${caseItem.id}`}
                      className="flex items-center justify-between px-6 py-4 hover:bg-slate-800/40 transition-colors group"
                    >
                      <div className="flex items-center gap-4">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-medium ${
                          isCompleted 
                            ? 'bg-teal-500/20 text-teal-400' 
                            : 'bg-slate-800 text-slate-500'
                        }`}>
                          {isCompleted ? <CheckCircle2 className="w-4 h-4" /> : `${modIndex + 1}.${caseIndex + 1}`}
                        </div>
                        <div>
                          <p className="text-sm font-medium text-slate-200 group-hover:text-white transition-colors">
                            {caseItem.title}
                          </p>
                          <div className="flex items-center gap-3 mt-1">
                            <span className="text-xs text-slate-500">{caseItem.case_id}</span>
                            <Badge variant="outline" className={`text-xs border-slate-700 ${
                              caseItem.difficulty === 'baseline' ? 'text-sky-400 border-sky-700' :
                              caseItem.difficulty === 'guided' ? 'text-amber-400 border-amber-700' :
                              'text-purple-400 border-purple-700'
                            }`}>{caseItem.difficulty ? caseItem.difficulty.charAt(0).toUpperCase() + caseItem.difficulty.slice(1) : 'Baseline'}</Badge>
                            {inProgress && !isCompleted && (
                              <Badge className="text-xs bg-amber-500/10 text-amber-400 border-amber-500/20">In Progress</Badge>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        {isCompleted && (
                          <span className={`text-sm font-mono font-medium ${
                            bestScore >= 80 ? 'text-teal-400' : bestScore >= 60 ? 'text-amber-400' : 'text-red-400'
                          }`}>{bestScore}%</span>
                        )}
                        <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-teal-400 transition-colors" />
                      </div>
                    </Link>
                  );
                })}
                {moduleCases.length === 0 && (
                  <div className="px-6 py-8 text-center text-slate-500 text-sm">
                    No cases added to this module yet.
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}