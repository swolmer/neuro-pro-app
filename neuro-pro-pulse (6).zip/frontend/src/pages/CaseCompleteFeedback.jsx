import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import {
  Loader2, Brain, Target, ChevronRight,
  CheckCircle2, XCircle, AlertTriangle, BookOpen, BarChart3,
  ArrowRight, Home, FileText
} from 'lucide-react';
import ProgressRing from '@/components/dashboard/ProgressRing';
import ReasoningScoreCard from '@/components/debrief/ReasoningScoreCard';
import CaseTeachingPanel from '@/components/debrief/CaseTeachingPanel';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

// ─── Tab IDs ──────────────────────────────────────────────────────────────────
const TABS = [
  { id: 'overview',  label: 'Overview',   icon: BarChart3  },
  { id: 'actions',   label: 'Actions',    icon: Target     },
  { id: 'reasoning', label: 'Reasoning',  icon: Brain      },
  { id: 'teaching',  label: 'Teaching',   icon: BookOpen   },
];

// ─── Grade helper (matches CaseTeachingPanel) ─────────────────────────────────
function getGrade(score) {
  if (score >= 85) return { letter: 'A', label: 'Excellent',   color: 'text-teal-400',   bg: 'bg-teal-500/10',   border: 'border-teal-500/25'   };
  if (score >= 70) return { letter: 'B', label: 'Proficient',  color: 'text-cyan-400',   bg: 'bg-cyan-500/10',   border: 'border-cyan-500/25'   };
  if (score >= 55) return { letter: 'C', label: 'Developing',  color: 'text-amber-400',  bg: 'bg-amber-500/10',  border: 'border-amber-500/25'  };
  if (score >= 40) return { letter: 'D', label: 'Needs Work',  color: 'text-orange-400', bg: 'bg-orange-500/10', border: 'border-orange-500/25' };
  return              { letter: 'F', label: 'Insufficient', color: 'text-red-400',    bg: 'bg-red-500/10',    border: 'border-red-500/25'    };
}

// ─── Score bar (reuses app style) ─────────────────────────────────────────────
function ScoreBar({ label, value, max = 100, colorClass = 'bg-teal-500' }) {
  const pct = Math.round((value / max) * 100);
  return (
    <div>
      <div className="flex justify-between text-xs mb-1.5">
        <span className="text-slate-400">{label}</span>
        <span className="text-slate-200 font-mono font-semibold">
          {value}{max !== 100 ? `/${max}` : '%'}
        </span>
      </div>
      <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
        <div
          className={`h-full ${colorClass} rounded-full transition-all duration-700`}
          style={{ width: `${Math.min(100, pct)}%` }}
        />
      </div>
    </div>
  );
}

// ─── Stat tile ────────────────────────────────────────────────────────────────
function StatTile({ label, value, color = 'text-white' }) {
  return (
    <div className="bg-slate-950/60 rounded-xl p-4 text-center">
      <p className={`text-xl font-bold font-mono ${color}`}>{value ?? '—'}</p>
      <p className="text-xs text-slate-500 mt-1">{label}</p>
    </div>
  );
}

// ─── Action pill ──────────────────────────────────────────────────────────────
function ActionPill({ text, done }) {
  return (
    <div className={`flex items-start gap-2.5 rounded-xl px-3 py-2.5 border text-sm ${
      done
        ? 'bg-teal-500/5 border-teal-500/20 text-teal-300'
        : 'bg-red-500/5 border-red-500/20 text-red-300'
    }`}>
      {done
        ? <CheckCircle2 className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
        : <XCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />}
      <span className="leading-relaxed">{text}</span>
    </div>
  );
}

// ─── Section header ───────────────────────────────────────────────────────────
function SectionHead({ children }) {
  return (
    <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-2">
      {children}
    </h3>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────
export default function CaseCompleteFeedback() {
  const navigate = useNavigate();
  const demoEmail = 'demo@caseplayer.local';
  const [activeTab, setActiveTab] = useState('overview');

  // Fetch all completed attempts to check if all 3 cases are done
  const { data: attempts, isLoading } = useQuery({
    queryKey: ['my-attempts-feedback'],
    queryFn: () => base44.entities.CaseAttempt.filter({ learner_email: demoEmail }, '-completed_at', 5),
    staleTime: 0,
  });

  // Filter out cardiac cases
  const filteredAttempts = attempts?.filter(a => !a.case_id?.toUpperCase?.().includes('CARDIAC')) || [];
  const attempt = filteredAttempts?.find(a => a.status === 'completed' && a.ai_debrief) || filteredAttempts?.[0];
  
  // Count completed unique cases (excluding cardiac)
  const completedCases = new Set(filteredAttempts?.filter(a => a.status === 'completed').map(a => a.case_id) || []);
  const hasCompletedAllThree = completedCases.size >= 3;

  // Next-case navigation map (Action item 11)
  const NEXT_CASE_BY_CASE_ID = {
    'CA-BASELINE-001': 'case-ca-teaching-002',
    'CA-TEACH-002': 'case-ca-evaluation-003',
    'CA-EVAL-003': null,
  };
  const CASE_INDEX_BY_CASE_ID = {
    'CA-BASELINE-001': 1,
    'CA-TEACH-002': 2,
    'CA-EVAL-003': 3,
  };
  const nextCaseDbId = attempt?.case_id ? NEXT_CASE_BY_CASE_ID[String(attempt.case_id).toUpperCase()] : null;
  const currentCaseIndex = attempt?.case_id ? CASE_INDEX_BY_CASE_ID[String(attempt.case_id).toUpperCase()] : null;

  // Fetch case data for teaching panel
  const { data: caseData } = useQuery({
    queryKey: ['case-for-feedback', attempt?.case_id],
    queryFn: () => base44.entities.Case.filter({ id: attempt.case_id }).then(r => r[0]),
    enabled: !!attempt?.case_id,
  });

  // ── Loading ──
  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-teal-400" />
      </div>
    );
  }

  // ── Empty ──
  if (!attempt) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center gap-4">
        <Brain className="w-10 h-10 text-slate-600" />
        <p className="text-slate-400 text-sm">No completed attempt found.</p>
        <Button variant="outline" onClick={() => navigate('/Courses')}
          className="border-slate-700 text-slate-300 hover:bg-slate-800">
          Back to Courses
        </Button>
      </div>
    );
  }

  // ── Data ──
  const score    = attempt.composite_reasoning_score ?? attempt.score ?? 0;
  const grade    = getGrade(score);
  const bd       = attempt.score_breakdown || {};
  const timeMin  = attempt.time_spent_seconds ? Math.round(attempt.time_spent_seconds / 60) : null;
  const correctActions = bd.correct_actions || [];
  const missedActions  = bd.missed_actions  || [];
  const cogErrors      = attempt.cognitive_errors || [];
  const hypotheses     = attempt.hypothesis_timestamps || [];
  const firstCorrect   = hypotheses.find(h => h.is_correct);

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 lg:py-12">

        {/* ── Top nav ── */}
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={() => navigate('/Courses')}
            className="flex items-center gap-1.5 text-sm text-slate-400 hover:text-white transition-colors"
          >
            <Home className="w-4 h-4" /> Courses
          </button>
          <button
            onClick={() => navigate('/Dashboard')}
            className="flex items-center gap-1.5 text-sm text-slate-400 hover:text-white transition-colors"
          >
            Dashboard <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* ── Hero card ── */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 mb-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">

            {/* Guidelines fulfilled ring */}
            <div className="flex items-center gap-5 shrink-0">
              <ProgressRing progress={attempt.critical_action_score ?? 0} size={88} strokeWidth={7} />
            </div>

            {/* Title + meta */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap mb-1">
                <h1 className="text-xl font-bold text-white">Case Complete</h1>
              </div>
              {caseData?.title && (
                <p className="text-slate-300 text-sm font-medium mb-1">{caseData.title}</p>
              )}
              <div className="flex items-center gap-2 text-xs text-teal-300/80 mb-2">
                <span className="font-semibold">{currentCaseIndex ? `Case ${currentCaseIndex} of 3` : ''}</span>
                {currentCaseIndex && (
                  <span className="flex items-center gap-1">
                    {[1, 2, 3].map(i => (
                      <span
                        key={i}
                        className={`w-2 h-2 rounded-full ${i <= currentCaseIndex ? 'bg-teal-400' : 'bg-slate-700'}`}
                      />
                    ))}
                  </span>
                )}
              </div>
              <p className="text-slate-500 text-xs">
                {attempt.case_id}
                {timeMin != null && <> · {timeMin} min</>}
                {attempt.completed_at && (
                  <> · {new Date(attempt.completed_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</>
                )}
              </p>
              {/* Guidelines fulfilled counter */}
              <div className="mt-3 inline-flex items-center gap-2 bg-teal-500/10 border border-teal-500/25 rounded-xl px-3 py-1.5">
                <CheckCircle2 className="w-4 h-4 text-teal-400 shrink-0" />
                <span className="text-sm font-bold font-mono text-teal-300">
                  {bd.completed_critical ?? 0}/{bd.total_critical ?? 0}
                </span>
                <span className="text-xs text-teal-400/80">NCS 2023 guidelines fulfilled</span>
              </div>
            </div>

            {/* Quick stat chip */}
            <div className="flex sm:flex-col gap-2 shrink-0 text-right">
              <div className="text-center px-4 py-2 bg-slate-800 rounded-xl">
                <p className={`text-lg font-bold font-mono ${score >= 80 ? 'text-teal-400' : score >= 60 ? 'text-amber-400' : 'text-red-400'}`}>
                  {score}%
                </p>
                <p className="text-xs text-slate-500">Overall</p>
              </div>
            </div>
          </div>

          {/* Sub-score bars */}
          <div className="grid sm:grid-cols-2 gap-3 mt-6 pt-6 border-t border-slate-800">
            <ScoreBar label="Critical Action Completion" value={attempt.critical_action_score ?? 0} colorClass="bg-teal-500" />
            <ScoreBar label="Reasoning Path Order"       value={attempt.order_accuracy_score ?? 0}  colorClass="bg-cyan-500" />
            <ScoreBar label="Diagnostic Efficiency"      value={attempt.diagnostic_efficiency_score ?? 0} colorClass="bg-violet-500" />
            <ScoreBar label="AI Reasoning Quality"       value={attempt.ai_reasoning_score ?? 0} max={5} colorClass="bg-amber-500" />
          </div>
        </div>

        {/* ── Tabs ── */}
        <div className="flex gap-1 bg-slate-900 border border-slate-800 rounded-xl p-1 mb-6">
          {TABS.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs sm:text-sm font-medium transition-all ${
                activeTab === tab.id
                  ? 'bg-teal-500/15 text-teal-400 border border-teal-500/25'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <tab.icon className="w-3.5 h-3.5 shrink-0" />
              <span className="hidden sm:inline">{tab.label}</span>
            </button>
          ))}
        </div>

        {/* ══════════════════════════════════════════════════════
            TAB: OVERVIEW
        ══════════════════════════════════════════════════════ */}
        {activeTab === 'overview' && (
          <div className="space-y-4">

            {/* Performance stats grid */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
              <SectionHead><BarChart3 className="w-3.5 h-3.5 text-teal-400" /> Performance Summary</SectionHead>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <StatTile label="Time Spent"       value={timeMin != null ? `${timeMin}m` : '—'} />
                <StatTile label="Actions Taken"    value={bd.total_actions_taken ?? attempt.actions_performed?.length ?? '—'} />
                <StatTile label="Path Score"       value={bd.reasoning_path_score != null ? `${bd.reasoning_path_score >= 0 ? '+' : ''}${bd.reasoning_path_score} pts` : '—'}
                  color={(bd.reasoning_path_score ?? 0) >= 0 ? 'text-teal-400' : 'text-red-400'} />
                <StatTile label="Time to Dx"       value={firstCorrect ? `${Math.round(firstCorrect.elapsed_seconds / 60)}m` : '—'} />
              </div>
            </div>

            {/* Critical actions summary */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
              <SectionHead><Target className="w-3.5 h-3.5 text-cyan-400" /> Critical Actions at a Glance</SectionHead>
              <div className="flex items-center gap-3 mb-4">
                <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-teal-500 rounded-full transition-all duration-700"
                    style={{ width: bd.total_critical ? `${(bd.completed_critical / bd.total_critical) * 100}%` : '0%' }}
                  />
                </div>
                <span className="text-sm font-mono font-semibold text-slate-200 shrink-0">
                  {bd.completed_critical ?? 0} / {bd.total_critical ?? 0}
                </span>
              </div>
              <div className="grid sm:grid-cols-2 gap-2">
                {correctActions.slice(0, 4).map((a, i) => <ActionPill key={i} text={a} done />)}
                {missedActions.slice(0, 2).map((a, i)  => <ActionPill key={i} text={a} done={false} />)}
                {(correctActions.length + missedActions.length) > 6 && (
                  <button
                    onClick={() => setActiveTab('actions')}
                    className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-teal-400 transition-colors col-span-full pt-1"
                  >
                    See all {correctActions.length + missedActions.length} actions <ArrowRight className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>

            {/* What to improve */}
            {(missedActions.length > 0 || cogErrors.length > 0) && (
              <div className="bg-slate-900 border border-amber-500/20 rounded-2xl p-5">
                <SectionHead><BookOpen className="w-3.5 h-3.5 text-amber-400" /><span className="text-amber-400">What to Focus on in Next Modules</span></SectionHead>
                <div className="space-y-2">
                  {missedActions.map((a, i) => (
                    <div key={i} className="flex items-start gap-2.5 rounded-xl px-3 py-2.5 border bg-amber-500/5 border-amber-500/20">
                      <BookOpen className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                      <div>
                        <p className="text-sm text-amber-200 leading-relaxed">{a}</p>
                        <p className="text-xs text-slate-500 mt-0.5">Review this guideline step in the next module</p>
                      </div>
                    </div>
                  ))}
                  {cogErrors.map((err, i) => (
                    <div key={i} className="flex items-start gap-2.5 rounded-xl px-3 py-2.5 border bg-orange-500/5 border-orange-500/20">
                      <AlertTriangle className="w-4 h-4 text-orange-400 shrink-0 mt-0.5" />
                      <div>
                        <p className="text-sm text-orange-200 leading-relaxed">
                          {{ premature_closure: 'Premature Closure', anchoring_bias: 'Anchoring Bias', availability_bias: 'Availability Bias', framing_effect: 'Framing Effect' }[err.error_type] || err.error_type}
                        </p>
                        {err.description && <p className="text-xs text-slate-500 mt-0.5">{err.description}</p>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}



            {/* Cognitive errors (if any) */}
            {cogErrors.length > 0 && (
              <div className="bg-slate-900 border border-red-500/20 rounded-2xl p-5">
                <SectionHead>
                  <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
                  <span className="text-red-400">Cognitive Errors Detected</span>
                </SectionHead>
                <div className="space-y-2">
                  {cogErrors.map((err, i) => (
                    <div key={i} className="bg-red-500/5 border border-red-500/15 rounded-xl p-3">
                      <p className="text-sm font-semibold text-red-300 mb-0.5">
                        {{ premature_closure: 'Premature Closure', anchoring_bias: 'Anchoring Bias', availability_bias: 'Availability Bias', framing_effect: 'Framing Effect' }[err.error_type] || err.error_type}
                      </p>
                      {err.description  && <p className="text-xs text-slate-400 leading-relaxed">{err.description}</p>}
                      {err.message_text && <p className="text-xs text-slate-500 italic mt-1">"{err.message_text}"</p>}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ══════════════════════════════════════════════════════
            TAB: ACTIONS
        ══════════════════════════════════════════════════════ */}
        {activeTab === 'actions' && (
          <div className="space-y-4">

            {/* Actions checklist */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
              <SectionHead><CheckCircle2 className="w-3.5 h-3.5 text-teal-400" /> Completed Actions</SectionHead>
              {correctActions.length > 0 ? (
                <div className="space-y-2">
                  {correctActions.map((a, i) => <ActionPill key={i} text={a} done />)}
                </div>
              ) : (
                <p className="text-sm text-slate-500 italic">None recorded.</p>
              )}
            </div>

            {missedActions.length > 0 && (
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
                <SectionHead><XCircle className="w-3.5 h-3.5 text-red-400" /><span className="text-red-400">Missed Actions</span></SectionHead>
                <div className="space-y-2">
                  {missedActions.map((a, i) => <ActionPill key={i} text={a} done={false} />)}
                </div>
              </div>
            )}

            {/* Reasoning path timeline */}
            {attempt.actions_performed?.length > 0 && (
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
                <SectionHead><BarChart3 className="w-3.5 h-3.5 text-violet-400" /> Full Reasoning Path</SectionHead>
                <div className="space-y-1.5 max-h-80 overflow-y-auto pr-1">
                  {attempt.actions_performed.map((a, i) => {
                    const cfg = {
                      critical:    { color: 'text-teal-400',   bg: 'bg-teal-500/10 border-teal-500/20',   pts: '+2' },
                      unnecessary: { color: 'text-amber-400',  bg: 'bg-amber-500/10 border-amber-500/20', pts: '-1' },
                      dangerous:   { color: 'text-red-400',    bg: 'bg-red-500/10 border-red-500/20',     pts: '-3' },
                      neutral:     { color: 'text-slate-400',  bg: 'bg-slate-800 border-slate-700',       pts: '0'  },
                    }[a.action_type || 'neutral'] || { color: 'text-slate-400', bg: 'bg-slate-800 border-slate-700', pts: '0' };
                    return (
                      <div key={i} className={`flex items-center gap-2 rounded-lg px-3 py-2 border ${cfg.bg}`}>
                        <span className="text-xs text-slate-600 font-mono w-4 shrink-0">{i + 1}</span>
                        <span className={`text-xs font-semibold w-20 shrink-0 ${cfg.color}`}>{a.action_type || 'neutral'}</span>
                        <span className="text-xs text-slate-300 flex-1 truncate">{a.action_text || a.action}</span>
                        <span className={`text-xs font-mono font-bold shrink-0 ${cfg.color}`}>{cfg.pts}</span>
                        {a.elapsed_seconds != null && (
                          <span className="text-xs text-slate-600 font-mono shrink-0">{Math.round(a.elapsed_seconds / 60)}m</span>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ══════════════════════════════════════════════════════
            TAB: REASONING — reuses existing ReasoningScoreCard
        ══════════════════════════════════════════════════════ */}
        {activeTab === 'reasoning' && (
          <ReasoningScoreCard attempt={attempt} />
        )}

        {/* ══════════════════════════════════════════════════════
            TAB: TEACHING — reuses existing CaseTeachingPanel
        ══════════════════════════════════════════════════════ */}
        {activeTab === 'teaching' && (
          <CaseTeachingPanel attempt={attempt} caseData={caseData} />
        )}

        {/* ── Optional SOAP Note Practice (Case 3 only) ── */}
        {(attempt?.case_id?.includes('003') || attempt?.case_id?.toUpperCase().includes('TBI')) && (
          <div className="mt-8 bg-gradient-to-r from-blue-500/10 to-teal-500/10 border border-blue-500/20 rounded-2xl p-6">
            <div className="flex items-start gap-4">
              <FileText className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-white mb-2">Optional: Practice SOAP Documentation</h3>
                <p className="text-sm text-slate-300 mb-4">
                  For this high-stakes case, you can optionally practice writing a structured SOAP note to document your neuroprognostication assessment. This is completely optional—skip if you prefer.
                </p>
                <Button
                  onClick={() => navigate(`/SOAPNotePage?attemptId=${attempt.id}`)}
                  className="bg-blue-600 hover:bg-blue-700 text-white font-semibold gap-2"
                >
                  <FileText className="w-4 h-4" />
                  Practice SOAP Note
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* ── Footer ── */}
        <div className="mt-8 space-y-3">

          {/* If all 3 cases completed, show Progress Assessment button */}
          {hasCompletedAllThree && (
            <Button
              onClick={() => navigate('/ProgressAssessment')}
              size="lg"
              className="w-full bg-gradient-to-r from-teal-600 to-cyan-600 hover:from-teal-500 hover:to-cyan-500 text-white font-semibold rounded-xl gap-2 py-4"
            >
              <BarChart3 className="w-4 h-4" />
              View Your Progress Assessment
              <ChevronRight className="w-4 h-4 ml-auto" />
            </Button>
          )}

          {/* Primary CTA: Proceed to Next Case (Action item 11) */}
          {nextCaseDbId && (
            <Button
              onClick={() => navigate(`/CasePlayer?caseId=${nextCaseDbId}`)}
              size="lg"
              className="w-full bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-400 hover:to-cyan-400 text-white font-semibold rounded-xl gap-2 py-4"
            >
              Proceed to Next Case
              <ChevronRight className="w-4 h-4 ml-auto" />
            </Button>
          )}

          {/* Secondary: Return to Courses */}
          <Button
            onClick={() => navigate('/Courses')}
            size="lg"
            variant={nextCaseDbId ? 'outline' : 'default'}
            className={nextCaseDbId
              ? 'w-full border-slate-700 text-slate-300 hover:bg-slate-800 hover:text-white rounded-xl gap-2 py-4'
              : 'w-full bg-teal-600 hover:bg-teal-500 text-white font-semibold rounded-xl gap-2 py-4'
            }
          >
            <Home className="w-4 h-4" />
            Return to Courses
            <ChevronRight className="w-4 h-4 ml-auto" />
          </Button>

          {/* Secondary action */}
          <Button
            variant="outline"
            onClick={() => navigate('/Dashboard')}
            className="w-full border-slate-700 text-slate-300 hover:bg-slate-800 hover:text-white"
          >
            Dashboard <ChevronRight className="w-4 h-4 ml-2" />
          </Button>
        </div>

      </div>
    </div>
  );
}