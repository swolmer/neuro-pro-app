import React, { useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { ArrowUp, ArrowDown, TrendingUp, Lightbulb, Target, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function ProgressAssessment() {
  const navigate = useNavigate();
  const demoEmail = 'demo@caseplayer.local';

  // Fetch all case attempts for this user
  const { data: attempts, isLoading } = useQuery({
    queryKey: ['all-attempts', demoEmail],
    queryFn: async () => {
      const all = await base44.entities.CaseAttempt.filter({ learner_email: demoEmail });
      // Sort by case ID to get cases 1, 2, 3 in order
      return all.sort((a, b) => {
        const aNum = parseInt(a.case_id?.match(/\d+/)?.[0] || '0');
        const bNum = parseInt(b.case_id?.match(/\d+/)?.[0] || '0');
        return aNum - bNum;
      });
    },
  });

  const analysis = useMemo(() => {
    if (!attempts || attempts.length < 3) return null;

    const case1 = attempts[0];
    const case2 = attempts[1];
    const case3 = attempts[2];

    // Extract key metrics
    const getMetrics = (attempt) => ({
      score: attempt.score || 0,
      criticalActionScore: attempt.critical_action_score || 0,
      orderAccuracyScore: attempt.order_accuracy_score || 0,
      diagnosticEfficiencyScore: attempt.diagnostic_efficiency_score || 0,
      aiReasoningScore: attempt.ai_reasoning_score || 0,
      timeSpent: attempt.time_spent_seconds || 0,
      cognitiveErrorCount: attempt.cognitive_errors?.length || 0,
      actionsCount: attempt.actions_performed?.length || 0,
    });

    const m1 = getMetrics(case1);
    const m2 = getMetrics(case2);
    const m3 = getMetrics(case3);

    // Calculate improvements
    const improvements = {
      score: {
        '1→3': m3.score - m1.score,
        '1→2': m2.score - m1.score,
        '2→3': m3.score - m2.score,
      },
      criticalActionScore: {
        '1→3': m3.criticalActionScore - m1.criticalActionScore,
        '1→2': m2.criticalActionScore - m1.criticalActionScore,
        '2→3': m3.criticalActionScore - m2.criticalActionScore,
      },
      efficiency: {
        '1→3': m3.diagnosticEfficiencyScore - m1.diagnosticEfficiencyScore,
        '1→2': m2.diagnosticEfficiencyScore - m1.diagnosticEfficiencyScore,
        '2→3': m3.diagnosticEfficiencyScore - m2.diagnosticEfficiencyScore,
      },
      reasoning: {
        '1→3': m3.aiReasoningScore - m1.aiReasoningScore,
        '1→2': m2.aiReasoningScore - m1.aiReasoningScore,
        '2→3': m3.aiReasoningScore - m2.aiReasoningScore,
      },
      cognitiveErrors: {
        case1: m1.cognitiveErrorCount,
        case2: m2.cognitiveErrorCount,
        case3: m3.cognitiveErrorCount,
      },
    };

    return { m1, m2, m3, improvements, cases: { case1, case2, case3 } };
  }, [attempts]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-slate-950">
        <div className="w-8 h-8 border-4 border-slate-700 border-t-teal-400 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!analysis) {
    return (
      <div className="flex flex-col items-center justify-center h-screen bg-slate-950 gap-4">
        <p className="text-slate-400">Complete all three cases to view progress assessment.</p>
        <Button variant="outline" onClick={() => navigate('/Courses')} className="border-slate-700 text-slate-300">Back to Courses</Button>
      </div>
    );
  }

  const { m1, m2, m3, improvements } = analysis;

  // Determine learning insights
  const insights = [];
  if (improvements.score['1→3'] > 10) insights.push('Strong overall improvement from Case 1 to Case 3');
  if (improvements.criticalActionScore['2→3'] > 5) insights.push('Continued progress on critical actions in Case 3');
  if (improvements.efficiency['1→3'] > 0) insights.push('Better diagnostic efficiency by Case 3');
  if (improvements.cognitiveErrors.case3 < improvements.cognitiveErrors.case1) insights.push('Reduced cognitive errors by Case 3');
  if (improvements.reasoning['2→3'] > 0) insights.push('Improved clinical reasoning quality in Case 3');

  const confusionAreas = [];
  if (improvements.orderAccuracyScore['2→3'] < 0) confusionAreas.push('Action sequencing—still working on optimal order');
  if (improvements.cognitiveErrors.case3 > 1) confusionAreas.push('Cognitive bias—watch for anchoring and premature closure');
  if (m3.diagnosticEfficiencyScore < 60) confusionAreas.push('Diagnostic efficiency—consider streamlining your approach');
  if (m3.criticalActionScore < 80) confusionAreas.push('Critical actions—ensure you\'re addressing all key areas');

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 to-slate-900">
      {/* Header */}
      <div className="border-b border-slate-800 bg-slate-950/80 backdrop-blur px-4 py-8 sm:px-6 sticky top-0 z-20">
        <div className="max-w-5xl mx-auto">
          <h1 className="text-3xl sm:text-4xl font-bold text-white mb-2">Your Progress Assessment</h1>
          <p className="text-slate-400">Comparing your performance across Cases 1, 2, and 3</p>
        </div>
      </div>

      {/* Main content */}
      <div className="p-4 sm:p-6 max-w-5xl mx-auto space-y-6">

        {/* Score Progression */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-5 h-5 text-teal-400" />
            <h2 className="text-lg font-bold text-white">Overall Score Progression</h2>
          </div>
          <div className="grid grid-cols-3 gap-4">
            {[
              { label: 'Case 1 (First)', score: m1.score, color: 'from-slate-700 to-slate-600' },
              { label: 'Case 2 (Teaching)', score: m2.score, color: 'from-teal-700 to-teal-600' },
              { label: 'Case 3 (Assessment)', score: m3.score, color: 'from-slate-700 to-slate-600' },
            ].map(({ label, score, color }, i) => (
              <div key={i} className={`bg-gradient-to-br ${color} rounded-lg p-4 text-center`}>
                <p className="text-sm text-slate-200 mb-2">{label}</p>
                <p className="text-3xl font-bold text-white">{Math.round(score)}%</p>
              </div>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-4 mt-4 text-sm">
            <div className={`p-3 rounded-lg ${improvements.score['1→3'] > 0 ? 'bg-green-500/10 border border-green-500/30' : 'bg-red-500/10 border border-red-500/30'}`}>
              <p className="text-slate-400 mb-1">Case 1 → Case 3</p>
              <div className="flex items-center gap-2">
                {improvements.score['1→3'] > 0 ? <ArrowUp className="w-4 h-4 text-green-400" /> : <ArrowDown className="w-4 h-4 text-red-400" />}
                <span className={improvements.score['1→3'] > 0 ? 'text-green-300' : 'text-red-300'}>{improvements.score['1→3'] > 0 ? '+' : ''}{improvements.score['1→3'].toFixed(1)}</span>
              </div>
            </div>
            <div className={`p-3 rounded-lg ${improvements.score['2→3'] > 0 ? 'bg-green-500/10 border border-green-500/30' : 'bg-red-500/10 border border-red-500/30'}`}>
              <p className="text-slate-400 mb-1">Case 2 → Case 3</p>
              <div className="flex items-center gap-2">
                {improvements.score['2→3'] > 0 ? <ArrowUp className="w-4 h-4 text-green-400" /> : <ArrowDown className="w-4 h-4 text-red-400" />}
                <span className={improvements.score['2→3'] > 0 ? 'text-green-300' : 'text-red-300'}>{improvements.score['2→3'] > 0 ? '+' : ''}{improvements.score['2→3'].toFixed(1)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Metric Breakdown */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            { label: 'Critical Actions', key: 'criticalActionScore', metric: 'm' },
            { label: 'Diagnostic Efficiency', key: 'diagnosticEfficiencyScore', metric: 'm' },
            { label: 'Action Sequencing', key: 'orderAccuracyScore', metric: 'm' },
            { label: 'Reasoning Quality', key: 'aiReasoningScore', metric: 'scale' },
          ].map(({ label, key, metric }) => {
            const v1 = metric === 'scale' ? m1[key] : m1[key];
            const v3 = metric === 'scale' ? m3[key] : m3[key];
            const change = v3 - v1;
            const isScale = metric === 'scale';
            return (
              <div key={key} className="bg-slate-900 border border-slate-800 rounded-lg p-4">
                <p className="text-sm font-semibold text-slate-300 mb-3">{label}</p>
                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-500">Case 1:</span>
                    <span className="text-slate-200">{isScale ? v1.toFixed(1) : Math.round(v1)}{'%'}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-500">Case 3:</span>
                    <span className="text-slate-200">{isScale ? v3.toFixed(1) : Math.round(v3)}{'%'}</span>
                  </div>
                  <div className={`flex items-center gap-1 text-xs font-semibold mt-2 ${change > 0 ? 'text-green-400' : change < 0 ? 'text-red-400' : 'text-slate-400'}`}>
                    {change > 0 ? <ArrowUp className="w-3 h-3" /> : change < 0 ? <ArrowDown className="w-3 h-3" /> : <span>—</span>}
                    {change > 0 ? '+' : ''}{isScale ? change.toFixed(1) : Math.round(change)}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Learning Insights */}
        {insights.length > 0 && (
          <div className="bg-teal-950/30 border border-teal-700/40 rounded-xl p-6">
            <div className="flex items-start gap-3">
              <Lightbulb className="w-5 h-5 text-teal-400 shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-teal-300 mb-3">What You Learned</h3>
                <ul className="space-y-2">
                  {insights.map((insight, i) => (
                    <li key={i} className="text-sm text-teal-200 flex items-start gap-2">
                      <span className="text-teal-400 mt-1">✓</span>
                      {insight}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )}

        {/* Areas of Confusion */}
        {confusionAreas.length > 0 && (
          <div className="bg-amber-950/30 border border-amber-700/40 rounded-xl p-6">
            <div className="flex items-start gap-3">
              <Target className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-amber-300 mb-3">Areas to Focus On</h3>
                <ul className="space-y-2">
                  {confusionAreas.map((area, i) => (
                    <li key={i} className="text-sm text-amber-200 flex items-start gap-2">
                      <span className="text-amber-400 mt-1">→</span>
                      {area}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )}

        {/* Cognitive Errors Trend */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <h3 className="font-semibold text-white mb-4">Cognitive Errors Detected</h3>
          <div className="grid grid-cols-3 gap-4">
            {[
              { label: 'Case 1', count: improvements.cognitiveErrors.case1 },
              { label: 'Case 2', count: improvements.cognitiveErrors.case2 },
              { label: 'Case 3', count: improvements.cognitiveErrors.case3 },
            ].map(({ label, count }) => (
              <div key={label} className="bg-slate-800/60 rounded-lg p-4 text-center">
                <p className="text-xs text-slate-500 uppercase mb-2">{label}</p>
                <p className="text-2xl font-bold text-slate-200">{count}</p>
                <p className="text-[10px] text-slate-600 mt-1">errors detected</p>
              </div>
            ))}
          </div>
        </div>

        {/* Prognosis Review Growth */}
        {analysis.cases?.case1?.stages && (
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
            <div className="flex items-center gap-2 mb-4">
              <Eye className="w-5 h-5 text-cyan-400" />
              <h3 className="font-semibold text-white">Your Prognosis Growth</h3>
            </div>
            <p className="text-sm text-slate-400 mb-4">Review how your prognostication approach evolved from Case 1 to Case 3.</p>
            <div className="space-y-3">
              {[
                { case: 'Case 1', title: 'First Case', desc: 'Initial baseline—how you approached your first neuroprognostication' },
                { case: 'Case 2', title: 'Teaching Case', desc: 'Integrated feedback and guidance from Case 1' },
                { case: 'Case 3', title: 'Assessment', desc: 'Demonstrated mastery with advanced case complexity' }
              ].map((item, i) => (
                <div key={i} className="border border-slate-700 rounded-lg p-3 hover:bg-slate-800/40 transition-colors">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-sm font-semibold text-slate-200">{item.case}: {item.title}</p>
                    <span className="text-xs bg-slate-800 px-2 py-1 rounded text-slate-400">
                      Score: {[m1.score, m2.score, m3.score][i]}%
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>

      {/* Footer */}
      <div className="border-t border-slate-800 bg-slate-950/80 backdrop-blur px-4 py-6 sm:px-6 mt-8">
        <div className="max-w-5xl mx-auto">
          <Button
            onClick={() => navigate('/Courses')}
            className="w-full bg-teal-600 hover:bg-teal-700 text-white font-semibold py-3"
          >
            Return to Dashboard
          </Button>
        </div>
      </div>
    </div>
  );
}