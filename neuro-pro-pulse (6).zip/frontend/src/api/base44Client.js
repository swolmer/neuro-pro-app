// Local mock of the Base44 SDK surface used throughout the app.
// Persists entities to localStorage and stubs auth + LLM calls so the
// original UI works without the hosted Base44 backend.

import { SEED_MODULES, SEED_CASES } from '@/lib/seedData';

const STORAGE_KEY = 'neurosim_db_v9_4stage';

const DEMO_USER = {
  id: 'demo-learner',
  email: 'learner@neurosim.app',
  full_name: 'Dr. Demo Learner',
  role: 'admin',
};

function loadDB() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (_) {}
  const seeded = {
    Module: SEED_MODULES.map((m) => ({ ...m })),
    Case: SEED_CASES.map((c) => ({ ...c })),
    CaseAttempt: [],
    EventLog: [],
    ParticipantProfile: [],
    Survey: [],
  };
  saveDB(seeded);
  return seeded;
}

function saveDB(db) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
  } catch (_) {}
}

let _db = null;
function db() {
  if (!_db) _db = loadDB();
  return _db;
}

function uid(prefix) {
  return `${prefix || 'id'}-${Math.random().toString(36).slice(2, 10)}-${Date.now().toString(36)}`;
}

function applyOrder(items, order) {
  if (!order) return items;
  const desc = order.startsWith('-');
  const key = desc ? order.slice(1) : order;
  return [...items].sort((a, b) => {
    const av = a?.[key];
    const bv = b?.[key];
    if (av === bv) return 0;
    if (av === undefined) return 1;
    if (bv === undefined) return -1;
    return desc ? (av < bv ? 1 : -1) : (av < bv ? -1 : 1);
  });
}

function makeEntity(name) {
  return {
    list: async (order, limit) => {
      const items = applyOrder(db()[name] || [], order);
      return limit ? items.slice(0, limit) : items;
    },
    filter: async (where = {}, order, limit) => {
      const items = (db()[name] || []).filter((item) => {
        return Object.entries(where).every(([k, v]) => item[k] === v);
      });
      const sorted = applyOrder(items, order);
      return limit ? sorted.slice(0, limit) : sorted;
    },
    get: async (id) => (db()[name] || []).find((x) => x.id === id) || null,
    create: async (data) => {
      const now = new Date().toISOString();
      const record = { id: uid(name.toLowerCase()), created_at: now, updated_at: now, ...data };
      db()[name] = [...(db()[name] || []), record];
      saveDB(db());
      return record;
    },
    update: async (id, patch) => {
      const arr = db()[name] || [];
      const idx = arr.findIndex((x) => x.id === id);
      if (idx >= 0) {
        arr[idx] = { ...arr[idx], ...patch, updated_at: new Date().toISOString() };
        db()[name] = arr;
        saveDB(db());
        return arr[idx];
      }
      return null;
    },
    delete: async (id) => {
      db()[name] = (db()[name] || []).filter((x) => x.id !== id);
      saveDB(db());
      return { id };
    },
  };
}

const auth = {
  me: async () => DEMO_USER,
  logout: () => {},
  redirectToLogin: () => {},
};

// ---- Mock LLM ----------------------------------------------------------
function detectPhase(text = '') {
  const t = text.toLowerCase();
  if (t.includes('phase 1') || t.includes('early') || t.includes('0–24') || t.includes('0-24') ||
      t.includes('post-rosc') && (t.includes('6 h') || t.includes('12 h') || t.includes('within 24'))) {
    return 'early';
  }
  if (t.includes('phase 2') || t.includes('intermediate') || t.includes('24–72') || t.includes('24-72') ||
      t.includes('rewarm') || t.includes('48 h post-rosc')) {
    return 'intermediate';
  }
  if (t.includes('phase 3') || t.includes('late') || t.includes('>72') || t.includes('72 h') ||
      t.includes('96 h') || t.includes('formal prognost')) {
    return 'late';
  }
  return null;
}

function mockLLMResponse(prompt = '', schema) {
  const p = String(prompt).toLowerCase();
  const phase = detectPhase(p);

  if (schema) {
    return {
      score: 78,
      strengths: [
        'Deferred prognostication until ≥72 h from ROSC and off sedation (NCS 2023 Good Practice Statements 1 & 2)',
        'Used a multimodal approach rather than relying on a single variable (Good Practice Statement 4)',
        'Named each predictor\u2019s reliability tier (reliable / moderately reliable / not reliable)',
      ],
      weaknesses: [
        'Did not explicitly screen pharmacologic clearance of sedation given prolonged infusion',
        'Could have framed counseling language by reliability tier (very likely / likely with substantial uncertainty / uncertain)',
      ],
      overall_feedback:
        'Reasoning aligned with NCS 2023 (Rajajee et al., Neurocrit Care 2023). Strengthen by explicitly stating reliability tiers in your synthesis and tailoring counseling language to the strongest predictor present.',
    };
  }

  // ---- Teaching Case 1 (Day 1 / Day 4) scripted Q&A ---------------------
  // These answers reflect the clinician author's outline for CA-TEACH-001.
  if ((p.includes('hours since') && (p.includes('arrest') || p.includes('rosc'))) ||
      (p.includes('how long') && p.includes('arrest')) ||
      p.includes('when did he arrest') || p.includes('when did the arrest')) {
    return '18 hours since arrest. (Day 1)';
  }
  if ((p.includes('cannot') || p.includes("can't") || p.includes('too early') || p.includes('defer')) &&
      p.includes('72') && p.includes('prognost')) {
    return 'Yes, that is correct. Agreed — we will not perform formal neuroprognostication until ≥72 h from arrest / rewarming.';
  }
  if (p.includes('sedation') || p.includes('propofol') || p.includes('fentanyl')) {
    if (phase === 'early' || p.includes('day 1')) {
      return 'He is on propofol and fentanyl because he was shivering on TTM. We can turn them off once he has completed 24 h of targeted temperature management.';
    }
  }
  if (p.includes('ttm') || p.includes('targeted temperature') || p.includes('cooling') || p.includes('temperature management')) {
    return 'Yes — we are cooling him to 36°C for 24 h and then slowly rewarming while preventing fever.';
  }
  if (p.includes('electrolyte') || p.includes('chem') || p.includes('bmp') || p.includes('cmp') || p.includes('ammonia') || p.includes('liver') || p.includes('lft')) {
    return 'Normal electrolyte panel. No AKI. No hepatic abnormality. Ammonia is normal.';
  }
  if (p.includes('utox') || p.includes('toxicology') || p.includes('alcohol') || p.includes('etoh')) {
    return 'No toxins detected. Serum alcohol normal.';
  }
  if (p.includes('medical history') || p.includes('pmh') || p.includes('past medical')) {
    return 'CAD, HTN, HLD.';
  }
  if (p.includes('pressor') || p.includes('levophed') || p.includes('norepinephrine') || p.includes('vent setting') || p.includes('hemodynam') || p.includes('peep') || p.includes('fio2')) {
    return 'Low-dose norepinephrine. PEEP 10, FiO2 60% — hemodynamically stable on current support.';
  }
  if ((p.includes('head ct') || p.includes('ct head') || p.includes('admission ct')) && !p.includes('mri')) {
    return 'Admission head CT shows cerebral edema and some blurring of the gray-white differentiation — concerning for hypoxic-ischemic brain injury.';
  }
  if (p.includes('how long was the arrest') || p.includes('duration of cpr') || p.includes('downtime') || (p.includes('cpr') && p.includes('how long'))) {
    return 'Family is uncertain. He had 30 minutes of CPR in the ED before ROSC.';
  }

  // Exam questions (Day 1, after 10 min sedation pause)
  if (p.includes('response to voice') || (p.includes('open') && p.includes('eye'))) {
    return 'He does not open his eyes. He does have intermittent non-rhythmic jerking movements.';
  }
  if (p.includes('noxious') || p.includes('central stim')) {
    return 'No eye opening, no purposeful movement. Same intermittent non-rhythmic jerking.';
  }
  if (p.includes('pupil')) {
    return '2 mm bilaterally, sluggishly reactive.';
  }
  if (p.includes('corneal')) { return 'Absent bilaterally.'; }
  if (p.includes('cough')) { return 'Absent.'; }
  if (p.includes('gag')) { return 'Absent.'; }
  if (p.includes('motor') || p.includes('movement')) {
    return 'Absent in all four limbs other than the irregular jerking.';
  }
  if (p.includes('myoclon')) {
    return 'The jerking is irregular and non-rhythmic — clinically concerning for post-anoxic myoclonus. Await EEG correlation.';
  }

  // Studies ordering — NCS 2023 timing
  if (p.includes('mri') && (p.includes('order') || p.includes('when') || p.includes('timing'))) {
    return 'MRI brain — appropriate between Day 2 and Day 7 from ROSC. A diffuse pattern of restricted diffusion across vascular distributions (bilateral cortex + deep gray matter) is a MODERATELY RELIABLE predictor of poor outcome per NCS 2023; ideally combined with a neurophysiologic study (EEG or SSEP).';
  }
  if (p.includes('ssep') && (p.includes('order') || p.includes('when') || p.includes('timing'))) {
    return 'SSEP — at least 48 h from ROSC (longer if hypothermia confounding suspected). Bilateral absence of the N20 wave with PRESERVED responses at Erb\u2019s point and the cervical spine is a RELIABLE predictor of poor outcome per NCS 2023 (FPR ≤3%, upper 95% CI ≤7%). Sedation and NMB do not abolish N20.';
  }
  if (p.includes('ct head') && (p.includes('order') || p.includes('when') || p.includes('timing'))) {
    return 'Noncontrast CT head ≥48 h from ROSC for prognostic purposes. Diffuse loss of gray-white differentiation with sulcal effacement across bilateral anterior and posterior circulation (including deep gray matter) is a MODERATELY RELIABLE predictor per NCS 2023. The early "etiology" CT done shortly after ROSC is too early for prognostic interpretation.';
  }
  if (p.includes('eeg') && (p.includes('order') || p.includes('when') || p.includes('timing'))) {
    return 'Continuous EEG — start Day 1 for myoclonus / seizure surveillance. For prognostication, suppressed or burst-suppression background ≥72 h from ROSC (or ≥72 h from rewarming if hypothermia used), in the absence of sedation or other confounders, is a MODERATELY RELIABLE predictor of poor outcome per NCS 2023.';
  }
  if (p.includes('nse') && (p.includes('order') || p.includes('when') || p.includes('reliab'))) {
    return 'Per NCS 2023, serum NSE alone (≤72 h from ROSC) is NOT a reliable predictor — no consistent threshold has been validated, and FPR varies widely (0–42%) by threshold. Use only as supportive data alongside other predictors.';
  }

  // Predictor reliability questions (NCS 2023 framework)
  if (p.includes('reliable predictor') || p.includes('what counts as reliable') || p.includes('reliability tier')) {
    return 'Per NCS 2023: RELIABLE predictors of poor outcome (FPR ≤3%, upper 95% CI ≤10%) are (1) bilateral absence of pupillary light response ≥72 h from ROSC, and (2) bilateral absence of N20 SSEP ≥48 h from ROSC. MODERATELY RELIABLE (FPR ≤5%) are diffuse DWI restriction on MRI 2–7 days, suppressed/burst-suppression EEG ≥72 h off sedation, and diffuse loss of gray-white differentiation on CT ≥48 h. NOT reliable in isolation: age, rhythm, time-to-ROSC, corneal reflex alone, motor response alone, myoclonus <48 h without EEG, NSE alone, prediction models.';
  }
  if (p.includes('age') && (p.includes('reliab') || p.includes('predictor'))) {
    return 'Per NCS 2023, age alone is NOT a reliable predictor of poor functional outcome (weak recommendation; low quality evidence). Best considered as a component of a validated prediction model.';
  }
  if (p.includes('rhythm') && (p.includes('reliab') || p.includes('predictor'))) {
    return 'Per NCS 2023, the initial cardiac rhythm alone (shockable vs nonshockable) is NOT a reliable predictor of poor functional outcome (FPR 13–40% — too high). Best considered in context.';
  }
  if (p.includes('downtime') && (p.includes('reliab') || p.includes('predictor'))) {
    return 'Per NCS 2023, time-to-ROSC alone is NOT a reliable predictor of poor functional outcome (FPR up to 32% for >25 min). Best considered as part of a validated prediction model.';
  }
  if (p.includes('corneal') && (p.includes('reliab') || p.includes('predictor'))) {
    return 'Per NCS 2023, bilateral absence of the corneal reflex ALONE is NOT a reliable predictor (FPR up to 16% — too high). It is supportive only when other reliable / moderately reliable predictors are present.';
  }
  if ((p.includes('motor') || p.includes('extensor')) && (p.includes('reliab') || p.includes('predictor'))) {
    return 'Per NCS 2023, motor response no better than extension alone is NOT a reliable predictor (FPR 15–30% in newer studies). Conversely, motor response of withdrawal or localization (GCS-M ≥4) at Day 4 supports a possibly favorable outcome (sensitivity ~93%, specificity ~77%).';
  }
  if (p.includes('myoclon')) {
    return 'Per NCS 2023, myoclonus <48 h from ROSC WITHOUT concomitant EEG is NOT a reliable predictor of poor outcome. With EEG showing burst-suppression and time-locked bursts, the malignant EEG pattern carries the prognostic weight. Note: Lance-Adams syndrome (delayed sporadic myoclonus) is a distinct entity often associated with GOOD recovery.';
  }
  if (p.includes('pupillometry') || p.includes('npi')) {
    return 'Per NCS 2023, when a pupillometer is available, quantitative pupillometry should be used to confirm bilateral absence of the pupillary light response. Up to 1/3 of pupils judged nonreactive on manual exam are reactive on pupillometry. NPi <3 with measurable response is NOT bilaterally absent and is therefore NOT the reliable poor predictor.';
  }
  if (p.includes('counsel') || p.includes('language') || p.includes('what do i tell')) {
    return 'Per NCS 2023 counseling language: with a RELIABLE predictor present, "very likely poor outcome." With multiple MODERATELY RELIABLE predictors (and no reliable), "likely poor outcome" with "substantial uncertainty." With no reliable or multiple moderately reliable predictors, counsel that likelihood, extent, and time course of recovery are uncertain and that recovery may take days to several months (Good Practice Statement 5).';
  }

  if (p.includes('impression') || p.includes('what do you think') || (p.includes('tell') && p.includes('family')) || (p.includes('discuss') && p.includes('impression'))) {
    if (p.includes('day 4') || p.includes('72 hour') || phase === 'late') {
      return 'The team is asking for your Day 4 synthesis. Per NCS 2023 multimodal framework: name each predictor, state its reliability tier (reliable / moderately reliable / not reliable), comment on multimodal concordance, acknowledge missing data as uncertainty, and choose the appropriate counseling language.';
    }
    return 'The team would like to know your impression. (Per NCS 2023 Good Practice Statement 1, formal neuroprognostication is deferred until ≥72 h from arrest / rewarming. If you agree it is too early, say so explicitly and specify which ancillary studies you want and when.)';
  }

  // Phase-level fallbacks
  if (phase === 'early') {
    return 'You are in the EARLY phase (0–24 h post-ROSC). Per NCS 2023 Good Practice Statement 1, formal prognostication is deferred. Focus on stabilization, TTM, MAP, and seizure surveillance.';
  }
  if (phase === 'intermediate') {
    return 'You are in the INTERMEDIATE phase (24–72 h post-ROSC). Per NCS 2023, formal prognostication remains deferred. Emerging exam findings should be framed as preliminary while confounders clear.';
  }
  if (phase === 'late') {
    return 'You are in the LATE / Day 4+ window. Per NCS 2023, integrate predictors multimodally — never base prognosis on a single variable (Good Practice Statement 4). Name each predictor\u2019s reliability tier and choose counseling language accordingly.';
  }

  if (p.includes('cardiac arrest') || p.includes('arrest') || p.includes('rosc')) {
    return 'Yes — this is a post–cardiac arrest neuroprognostication case. Per NCS 2023, identify time post-ROSC, screen confounders, and use the multimodal framework before any prognostic statement.';
  }

  return 'Per NCS 2023: on Day 1 gather information, screen confounders, and order studies with correct timing — but do NOT formally prognosticate. On Day 4+ (≥72 h from arrest AND off sedation) synthesize multimodally and choose counseling language by predictor reliability tier.';
}

const integrations = {
  Core: {
    // Real LLM call — proxies through our backend which injects the NCS 2023
    // guideline as system context. Falls back to the mock only if the network
    // call fails so the app never hard-crashes.
    InvokeLLM: async ({ prompt, response_json_schema, model, provider, extra_system } = {}) => {
      try {
        const backendUrl = (typeof process !== 'undefined' && process.env && process.env.REACT_APP_BACKEND_URL) || '';
        const resp = await fetch(`${backendUrl}/api/llm/invoke`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt, response_json_schema, model, provider, extra_system }),
        });
        if (!resp.ok) throw new Error(`LLM proxy status ${resp.status}`);
        const data = await resp.json();
        if (data.error) throw new Error(data.error);
        if (response_json_schema) return data.data || {};
        return data.text || '';
      } catch (err) {
        console.warn('[InvokeLLM] falling back to local heuristic:', err.message);
        return mockLLMResponse(prompt, response_json_schema);
      }
    },
    UploadFile: async ({ file }) => ({
      file_url: typeof URL !== 'undefined' && file ? URL.createObjectURL(file) : '',
    }),
  },
};

export const base44 = {
  auth,
  entities: {
    Module: makeEntity('Module'),
    Case: makeEntity('Case'),
    CaseAttempt: makeEntity('CaseAttempt'),
    EventLog: makeEntity('EventLog'),
    ParticipantProfile: makeEntity('ParticipantProfile'),
    Survey: makeEntity('Survey'),
  },
  integrations,
};
