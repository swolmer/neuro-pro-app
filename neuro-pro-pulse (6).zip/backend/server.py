from fastapi import FastAPI, APIRouter, HTTPException
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import json
import logging
import re
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime, timezone

from ncs_guideline import NCS_2023_SYSTEM_CONTEXT


ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create the main app without a prefix
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")


# Define Models
class StatusCheck(BaseModel):
    model_config = ConfigDict(extra="ignore")  # Ignore MongoDB's _id field
    
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    client_name: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class StatusCheckCreate(BaseModel):
    client_name: str

# Add your routes to the router instead of directly to app
@api_router.get("/")
async def root():
    return {"message": "Hello World"}

@api_router.post("/status", response_model=StatusCheck)
async def create_status_check(input: StatusCheckCreate):
    status_dict = input.model_dump()
    status_obj = StatusCheck(**status_dict)
    
    # Convert to dict and serialize datetime to ISO string for MongoDB
    doc = status_obj.model_dump()
    doc['timestamp'] = doc['timestamp'].isoformat()
    
    _ = await db.status_checks.insert_one(doc)
    return status_obj

@api_router.get("/status", response_model=List[StatusCheck])
async def get_status_checks():
    # Exclude MongoDB's _id field from the query results
    status_checks = await db.status_checks.find({}, {"_id": 0}).to_list(1000)
    
    # Convert ISO string timestamps back to datetime objects
    for check in status_checks:
        if isinstance(check['timestamp'], str):
            check['timestamp'] = datetime.fromisoformat(check['timestamp'])
    
    return status_checks

# Include the router in the main app

# ---------------------------------------------------------------------------
# LLM invoke proxy — routes all chatbot / feedback / scoring calls through
# the Emergent Universal LLM key, with the NCS 2023 guideline injected as
# the system context so responses stay grounded in the guideline.
# ---------------------------------------------------------------------------

EMERGENT_LLM_KEY = os.environ.get('EMERGENT_LLM_KEY', '').strip()
DEFAULT_PROVIDER = 'anthropic'
DEFAULT_MODEL = 'claude-sonnet-4-5-20250929'


class InvokeLLMRequest(BaseModel):
    prompt: str
    model: Optional[str] = None
    provider: Optional[str] = None
    response_json_schema: Optional[Dict[str, Any]] = None
    session_id: Optional[str] = None
    extra_system: Optional[str] = None  # case-specific addendum


class InvokeLLMResponse(BaseModel):
    text: Optional[str] = None
    data: Optional[Any] = Field(default=None, description="Parsed JSON if a schema was requested")
    model: str
    provider: str
    error: Optional[str] = None


def _coerce_json(text: str) -> Any:
    """Parse a JSON string the model returned. Strips code fences."""
    if not text:
        return {}
    cleaned = re.sub(r'^```(?:json)?|```$', '', text.strip(), flags=re.MULTILINE).strip()
    try:
        return json.loads(cleaned)
    except Exception:
        match = re.search(r'\{.*\}', cleaned, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(0))
            except Exception:
                pass
    return {}


@api_router.post("/llm/invoke", response_model=InvokeLLMResponse)
async def invoke_llm(req: InvokeLLMRequest):
    if not EMERGENT_LLM_KEY:
        raise HTTPException(status_code=500, detail="EMERGENT_LLM_KEY not configured")

    provider = (req.provider or DEFAULT_PROVIDER).lower()
    model = req.model or DEFAULT_MODEL

    # Build the system prompt: NCS 2023 guideline + (optional case addendum) +
    # JSON-only instruction if a schema was requested.
    system_parts = [NCS_2023_SYSTEM_CONTEXT]
    if req.extra_system:
        system_parts.append(req.extra_system)
    if req.response_json_schema:
        system_parts.append(
            "You MUST respond with a single valid JSON object matching the "
            "requested schema. No preamble, no markdown code fences, no "
            "explanation. Only the JSON object."
        )
    system_message = "\n\n".join(system_parts)

    session_id = req.session_id or f"neurosim-{uuid.uuid4().hex[:12]}"

    try:
        # Import lazily so the server boots even if the package is missing.
        from emergentintegrations.llm.chat import LlmChat, UserMessage
    except Exception as e:
        logger.exception("emergentintegrations import failed")
        raise HTTPException(status_code=500, detail=f"LLM library unavailable: {e}")

    try:
        chat = LlmChat(
            api_key=EMERGENT_LLM_KEY,
            session_id=session_id,
            system_message=system_message,
        ).with_model(provider, model)

        reply = await chat.send_message(UserMessage(text=req.prompt))
        text = str(reply) if reply is not None else ''
    except Exception as e:
        logger.exception("LLM call failed")
        # Surface a helpful error for the frontend so learners see a message
        # instead of a silent fallback.
        return InvokeLLMResponse(
            text=None,
            json=None,
            model=model,
            provider=provider,
            error=str(e),
        )

    if req.response_json_schema:
        return InvokeLLMResponse(
            text=text,
            data=_coerce_json(text),
            model=model,
            provider=provider,
        )

    return InvokeLLMResponse(text=text, model=model, provider=provider)


app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()